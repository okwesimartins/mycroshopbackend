const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const { authenticate, authorize } = require('../middleware/auth');
const { attachTenantDb } = require('../middleware/tenant');
const { initializeTenantModels } = require('../middleware/models');
const inventoryController = require('../controllers/inventoryController');

// All routes require authentication and tenant DB
router.use(authenticate);
router.use(attachTenantDb);
router.use(initializeTenantModels);

// Get all products
router.get('/', inventoryController.getAllProducts);

// Get product by ID
router.get('/:id', inventoryController.getProductById);

// Create product
router.post('/',
  [
    body('name').notEmpty().withMessage('Product name is required'),
    body('price').isFloat({ min: 0 }).withMessage('Price must be a positive number')
  ],
  inventoryController.createProduct
);

// Update product
router.put('/:id', inventoryController.updateProduct);

// Delete product
router.delete('/:id', authorize('admin', 'manager'), inventoryController.deleteProduct);

// Get low stock products
router.get('/alerts/low-stock', inventoryController.getLowStockProducts);

module.exports = router;

