const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const authController = require('../controllers/authController');

// Register new tenant
router.post('/register',
  [
    body('name').notEmpty().withMessage('Tenant name is required'),
    body('subdomain').notEmpty().withMessage('Subdomain is required'),
    body('subdomain').matches(/^[a-z0-9-]+$/).withMessage('Subdomain can only contain lowercase letters, numbers, and hyphens'),
    body('adminEmail').isEmail().withMessage('Valid email is required'),
    body('adminPassword').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
    body('license_key').notEmpty().withMessage('License key is required')
  ],
  authController.register
);

// Login
router.post('/login',
  [
    body('email').isEmail().withMessage('Valid email is required'),
    body('password').notEmpty().withMessage('Password is required')
  ],
  authController.login
);

// Refresh token
router.post('/refresh', authController.refreshToken);

// Get current user
const { authenticate } = require('../middleware/auth');
router.get('/me', authenticate, authController.getCurrentUser);

module.exports = router;