const { Sequelize } = require('sequelize');
const mysql = require('mysql2/promise');

// Main database connection (for tenant management)
const mainDbConfig = {
  host: process.env.MAIN_DB_HOST || 'localhost',
  port: process.env.MAIN_DB_PORT || 3306,
  user: process.env.MAIN_DB_USER || 'root',
  password: process.env.MAIN_DB_PASSWORD,
  database: process.env.MAIN_DB_NAME || 'mycroshop_main'
};

// Create main database connection
const mainSequelize = new Sequelize(
  mainDbConfig.database,
  mainDbConfig.user,
  mainDbConfig.password,
  {
    host: mainDbConfig.host,
    port: mainDbConfig.port,
    dialect: 'mysql',
    logging: process.env.NODE_ENV === 'development' ? console.log : false,
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  }
);

// Store active tenant connections
const tenantConnections = new Map();

/**
 * Get tenant database connection
 * Creates connection if it doesn't exist
 */
async function getTenantConnection(tenantId) {
  if (tenantConnections.has(tenantId)) {
    return tenantConnections.get(tenantId);
  }

  const dbName = `${process.env.TENANT_DB_PREFIX || 'mycroshop_tenant_'}${tenantId}`;
  
  const sequelize = new Sequelize(
    dbName,
    process.env.TENANT_DB_USER || 'root',
    process.env.TENANT_DB_PASSWORD,
    {
      host: process.env.TENANT_DB_HOST || 'localhost',
      port: process.env.TENANT_DB_PORT || 3306,
      dialect: 'mysql',
      logging: process.env.NODE_ENV === 'development' ? console.log : false,
      pool: {
        max: 5,
        min: 0,
        acquire: 30000,
        idle: 10000
      }
    }
  );

  // Test connection
  try {
    await sequelize.authenticate();
    tenantConnections.set(tenantId, sequelize);
    return sequelize;
  } catch (error) {
    console.error(`Failed to connect to tenant database ${dbName}:`, error);
    throw new Error(`Database connection failed for tenant ${tenantId}`);
  }
}

/**
 * Create a new tenant database
 */
async function createTenantDatabase(tenantId) {
  const connection = await mysql.createConnection({
    host: process.env.TENANT_DB_HOST || 'localhost',
    port: process.env.TENANT_DB_PORT || 3306,
    user: process.env.TENANT_DB_USER || 'root',
    password: process.env.TENANT_DB_PASSWORD
  });

  const dbName = `${process.env.TENANT_DB_PREFIX || 'mycroshop_tenant_'}${tenantId}`;
  
  try {
    // Create database
    await connection.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
    
    // Switch to the new database
    await connection.query(`USE \`${dbName}\``);
    
    // Run migrations to create tables
    await runTenantMigrations(connection);
    
    await connection.end();
    return dbName;
  } catch (error) {
    await connection.end();
    console.error(`Error creating tenant database:`, error);
    throw error;
  }
}

/**
 * Run migrations for tenant database
 */
async function runTenantMigrations(connection) {
  // Products table
  await connection.query(`
    CREATE TABLE IF NOT EXISTS products (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      sku VARCHAR(100) UNIQUE,
      description TEXT,
      price DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
      cost DECIMAL(10, 2) DEFAULT 0.00,
      stock INT DEFAULT 0,
      low_stock_threshold INT DEFAULT 10,
      category VARCHAR(100),
      image_url VARCHAR(500),
      is_active BOOLEAN DEFAULT TRUE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_sku (sku),
      INDEX idx_category (category),
      INDEX idx_is_active (is_active)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);

  // Customers table
  await connection.query(`
    CREATE TABLE IF NOT EXISTS customers (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      email VARCHAR(255),
      phone VARCHAR(50),
      address TEXT,
      city VARCHAR(100),
      state VARCHAR(100),
      zip_code VARCHAR(20),
      country VARCHAR(100),
      notes TEXT,
      tags JSON,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      INDEX idx_email (email),
      INDEX idx_phone (phone)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);

  // Invoices table
  await connection.query(`
    CREATE TABLE IF NOT EXISTS invoices (
      id INT AUTO_INCREMENT PRIMARY KEY,
      invoice_number VARCHAR(50) UNIQUE NOT NULL,
      customer_id INT,
      issue_date DATE NOT NULL,
      due_date DATE,
      subtotal DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
      tax_amount DECIMAL(10, 2) DEFAULT 0.00,
      discount_amount DECIMAL(10, 2) DEFAULT 0.00,
      total DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
      status ENUM('draft', 'sent', 'paid', 'overdue', 'cancelled') DEFAULT 'draft',
      payment_method VARCHAR(50),
      payment_date DATE,
      notes TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
      INDEX idx_invoice_number (invoice_number),
      INDEX idx_customer_id (customer_id),
      INDEX idx_status (status),
      INDEX idx_issue_date (issue_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);

  // Invoice items table
  await connection.query(`
    CREATE TABLE IF NOT EXISTS invoice_items (
      id INT AUTO_INCREMENT PRIMARY KEY,
      invoice_id INT NOT NULL,
      product_id INT,
      item_name VARCHAR(255) NOT NULL,
      description TEXT,
      quantity DECIMAL(10, 2) NOT NULL DEFAULT 1.00,
      unit_price DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
      total DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE,
      FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
      INDEX idx_invoice_id (invoice_id),
      INDEX idx_product_id (product_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);

  // Bookings table
  await connection.query(`
    CREATE TABLE IF NOT EXISTS bookings (
      id INT AUTO_INCREMENT PRIMARY KEY,
      customer_id INT,
      service_type VARCHAR(100) NOT NULL,
      service_name VARCHAR(255),
      description TEXT,
      scheduled_at DATETIME NOT NULL,
      duration_minutes INT DEFAULT 60,
      staff_name VARCHAR(255),
      status ENUM('pending', 'confirmed', 'completed', 'cancelled', 'no_show') DEFAULT 'pending',
      notes TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
      INDEX idx_customer_id (customer_id),
      INDEX idx_scheduled_at (scheduled_at),
      INDEX idx_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);

  // Store products table (for online store)
  await connection.query(`
    CREATE TABLE IF NOT EXISTS store_products (
      id INT AUTO_INCREMENT PRIMARY KEY,
      product_id INT NOT NULL,
      is_published BOOLEAN DEFAULT FALSE,
      seo_title VARCHAR(255),
      seo_description TEXT,
      seo_keywords VARCHAR(500),
      featured BOOLEAN DEFAULT FALSE,
      sort_order INT DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
      INDEX idx_is_published (is_published),
      INDEX idx_featured (featured)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);

  // Customer interactions/CRM logs
  await connection.query(`
    CREATE TABLE IF NOT EXISTS customer_interactions (
      id INT AUTO_INCREMENT PRIMARY KEY,
      customer_id INT NOT NULL,
      interaction_type ENUM('call', 'email', 'meeting', 'note', 'whatsapp', 'instagram') NOT NULL,
      subject VARCHAR(255),
      description TEXT,
      interaction_date DATETIME NOT NULL,
      created_by VARCHAR(255),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
      INDEX idx_customer_id (customer_id),
      INDEX idx_interaction_date (interaction_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);

  // AI Agent configurations
  await connection.query(`
    CREATE TABLE IF NOT EXISTS ai_agent_configs (
      id INT AUTO_INCREMENT PRIMARY KEY,
      whatsapp_enabled BOOLEAN DEFAULT FALSE,
      instagram_enabled BOOLEAN DEFAULT FALSE,
      whatsapp_phone_number VARCHAR(50),
      whatsapp_phone_number_id VARCHAR(100),
      whatsapp_access_token TEXT,
      instagram_account_id VARCHAR(100),
      instagram_access_token TEXT,
      greeting_message TEXT,
      unavailable_message TEXT,
      business_hours JSON,
      auto_reply_enabled BOOLEAN DEFAULT TRUE,
      settings JSON,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);
}

/**
 * Close tenant connection
 */
function closeTenantConnection(tenantId) {
  if (tenantConnections.has(tenantId)) {
    const sequelize = tenantConnections.get(tenantId);
    sequelize.close();
    tenantConnections.delete(tenantId);
  }
}

module.exports = {
  mainSequelize,
  getTenantConnection,
  createTenantDatabase,
  closeTenantConnection
};

