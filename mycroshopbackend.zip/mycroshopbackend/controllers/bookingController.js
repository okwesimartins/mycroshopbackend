const { Sequelize } = require('sequelize');
const moment = require('moment');

/**
 * Get all bookings
 */
async function getAllBookings(req, res) {
  try {
    const { page = 1, limit = 50, status, customer_id, start_date, end_date } = req.query;
    const offset = (page - 1) * limit;

    const where = {};
    if (status) {
      where.status = status;
    }
    if (customer_id) {
      where.customer_id = customer_id;
    }
    if (start_date || end_date) {
      where.scheduled_at = {};
      if (start_date) where.scheduled_at[Sequelize.Op.gte] = start_date;
      if (end_date) where.scheduled_at[Sequelize.Op.lte] = end_date;
    }

    const { count, rows } = await req.db.models.Booking.findAndCountAll({
      where,
      include: [
        {
          model: req.db.models.Customer,
          attributes: ['id', 'name', 'email', 'phone']
        }
      ],
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [['scheduled_at', 'ASC']]
    });

    res.json({
      success: true,
      data: {
        bookings: rows,
        pagination: {
          total: count,
          page: parseInt(page),
          limit: parseInt(limit),
          totalPages: Math.ceil(count / limit)
        }
      }
    });
  } catch (error) {
    console.error('Error getting bookings:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get bookings'
    });
  }
}

/**
 * Get booking by ID
 */
async function getBookingById(req, res) {
  try {
    const booking = await req.db.models.Booking.findByPk(req.params.id, {
      include: [
        {
          model: req.db.models.Customer
        }
      ]
    });

    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found'
      });
    }

    res.json({
      success: true,
      data: { booking }
    });
  } catch (error) {
    console.error('Error getting booking:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get booking'
    });
  }
}

/**
 * Create booking
 */
async function createBooking(req, res) {
  try {
    const {
      customer_id,
      service_type,
      service_name,
      description,
      scheduled_at,
      duration_minutes,
      staff_name,
      notes
    } = req.body;

    // Check for conflicts (optional - can be enhanced)
    const conflictingBooking = await req.db.models.Booking.findOne({
      where: {
        scheduled_at: {
          [Sequelize.Op.between]: [
            moment(scheduled_at).subtract(duration_minutes || 60, 'minutes').toDate(),
            moment(scheduled_at).add(duration_minutes || 60, 'minutes').toDate()
          ]
        },
        status: {
          [Sequelize.Op.in]: ['pending', 'confirmed']
        }
      }
    });

    if (conflictingBooking) {
      return res.status(409).json({
        success: false,
        message: 'Time slot already booked'
      });
    }

    const booking = await req.db.models.Booking.create({
      customer_id: customer_id || null,
      service_type,
      service_name: service_name || null,
      description: description || null,
      scheduled_at,
      duration_minutes: duration_minutes || 60,
      staff_name: staff_name || null,
      status: 'pending',
      notes: notes || null
    });

    const completeBooking = await req.db.models.Booking.findByPk(booking.id, {
      include: [
        {
          model: req.db.models.Customer
        }
      ]
    });

    res.status(201).json({
      success: true,
      message: 'Booking created successfully',
      data: { booking: completeBooking }
    });
  } catch (error) {
    console.error('Error creating booking:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create booking'
    });
  }
}

/**
 * Update booking
 */
async function updateBooking(req, res) {
  try {
    const booking = await req.db.models.Booking.findByPk(req.params.id);
    
    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found'
      });
    }

    const {
      customer_id,
      service_type,
      service_name,
      description,
      scheduled_at,
      duration_minutes,
      staff_name,
      notes
    } = req.body;

    await booking.update({
      ...(customer_id !== undefined && { customer_id }),
      ...(service_type !== undefined && { service_type }),
      ...(service_name !== undefined && { service_name }),
      ...(description !== undefined && { description }),
      ...(scheduled_at !== undefined && { scheduled_at }),
      ...(duration_minutes !== undefined && { duration_minutes }),
      ...(staff_name !== undefined && { staff_name }),
      ...(notes !== undefined && { notes })
    });

    const updatedBooking = await req.db.models.Booking.findByPk(booking.id, {
      include: [
        {
          model: req.db.models.Customer
        }
      ]
    });

    res.json({
      success: true,
      message: 'Booking updated successfully',
      data: { booking: updatedBooking }
    });
  } catch (error) {
    console.error('Error updating booking:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update booking'
    });
  }
}

/**
 * Update booking status
 */
async function updateBookingStatus(req, res) {
  try {
    const { status } = req.body;
    
    const validStatuses = ['pending', 'confirmed', 'completed', 'cancelled', 'no_show'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid status'
      });
    }

    const booking = await req.db.models.Booking.findByPk(req.params.id);
    
    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found'
      });
    }

    await booking.update({ status });

    res.json({
      success: true,
      message: 'Booking status updated successfully',
      data: { booking }
    });
  } catch (error) {
    console.error('Error updating booking status:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update booking status'
    });
  }
}

/**
 * Delete booking
 */
async function deleteBooking(req, res) {
  try {
    const booking = await req.db.models.Booking.findByPk(req.params.id);
    
    if (!booking) {
      return res.status(404).json({
        success: false,
        message: 'Booking not found'
      });
    }

    await booking.destroy();

    res.json({
      success: true,
      message: 'Booking deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting booking:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete booking'
    });
  }
}

/**
 * Get bookings by date range (for calendar view)
 */
async function getBookingsByDateRange(req, res) {
  try {
    const { start_date, end_date } = req.query;

    if (!start_date || !end_date) {
      return res.status(400).json({
        success: false,
        message: 'Start date and end date are required'
      });
    }

    const bookings = await req.db.models.Booking.findAll({
      where: {
        scheduled_at: {
          [Sequelize.Op.between]: [start_date, end_date]
        }
      },
      include: [
        {
          model: req.db.models.Customer,
          attributes: ['id', 'name', 'email', 'phone']
        }
      ],
      order: [['scheduled_at', 'ASC']]
    });

    res.json({
      success: true,
      data: { bookings }
    });
  } catch (error) {
    console.error('Error getting bookings by date range:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get bookings'
    });
  }
}

module.exports = {
  getAllBookings,
  getBookingById,
  createBooking,
  updateBooking,
  updateBookingStatus,
  deleteBooking,
  getBookingsByDateRange
};

