const { Sequelize } = require('sequelize');
const moment = require('moment');

/**
 * Generate unique invoice number
 */
function generateInvoiceNumber() {
  const prefix = 'INV';
  const timestamp = Date.now().toString().slice(-8);
  const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  return `${prefix}-${timestamp}-${random}`;
}

/**
 * Get all invoices
 */
async function getAllInvoices(req, res) {
  try {
    const { page = 1, limit = 50, status, customer_id, start_date, end_date } = req.query;
    const offset = (page - 1) * limit;

    const where = {};
    if (status) {
      where.status = status;
    }
    if (customer_id) {
      where.customer_id = customer_id;
    }
    if (start_date || end_date) {
      where.issue_date = {};
      if (start_date) where.issue_date[Sequelize.Op.gte] = start_date;
      if (end_date) where.issue_date[Sequelize.Op.lte] = end_date;
    }

    const { count, rows } = await req.db.models.Invoice.findAndCountAll({
      where,
      include: [
        {
          model: req.db.models.Customer,
          attributes: ['id', 'name', 'email', 'phone']
        },
        {
          model: req.db.models.InvoiceItem,
          include: [
            {
              model: req.db.models.Product,
              attributes: ['id', 'name', 'sku']
            }
          ]
        }
      ],
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [['created_at', 'DESC']]
    });

    res.json({
      success: true,
      data: {
        invoices: rows,
        pagination: {
          total: count,
          page: parseInt(page),
          limit: parseInt(limit),
          totalPages: Math.ceil(count / limit)
        }
      }
    });
  } catch (error) {
    console.error('Error getting invoices:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get invoices'
    });
  }
}

/**
 * Get invoice by ID
 */
async function getInvoiceById(req, res) {
  try {
    const invoice = await req.db.models.Invoice.findByPk(req.params.id, {
      include: [
        {
          model: req.db.models.Customer
        },
        {
          model: req.db.models.InvoiceItem,
          include: [
            {
              model: req.db.models.Product
            }
          ]
        }
      ]
    });

    if (!invoice) {
      return res.status(404).json({
        success: false,
        message: 'Invoice not found'
      });
    }

    res.json({
      success: true,
      data: { invoice }
    });
  } catch (error) {
    console.error('Error getting invoice:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get invoice'
    });
  }
}

/**
 * Create invoice
 */
async function createInvoice(req, res) {
  const transaction = await req.db.transaction();
  
  try {
    const {
      customer_id,
      issue_date,
      due_date,
      items,
      tax_rate = 0,
      discount_amount = 0,
      notes
    } = req.body;

    // Calculate totals
    let subtotal = 0;
    const invoiceItems = [];

    for (const item of items) {
      const { product_id, item_name, description, quantity, unit_price } = item;
      
      // If product_id is provided, get product info (but use provided unit_price - flexible pricing)
      let product = null;
      if (product_id) {
        product = await req.db.models.Product.findByPk(product_id);
      }

      const itemTotal = quantity * unit_price;
      subtotal += itemTotal;

      invoiceItems.push({
        product_id: product_id || null,
        item_name: product ? product.name : item_name,
        description: description || (product ? product.description : null),
        quantity,
        unit_price,
        total: itemTotal
      });
    }

    const taxAmount = subtotal * (tax_rate / 100);
    const total = subtotal + taxAmount - discount_amount;

    // Create invoice
    const invoice = await req.db.models.Invoice.create({
      invoice_number: generateInvoiceNumber(),
      customer_id: customer_id || null,
      issue_date,
      due_date: due_date || null,
      subtotal,
      tax_amount: taxAmount,
      discount_amount,
      total,
      status: 'draft',
      notes: notes || null
    }, { transaction });

    // Create invoice items
    for (const item of invoiceItems) {
      await req.db.models.InvoiceItem.create({
        invoice_id: invoice.id,
        ...item
      }, { transaction });
    }

    await transaction.commit();

    // Fetch complete invoice with relations
    const completeInvoice = await req.db.models.Invoice.findByPk(invoice.id, {
      include: [
        {
          model: req.db.models.Customer
        },
        {
          model: req.db.models.InvoiceItem,
          include: [
            {
              model: req.db.models.Product
            }
          ]
        }
      ]
    });

    res.status(201).json({
      success: true,
      message: 'Invoice created successfully',
      data: { invoice: completeInvoice }
    });
  } catch (error) {
    await transaction.rollback();
    console.error('Error creating invoice:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create invoice'
    });
  }
}

/**
 * Update invoice
 */
async function updateInvoice(req, res) {
  const transaction = await req.db.transaction();
  
  try {
    const invoice = await req.db.models.Invoice.findByPk(req.params.id);
    
    if (!invoice) {
      await transaction.rollback();
      return res.status(404).json({
        success: false,
        message: 'Invoice not found'
      });
    }

    if (invoice.status === 'paid' || invoice.status === 'cancelled') {
      await transaction.rollback();
      return res.status(400).json({
        success: false,
        message: 'Cannot update paid or cancelled invoice'
      });
    }

    const {
      customer_id,
      issue_date,
      due_date,
      items,
      tax_rate = 0,
      discount_amount = 0,
      notes
    } = req.body;

    // If items are provided, recalculate totals
    if (items) {
      // Delete existing items
      await req.db.models.InvoiceItem.destroy({
        where: { invoice_id: invoice.id }
      }, { transaction });

      // Calculate new totals
      let subtotal = 0;
      const invoiceItems = [];

      for (const item of items) {
        const { product_id, item_name, description, quantity, unit_price } = item;
        
        let product = null;
        if (product_id) {
          product = await req.db.models.Product.findByPk(product_id);
        }

        const itemTotal = quantity * unit_price;
        subtotal += itemTotal;

        invoiceItems.push({
          product_id: product_id || null,
          item_name: product ? product.name : item_name,
          description: description || (product ? product.description : null),
          quantity,
          unit_price,
          total: itemTotal
        });
      }

      const taxAmount = subtotal * (tax_rate / 100);
      const total = subtotal + taxAmount - discount_amount;

      // Update invoice
      await invoice.update({
        ...(customer_id !== undefined && { customer_id }),
        ...(issue_date !== undefined && { issue_date }),
        ...(due_date !== undefined && { due_date }),
        subtotal,
        tax_amount: taxAmount,
        discount_amount,
        total,
        ...(notes !== undefined && { notes })
      }, { transaction });

      // Create new items
      for (const item of invoiceItems) {
        await req.db.models.InvoiceItem.create({
          invoice_id: invoice.id,
          ...item
        }, { transaction });
      }
    } else {
      // Update invoice fields only
      await invoice.update({
        ...(customer_id !== undefined && { customer_id }),
        ...(issue_date !== undefined && { issue_date }),
        ...(due_date !== undefined && { due_date }),
        ...(notes !== undefined && { notes })
      }, { transaction });
    }

    await transaction.commit();

    // Fetch updated invoice
    const updatedInvoice = await req.db.models.Invoice.findByPk(invoice.id, {
      include: [
        {
          model: req.db.models.Customer
        },
        {
          model: req.db.models.InvoiceItem,
          include: [
            {
              model: req.db.models.Product
            }
          ]
        }
      ]
    });

    res.json({
      success: true,
      message: 'Invoice updated successfully',
      data: { invoice: updatedInvoice }
    });
  } catch (error) {
    await transaction.rollback();
    console.error('Error updating invoice:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update invoice'
    });
  }
}

/**
 * Update invoice status
 */
async function updateInvoiceStatus(req, res) {
  try {
    const { status, payment_method, payment_date } = req.body;
    
    const validStatuses = ['draft', 'sent', 'paid', 'overdue', 'cancelled'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid status'
      });
    }

    const invoice = await req.db.models.Invoice.findByPk(req.params.id);
    
    if (!invoice) {
      return res.status(404).json({
        success: false,
        message: 'Invoice not found'
      });
    }

    await invoice.update({
      status,
      ...(payment_method && { payment_method }),
      ...(payment_date && { payment_date })
    });

    res.json({
      success: true,
      message: 'Invoice status updated successfully',
      data: { invoice }
    });
  } catch (error) {
    console.error('Error updating invoice status:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update invoice status'
    });
  }
}

/**
 * Delete invoice
 */
async function deleteInvoice(req, res) {
  try {
    const invoice = await req.db.models.Invoice.findByPk(req.params.id);
    
    if (!invoice) {
      return res.status(404).json({
        success: false,
        message: 'Invoice not found'
      });
    }

    if (invoice.status === 'paid') {
      return res.status(400).json({
        success: false,
        message: 'Cannot delete paid invoice'
      });
    }

    await invoice.destroy();

    res.json({
      success: true,
      message: 'Invoice deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting invoice:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete invoice'
    });
  }
}

module.exports = {
  getAllInvoices,
  getInvoiceById,
  createInvoice,
  updateInvoice,
  updateInvoiceStatus,
  deleteInvoice
};

