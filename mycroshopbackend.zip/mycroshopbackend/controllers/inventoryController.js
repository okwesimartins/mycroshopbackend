const { Sequelize } = require('sequelize');

/**
 * Get all products
 */
async function getAllProducts(req, res) {
  try {
    const { page = 1, limit = 50, search, category, isActive } = req.query;
    const offset = (page - 1) * limit;

    const where = {};
    if (search) {
      where[Sequelize.Op.or] = [
        { name: { [Sequelize.Op.like]: `%${search}%` } },
        { sku: { [Sequelize.Op.like]: `%${search}%` } }
      ];
    }
    if (category) {
      where.category = category;
    }
    if (isActive !== undefined) {
      where.is_active = isActive === 'true';
    }

    const { count, rows } = await req.db.models.Product.findAndCountAll({
      where,
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [['created_at', 'DESC']]
    });

    res.json({
      success: true,
      data: {
        products: rows,
        pagination: {
          total: count,
          page: parseInt(page),
          limit: parseInt(limit),
          totalPages: Math.ceil(count / limit)
        }
      }
    });
  } catch (error) {
    console.error('Error getting products:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get products'
    });
  }
}

/**
 * Get product by ID
 */
async function getProductById(req, res) {
  try {
    const product = await req.db.models.Product.findByPk(req.params.id);
    
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    res.json({
      success: true,
      data: { product }
    });
  } catch (error) {
    console.error('Error getting product:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get product'
    });
  }
}

/**
 * Create product
 */
async function createProduct(req, res) {
  try {
    const { name, sku, description, price, cost, stock, low_stock_threshold, category, image_url } = req.body;

    const product = await req.db.models.Product.create({
      name,
      sku: sku || null,
      description: description || null,
      price: price || 0,
      cost: cost || 0,
      stock: stock || 0,
      low_stock_threshold: low_stock_threshold || 10,
      category: category || null,
      image_url: image_url || null,
      is_active: true
    });

    res.status(201).json({
      success: true,
      message: 'Product created successfully',
      data: { product }
    });
  } catch (error) {
    console.error('Error creating product:', error);
    if (error.name === 'SequelizeUniqueConstraintError') {
      return res.status(409).json({
        success: false,
        message: 'SKU already exists'
      });
    }
    res.status(500).json({
      success: false,
      message: 'Failed to create product'
    });
  }
}

/**
 * Update product
 */
async function updateProduct(req, res) {
  try {
    const product = await req.db.models.Product.findByPk(req.params.id);
    
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    const { name, sku, description, price, cost, stock, low_stock_threshold, category, image_url, is_active } = req.body;

    await product.update({
      ...(name !== undefined && { name }),
      ...(sku !== undefined && { sku }),
      ...(description !== undefined && { description }),
      ...(price !== undefined && { price }),
      ...(cost !== undefined && { cost }),
      ...(stock !== undefined && { stock }),
      ...(low_stock_threshold !== undefined && { low_stock_threshold }),
      ...(category !== undefined && { category }),
      ...(image_url !== undefined && { image_url }),
      ...(is_active !== undefined && { is_active })
    });

    res.json({
      success: true,
      message: 'Product updated successfully',
      data: { product }
    });
  } catch (error) {
    console.error('Error updating product:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update product'
    });
  }
}

/**
 * Delete product
 */
async function deleteProduct(req, res) {
  try {
    const product = await req.db.models.Product.findByPk(req.params.id);
    
    if (!product) {
      return res.status(404).json({
        success: false,
        message: 'Product not found'
      });
    }

    await product.destroy();

    res.json({
      success: true,
      message: 'Product deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting product:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete product'
    });
  }
}

/**
 * Get low stock products
 */
async function getLowStockProducts(req, res) {
  try {
    const products = await req.db.models.Product.findAll({
      where: {
        is_active: true,
        stock: {
          [Sequelize.Op.lte]: Sequelize.col('low_stock_threshold')
        }
      },
      order: [['stock', 'ASC']]
    });

    res.json({
      success: true,
      data: { products }
    });
  } catch (error) {
    console.error('Error getting low stock products:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get low stock products'
    });
  }
}

module.exports = {
  getAllProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
  getLowStockProducts
};

