const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const app = express();

// Middleware
app.use(helmet());
app.use(cors({
  origin: process.env.CORS_ORIGIN?.split(',') || '*',
  credentials: true
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Subdomain identification (for web access via subdomain)
const { identifyTenantBySubdomain } = require('./middleware/subdomain');
app.use(identifyTenantBySubdomain);

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});
app.use('/api/', limiter);

// Routes
app.use('/api/v1/auth', require('./routes/auth'));
app.use('/api/v1/inventory', require('./routes/inventory'));
app.use('/api/v1/invoices', require('./routes/invoices'));
app.use('/api/v1/customers', require('./routes/customers'));
app.use('/api/v1/bookings', require('./routes/bookings'));
app.use('/api/v1/store', require('./routes/store'));
app.use('/api/v1/licenses', require('./routes/licenses')); // License key management (admin only)
app.use('/api/v1/meta-connection', require('./routes/metaConnection')); // Meta account connection
// AI Agent endpoints (for BMT to AI communication)
app.use('/api/v1/ai-agent', require('./routes/aiAgent'));

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal server error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: 'Route not found'
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
});

module.exports = app;

