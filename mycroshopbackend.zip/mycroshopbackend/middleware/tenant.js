const { getTenantConnection } = require('../config/database');

/**
 * Middleware to attach tenant database connection to request
 * Must be used after auth middleware
 */
async function attachTenantDb(req, res, next) {
  try {
    if (!req.user || !req.user.tenantId) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required'
      });
    }

    // Get tenant database connection
    const sequelize = await getTenantConnection(req.user.tenantId);
    req.db = sequelize;

    next();
  } catch (error) {
    console.error('Error attaching tenant database:', error);
    return res.status(500).json({
      success: false,
      message: 'Database connection error'
    });
  }
}

module.exports = {
  attachTenantDb
};

