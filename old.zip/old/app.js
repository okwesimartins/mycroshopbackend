const express= require("express");
const cors = require("cors");
const dotenv= require("dotenv");


const adminRoutes = require("./routes/adminroute");


const app = express();

const db = require("./models");

app.use(express.json());
app.use(cors({
    origin: '*'
}));
dotenv.config();



db.sequelize.authenticate()
  .then(() => {
    console.log("Synced db.");
  })
  .catch((err) => {
    console.log("Failed to sync db: " + err.message);
  });

// app.use("/", adminRoutes);

app.use("/", adminRoutes);

// app.get("/", (req, res) => {
//   res.send("Welcome to Hair Planet Backend!");
// });

const PORT =  3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
// app.listen()
  