const adminRoutes = require("express").Router();


const Subscription_payments = require("../controllers/subscription_payments.js");

const Buying_pool  = require("../controllers/buying_pool.js")

const Mycroshop_logistics = require("../controllers/mycroshop_logistics")

// const Products = require("../controllers/products.js")

// const Payment_list = require("../controllers/payment_list.js")

// const Suppliers = require("../controllers/suppliers.js")
const authmiddleware = require("../middleware/auth.js")
const filevalidatorMiddleware = require("../middleware/file.js");

// const Invoice = require("../controllers/invoice.js")
// const Purchase = require("../controllers/purchase.js")

// const Reports = require("../controllers/reports.js")

// const Customers= require("../controllers/customers.js")

// const Dashboard= require("../controllers/dashboard.js")


adminRoutes.post("/generate_mycroshop_form_token", Buying_pool.generateSupplierFormToken)
//auth route ////////////////////////////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////mycroshop subscription payment///////////////////////////////////////////////
//sub payment link
adminRoutes.post("/sub_payment_link", Subscription_payments.subscribeToPlan);


//verify sub-payment
adminRoutes.get("/verify_sub_payment", Subscription_payments.verifyPayment);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////



/// ///////////////////////////////////mycroshop buying pool /////////////////////////////////////////
adminRoutes.post("/register_supplier", Buying_pool.registerSupplier)

adminRoutes.post("/login_supplier", Buying_pool.loginSupplier)

adminRoutes.post("/login_pool_customer", Buying_pool.loginPoolCustomer)

adminRoutes.get("/get_login_pool_customer_details",authmiddleware.verifyToken,authmiddleware.authorization("pool_customer"), Buying_pool.getLoggedInCustomer)

adminRoutes.get("/get_login_supplier_details",authmiddleware.verifyToken,authmiddleware.authorization("supplier"), Buying_pool.getLoggedInSupplier)

adminRoutes.post("/supplier_create_buying_pool_plan",authmiddleware.verifyToken,authmiddleware.authorization("supplier"), Buying_pool.createSupplierPoolSubPlan)

adminRoutes.put("/supplier_update_buying_pool_plan",authmiddleware.verifyToken,authmiddleware.authorization("supplier"), Buying_pool.updateSupplierPoolSubPlan)

adminRoutes.post("/initialize_pool_sub_payment", Buying_pool.initializePoolSubPayment)

adminRoutes.get("/subscribe_to_pool_plan", Buying_pool.subscribeToPoolPlan)

adminRoutes.post("/create_buying_pool",authmiddleware.verifyToken,authmiddleware.authorization("create_pool"), filevalidatorMiddleware.imageValidator, Buying_pool.createPool)

adminRoutes.put("/update_buying_pool/:poolId",authmiddleware.verifyToken,authmiddleware.authorization("update_pool"), filevalidatorMiddleware.imageValidator, Buying_pool.updatePool)

adminRoutes.post("/update_buying_pool_Status/:poolId",authmiddleware.verifyToken,authmiddleware.authorization("update_pool"), Buying_pool.updatePoolstatus)

adminRoutes.get("/get_supplier_pool",authmiddleware.verifyToken,authmiddleware.authorization("view_supplier_pool_details"), Buying_pool.getSupplierPools)

adminRoutes.get("/get_customer_pool",authmiddleware.verifyToken,authmiddleware.authorization("view_customer_pool_details"), Buying_pool.getPoolsForCustomer)

adminRoutes.post("/initialize_join_pool_payment",authmiddleware.verifyToken,authmiddleware.authorization("view_customer_pool_details"), Buying_pool.initializePoolJoinPayment)

adminRoutes.get("/join_buying_pool",Buying_pool.verifyPoolJoinPayment)

adminRoutes.get("/withdraw_from_pool/:joinId",authmiddleware.verifyToken,authmiddleware.authorization("view_customer_pool_details"), Buying_pool.withdrawFromPool)

adminRoutes.post("/validate_pool_member_pickup/:poolId",authmiddleware.verifyToken,authmiddleware.authorization("view_supplier_pool_details"), Buying_pool.validatePickup)

adminRoutes.get("/get_pool_details_for_supplier/:poolId",authmiddleware.verifyToken,authmiddleware.authorization("view_supplier_pool_details"), Buying_pool.getPoolDetails)

adminRoutes.get("/supplier_track_pool_customer/:poolId/:type",authmiddleware.verifyToken,authmiddleware.authorization("view_supplier_pool_details"), Buying_pool.supplierTrackPoolCustomerList)

adminRoutes.get("/customer_track_pool/:poolId",authmiddleware.verifyToken,authmiddleware.authorization("view_customer_pool_details"), Buying_pool.trackCustomerPool)

adminRoutes.get("/supplier_track_pool_status/:poolId",authmiddleware.verifyToken, authmiddleware.authorization("view_supplier_pool_details"), Buying_pool.suppliertrackPoolStatus)


adminRoutes.get("/get_supplier_dashboard",authmiddleware.verifyToken, authmiddleware.authorization("supplier"), Buying_pool.getSupplierDashboard)

adminRoutes.get("/get_pool_details_by_params", Buying_pool.getPoolDetailsByParams)

adminRoutes.get("/get_all_supplier_pool", Buying_pool.getAllPoolsBySupplierId)

adminRoutes.get("/get_categories", Buying_pool.getCategory)

adminRoutes.get("/get_buyingpool_subscribers",authmiddleware.verifyToken, authmiddleware.authorization("supplier"), Buying_pool.getAllBuyingPoolSubscribers)

adminRoutes.post("/link_paystack",authmiddleware.verifyToken, authmiddleware.authorization("supplier"), Buying_pool.linkPaystack)

adminRoutes.post("/update_password_from_dashboard",authmiddleware.verifyToken, authmiddleware.authorization("supplier"), Buying_pool.updatesupplierPassword)

adminRoutes.post("/buying_pool_request_otp",Buying_pool.requestForgotPasswordOTP)

adminRoutes.post("/buying_pool_verify_otp", Buying_pool.verifyForgotPasswordOTP)

adminRoutes.post("/buying_pool_reset_forgot_password", Buying_pool.resetForgottenPassword)

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////////////////////////////////////////Logistics apis//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
adminRoutes.post("/register_logistics_agent",authmiddleware.verifyToken,authmiddleware.authorization("company"),Mycroshop_logistics.registerLogisticsAgent)

//to be added generateLogisticCompanyFormToken

adminRoutes.post("/login_logistics_agent",Mycroshop_logistics.loginLogisticsAgent)

adminRoutes.post("/register_logistics_customer",Mycroshop_logistics.registerLogisticsCustomer)

adminRoutes.post("/login_logistics_customer",Mycroshop_logistics.loginLogisticsCustomer)

adminRoutes.post("/initiate_token_payment",authmiddleware.verifyToken,authmiddleware.authorization("logistics customer"),Mycroshop_logistics.initiateTokenPayment)

adminRoutes.get("/verify_token_payment",authmiddleware.verifyToken,authmiddleware.authorization("logistics customer"),Mycroshop_logistics.verifyTokenPayment)

adminRoutes.post("/register_logistics_company",Mycroshop_logistics.registerCompany)

adminRoutes.post("/login_logistics_company",Mycroshop_logistics.loginCompany)

adminRoutes.get("/get_company_listing",authmiddleware.verifyToken,authmiddleware.authorization("company"),Mycroshop_logistics.getCompanyListings)

adminRoutes.get("/company_dashboard",authmiddleware.verifyToken,authmiddleware.authorization("company"),Mycroshop_logistics.getCompanyDashboard)

// adminRoutes.get("/company_get_agents",authmiddleware.verifyToken,authmiddleware.authorization("company"),Mycroshop_logistics.getCompanyAgents)

// adminRoutes.get("/company_get_bookings",authmiddleware.verifyToken,authmiddleware.authorization("company"),Mycroshop_logistics.getCompanyBookings)

// adminRoutes.get("/filter_company_revenue_by_location",authmiddleware.verifyToken,authmiddleware.authorization("company"),Mycroshop_logistics.filterRevenueByState)

// adminRoutes.get("/get_all_logistics_company",Mycroshop_logistics.getAllLogisticsCompanies)

adminRoutes.get("/company_agent_details_bookings",authmiddleware.verifyToken,authmiddleware.authorization("company"),Mycroshop_logistics.getAgentDetailsAndBookings)



// adminRoutes.post("/booklisting",authmiddleware.verifyToken,authmiddleware.authorization("logistics customer"),Mycroshop_logistics.bookListing)

// adminRoutes.get("/get_all_listings_for_customers",authmiddleware.verifyToken,authmiddleware.authorization("logistics customer"),Mycroshop_logistics.getAllListingsForCustomers)

// adminRoutes.post("/update_listing_status",authmiddleware.verifyToken,authmiddleware.authorization("logistics agent"),Mycroshop_logistics.updateListingStatus)

adminRoutes.post("/create_listing",authmiddleware.verifyToken,authmiddleware.authorization("logistics agent"),Mycroshop_logistics.createListing)

adminRoutes.post("/update_listing/:listingId",authmiddleware.verifyToken,authmiddleware.authorization("logistics agent"),Mycroshop_logistics.updateListing)

// adminRoutes.post("/validate_booking_by_agent",authmiddleware.verifyToken,authmiddleware.authorization("logistics agent"),Mycroshop_logistics.validateBookingByAgent)

adminRoutes.get("/logistics_agent_dashbaord_api",authmiddleware.verifyToken,authmiddleware.authorization("logistics agent"),Mycroshop_logistics.getAgentDashboardSummary)

adminRoutes.get("/get_agent_listing",authmiddleware.verifyToken,authmiddleware.authorization("logistics agent"),Mycroshop_logistics.getAgentAvailableListings)

adminRoutes.get("/get_agent_active_route",authmiddleware.verifyToken,authmiddleware.authorization("logistics agent"),Mycroshop_logistics.getAgentActiveRoutes)


// adminRoutes.get("/get_active_routes",Mycroshop_logistics.getAllActiveRoutes)

// adminRoutes.post("/request_forgot_password",Mycroshop_logistics.requestForgotPasswordOTP)

// adminRoutes.post("/verify_forgot_password",Mycroshop_logistics.verifyForgotPasswordOTP)

// adminRoutes.post("/update_password",Mycroshop_logistics.resetForgottenPassword)

////////////////////////////////////////////////////////////////end of logistics api/////////////////////////////////////////////////////////////////////////
//admin dashboard api
// adminRoutes.get("/token_login", authmiddleware.verifyToken, Users.tokenLoginapi);


// //create user
// adminRoutes.post("/create_user", authmiddleware.verifyToken,  (req, res, next) => authmiddleware.authorization(req, res, next, "create users"), Users.createUsers);

// //get list of all shops when creating or editing a user 
// adminRoutes.get("/get_shops", authmiddleware.verifyToken, Users.getShops);

// //edit user
// adminRoutes.post("/update_user", authmiddleware.verifyToken,  (req, res, next) => authmiddleware.authorization(req, res, next, "edit users"), Users.updateUser);



// //get users
// adminRoutes.get("/get_users", authmiddleware.verifyToken, Users.getAllusers)


// //update user password
// adminRoutes.post("/update_user_password", authmiddleware.verifyToken, (req, res, next) => authmiddleware.authorization(req, res, next, "edit users"), Users.updateUserPassword)

// //delete user
// adminRoutes.post("/delete_user", authmiddleware.verifyToken,  (req, res, next) => authmiddleware.authorization(req, res, next, "delete user"), Users.deleteUser);


// //get user
// adminRoutes.get("/get_users", authmiddleware.verifyToken, Users.getAllusers);


// //get user role privilege
// adminRoutes.get("/get_users_role", authmiddleware.verifyToken, Users.getAlluserrole);
// //auth route ends /////////////////////////////////////////////////////////////////


// //suppliers route//////////////////////////////////////////////////////////

// //create supplier
// adminRoutes.post("/create_supplier", authmiddleware.verifyToken,  (req, res, next) => authmiddleware.authorization(req, res, next, "create supplier"),Suppliers.Createsupplier);

// //updae user
// adminRoutes.post("/update_supplier", authmiddleware.verifyToken,  (req, res, next) => authmiddleware.authorization(req, res, next, "edit supplier"),Suppliers.Updatesupplier);

// //get all suppliers
// adminRoutes.get("/get_suppliers", authmiddleware.verifyToken,Suppliers.Getallsuppliers);


// //delete supplier
// adminRoutes.post("/delete_supplier", authmiddleware.verifyToken,  (req, res, next) => authmiddleware.authorization(req, res, next, "delete supplier"),Suppliers.Disablesupplier);


// // products/////////////////////////////////////////////////////////////

// //create category
// adminRoutes.post("/create_category", authmiddleware.verifyToken,  (req, res, next) => authmiddleware.authorization(req, res, next, "create category"), Products.createCategory);

// //update category 
// adminRoutes.post("/update_category", authmiddleware.verifyToken,   (req, res, next) => authmiddleware.authorization(req, res, next, "edit category"), Products.editCategory);

// //delete category
// adminRoutes.get("/delete_category", authmiddleware.verifyToken, (req, res, next) => authmiddleware.authorization(req, res, next, "delete category"), Products.deleteCategory);



// //get all category
// adminRoutes.get("/get_category", authmiddleware.verifyToken, Products.getAllcats);




// //create product

// adminRoutes.post("/create_product", authmiddleware.verifyToken,   (req, res, next) => authmiddleware.authorization(req, res, next, "create product"), filevalidatorMiddleware.imageValidator, Products.createProducts);



// //edit product
// adminRoutes.post("/edit_product", authmiddleware.verifyToken,   (req, res, next) => authmiddleware.authorization(req, res, next, "edit product"), filevalidatorMiddleware.imageValidator, Products.updateProducts);

// //delete product
// adminRoutes.post("/delete_product", authmiddleware.verifyToken,   (req, res, next) => authmiddleware.authorization(req, res, next, "delete product"), Products.deleteProduct);


// //get all product
// adminRoutes.get("/get_products", authmiddleware.verifyToken, Products.getAllproducts);




// //////////////////////////invoice////////////////////////////////////////////////////////
// //create invoice
// adminRoutes.post("/create_invoice",authmiddleware.verifyToken, (req, res, next) => authmiddleware.authorization(req, res, next, "create invoice"), Invoice.Createinvoice)


// //update invoice
// adminRoutes.post("/update_invoice",authmiddleware.verifyToken, (req, res, next) => authmiddleware.authorization(req, res, next, "edit invoice"), Invoice.Updateinvoice)

// //validate invoice pin
// adminRoutes.post("/validate_invoice_payment_pin",authmiddleware.verifyToken,Invoice.Validateinvoicepin)


// //cancel validate invoice pin payment method
// adminRoutes.post("/cancel_validate_invoice_pin",authmiddleware.verifyToken,Invoice.cancelUpdatepaymentstatus)

// //update invoice status
// adminRoutes.post("/update_invoice_payment_status",authmiddleware.verifyToken,(req, res, next) => authmiddleware.authorization(req, res, next, "edit invoice"),Invoice.Updateinvoicepaymentstatus)

// //get all invoice 
// adminRoutes.get("/get_allinvoice",authmiddleware.verifyToken,Invoice.getallInvoice)


// //save customer info
// adminRoutes.post("/save_customer_info",authmiddleware.verifyToken,Invoice.SavenewCustomers)

// //get all customers
// adminRoutes.get("/get_allcustomer",authmiddleware.verifyToken,Invoice.getCustomers)



// //payment list/////////////////////////////////////////////////
// adminRoutes.get("/get_allpayment",authmiddleware.verifyToken,Payment_list.getPaymentlist)

// adminRoutes.post("/validate_update_payment_pin",authmiddleware.verifyToken,Payment_list.ValidateinvoicePaymentpin)

// adminRoutes.post("/cancel_validate_update_payment_pin_process",authmiddleware.verifyToken,Payment_list.cancelUpdatePaymentstatus)

// adminRoutes.post("/update_payment_status",authmiddleware.verifyToken,(req, res, next) => authmiddleware.authorization(req, res, next, "edit invoice"),Payment_list.UpdateinvoicePaymentstatus)



// /////////////////create discount/////////////////////////
// adminRoutes.post("/create_discount",authmiddleware.verifyToken,(req, res, next) => authmiddleware.authorization(req, res, next, "create discount"),Payment_list.createDiscount)
// adminRoutes.get("/get_discount",authmiddleware.verifyToken,Payment_list.getDiscount)
// adminRoutes.post("/update_discount",authmiddleware.verifyToken,(req, res, next) => authmiddleware.authorization(req, res, next, "edit discount"),Payment_list.updateDiscount)


// /////// purchase //////////////////////////
// adminRoutes.post("/create_purchase",authmiddleware.verifyToken,(req, res, next) => authmiddleware.authorization(req, res, next, "create purchase"), Purchase.createPurchase)


// adminRoutes.post("/update_purchase",authmiddleware.verifyToken,(req, res, next) => authmiddleware.authorization(req, res, next, "edit purchase"), Purchase.updatePurchase)


// adminRoutes.get("/getall_purchase",authmiddleware.verifyToken, Purchase.getAllpurchases)



// ////////////////////////reports//////////////////////////////////////////
// adminRoutes.get("/stock_summary",authmiddleware.verifyToken, Reports.getMonthlyStockSummary)

// adminRoutes.get("/get_stock_movement",authmiddleware.verifyToken, Reports.getstockmovement)

// adminRoutes.get("/get_sales_summary_report",authmiddleware.verifyToken, Reports.getSalesSummary)

// adminRoutes.get("/get_sales_record",authmiddleware.verifyToken, Reports.getSales)





// ////////////////////////////////customers/////////////////////////

// adminRoutes.get("/get_customers",authmiddleware.verifyToken, Customers.getAllcustomers)



// ////dashboard/////////
// adminRoutes.get("/get_dashboard_summary_data",authmiddleware.verifyToken, Dashboard.getDashboardsummary)


// ///latest payment and invoice/////
// adminRoutes.get("/latest_payment_and_invoice",authmiddleware.verifyToken, Dashboard.getLatestPaymnetandInvoices)


// //sort orders///
// adminRoutes.get("/getall_orders",authmiddleware.verifyToken, Invoice.getAllsortedorders)

// adminRoutes.get("/update_orders_status",authmiddleware.verifyToken, Invoice.updateSortedstatus)



module.exports = adminRoutes;







