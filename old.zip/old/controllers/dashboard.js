// const db = require("../models");

// const Customer= db.customers
// const Op = db.Sequelize.Op;
// const  Sequelize=require('sequelize')
// const Invoice = db.invoice




// exports.getDashboardsummary = async (req, res, next)=>{
//     try {
//         const shop_id = req.query.shop_id;

//         if (!shop_id) {
//             return res.status(400).json({ message: "Shop ID is required" });
//         }

//         const sevenDaysAgo = new Date();
//         sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

//         // 🟢 Fetch Sales Data from Invoices
//         const invoices = await Invoice.findAll({
//             where: { shop_id, status: { [Op.in]: ["Paid", "Unpaid"] } },
//             attributes: ["total_amount", "products_ordered_array", "status", "date"],
//         });

//         let totalSales = 0;
//         let totalItemsSold = 0;
//         let totalOrders = invoices.length;
//         let productSalesMap = {}; // To track best-selling products
//         let last7DaysData = {}; // To store Paid vs Unpaid invoices for the last 7 days

//         // Initialize last 7 days data structure
//         for (let i = 6; i >= 0; i--) {
//             const date = new Date();
//             date.setDate(date.getDate() - i);
//             const formattedDate = date.toISOString().split("T")[0];

//             last7DaysData[formattedDate] = { Paid: 0, Unpaid: 0 };
//         }

//         for (const invoice of invoices) {
//             totalSales += invoice.status === "Paid" ? Number(invoice.total_amount) || 0 : 0;

//             // Extract the invoice date (YYYY-MM-DD)
//             const invoiceDate = new Date(invoice.date).toISOString().split("T")[0];

//             // Update Paid & Unpaid invoice totals for the last 7 days
//             if (last7DaysData[invoiceDate]) {
//                 last7DaysData[invoiceDate][invoice.status] += Number(invoice.total_amount) || 0;
//             }

//             // Process ordered products
//             const orderedProducts = JSON.parse(invoice.products_ordered_array || "[]");

//             for (const product of orderedProducts) {
//                 const { product_id, quantity, product_name } = product;
//                 totalItemsSold += Number(quantity) || 0;

//                 if (!productSalesMap[product_id]) {
//                     productSalesMap[product_id] = { name: product_name, totalSold: 0 };
//                 }
//                 productSalesMap[product_id].totalSold += Number(quantity);
//             }
//         }

//         // Fetch Total Customers
//         const totalCustomers = await Customer.count();

//         // Get Top 4 Best-Selling Products
//         const topProducts = Object.entries(productSalesMap)
//             .sort((a, b) => b[1].totalSold - a[1].totalSold) // Sort by quantity sold
//             .slice(0, 4) // Get Top 4
//             .map(([product_id, data]) => ({
//                 product_id,
//                 product_name: data.name,
//                 totalSold: data.totalSold,
//             }));

//         // Format data for the double bar chart (Paid vs Unpaid in the last 7 days)
//         const barChartData = Object.keys(last7DaysData).map(date => ({
//             date,
//             Paid: last7DaysData[date].Paid,
//             Unpaid: last7DaysData[date].Unpaid,
//         }));

//         return res.status(200).json({
//             totalSales,
//             totalItemsSold,
//             totalOrders,
//             totalCustomers,
//             bestSellingProducts: topProducts,
//             barChartData, // For the double bar chart
//         });
//     } catch (error) {
//         return res.status(500).json({ message: error.message });
//     }
// }





// //get latest payment and invoices 

// exports.getLatestPaymnetandInvoices = async (req, res, next)=>{
//      try {
//         const shop_id = req.query.shop_id;

//         if (!shop_id) {
//             return res.status(400).json({ message: "Shop ID is required" });
//         }

//         // Fetch latest payments (Paid invoices)
//         const latestPayments = await Invoice.findAll({
//             where: { shop_id, status: "Paid" },
//             order: [["date", "DESC"]],
//             limit: 7,
//             attributes: ["invoice_number", "total_amount", "date"]
//         });

//         // Fetch latest invoices (All invoices)
//         const latestInvoices = await Invoice.findAll({
//             where: { shop_id },
//             order: [["date", "DESC"]],
//             limit: 7,
//             attributes: ["invoice_number", "total_amount", "status", "date"]
//         });

//         return res.status(200).json({ latestPayments, latestInvoices });

//     } catch (error) {
//         return res.status(500).json({ message: error.message });
//     }
// }



