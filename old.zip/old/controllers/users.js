// const db = require("../models")
// const bcrypt = require("bcryptjs")
// const crypto = require("crypto");
// const jwt = require("jsonwebtoken")
// const Op = db.Sequelize.Op
// const Users = db.users
// const Privilege = db.privileges
// const Userroles = db.user_roles
// const Menus = db.menus
// const Shop = db.shop
// const key = 'hfbsybfuyerbdjshbdhsurhewiwecv'
// const disabled_users_products_and_suppliers = db.disabled_users_products_and_suppliers

// const Child_menu = db.child_menu 
// const pagination = async (items, page, per_page) => {
    
//   var page = page || 1,
//   per_page = 5,
//   offset = (page - 1) * per_page,
//   paginatedItems = items.slice(offset).slice(0, per_page),
//   total_pages = Math.ceil(items.length / per_page);
  
//   return {
//   page: page,
//   per_page: per_page,
//   pre_page: page - 1 ? page - 1 : null,
//   next_page: (total_pages > page) ? page + 1 : null,
//   total: items.length,
//   total_pages: total_pages,
//   data: paginatedItems
//   };
  
// }




// //login user
// exports.login =  async(req, res, next)=>{
//     const {login, password} = req.body
    
//     if(login && password){
//         let user
//         try{
//              user =  await Users.findOne({where: {
//         [Op.or]: [{ email: login }, { phone_number: login }]
//       }})
//         }catch(error){
//             return res.status(400).json(error);
//         }
       
//       if(user){
          
//           let rolePrivileges
          
          
//           try{
//               rolePrivileges = JSON.parse(user.role_privilege_ids)
              
//           }catch(error){
//               return res.status(400).json(error);
//           }
          
//           let userRoles
//           try{
//              userRoles = await Userroles.findOne({where:{id: user.role_type_id}})
              
//           }catch(error){
//               return res.status(400).json(error);
//           }

          
       
//           const menuIds =  JSON.parse(userRoles.menus)
          
//           const parseShopid = JSON.parse(user.shop_id)
          
//                       const checkDeletestatus =  await disabled_users_products_and_suppliers.findOne({where: { type: "user", type_id: user.id ,shop_id: { [Op.in]:parseShopid} }})
//              const filteredShopIds = checkDeletestatus?.shop_id
//     ? parseShopid.filter((id) => id !== checkDeletestatus.shop_id)
//     : parseShopid;
             
             
//           const userassignedShops = await Shop.findAll({
//   where: { id: { [Op.in]:filteredShopIds} }
// });

           
           
           
           
           
//           const Menunames = await Menus.findAll({
//   where: { id: { [Op.in]: menuIds} },
//   attributes: ['id','menu_name'] // Specify the attributes to include
// });

// let finalmenuResult = []
// for(const menuData of Menunames){
    
//     const childMenu = await Child_menu.findAll({where:{parent_id : menuData.id }})
//     const result = {
//         "parent_menu": menuData,
//         "child_menu": childMenu
//     }
    
//     finalmenuResult.push(result)
// }

//           const Privileges = await Privilege.findAll({
//   where: { id: { [Op.in]: rolePrivileges } },
//   attributes: ['privileges'] // Specify the attributes to include
// });
          
           
//           const unhashpassword = bcrypt.compareSync(password, user.password);
              
//               if(!unhashpassword){
//                   return res.status(404).json({message:"Incorrect password"})
//               }
              
              
//              let payload = {id : user.id,
//                           user_name : user.user_name,
//                           email : user.email,
//                           phone_number : user.phone_number,
//                           role_type : userRoles.role_type,
//                           menus : finalmenuResult,
//                           privileges : Privileges,
//                           shops : userassignedShops
//              };
                     
//               const token = jwt.sign(payload, 'htrenxenxnx2xx2j2i3ijeuy36xmaexuioajnxew');
              
//               return res.status(200).json({message:"login successful", token: token, user: payload});
//       }else{
//           return res.status(400).json({message:"no user found"});
//       }
//     }
   
//   return res.status(400).json({message: "All fields are required"})
   
// }

// //user dashboard api
// exports.tokenLoginapi= async (req, res, next)=>{
    
//     const userID = req.user.id
    
     
//      let user
//         try{
//              user =  await Users.findOne({where: {id:userID}})
//         }catch(error){
//             return res.status(400).json(error);
//         }
       
//       if(user){
          
//           let rolePrivileges
          
          
//           try{
//               rolePrivileges = JSON.parse(user.role_privilege_ids)
              
//           }catch(error){
//               return res.status(400).json(error);
//           }
          
//           let userRoles
//           try{
//              userRoles = await Userroles.findOne({where:{id: user.role_type_id}})
              
//           }catch(error){
//               return res.status(400).json(error);
//           }

          
       
//           const menuIds =  JSON.parse(userRoles.menus)
          
//           const parseShopid = JSON.parse(user.shop_id)
          
//                       const checkDeletestatus =  await disabled_users_products_and_suppliers.findOne({where: { type: "user", type_id: user.id ,shop_id: { [Op.in]:parseShopid} }})
//              const filteredShopIds = checkDeletestatus?.shop_id
//     ? parseShopid.filter((id) => id !== checkDeletestatus.shop_id)
//     : parseShopid;
             
             
//           const userassignedShops = await Shop.findAll({
//   where: { id: { [Op.in]:filteredShopIds} }
// });


//           const Menunames = await Menus.findAll({
//   where: { id: { [Op.in]: menuIds} },
//   attributes: ['id','menu_name'] // Specify the attributes to include
// });

// let finalmenuResult = []
// for(const menuData of Menunames){
    
//     const childMenu = await Child_menu.findAll({where:{parent_id : menuData.id }})
//     const result = {
//         "parent_menu": menuData,
//         "child_menu": childMenu
//     }
    
//     finalmenuResult.push(result)
// }
//           const Privileges = await Privilege.findAll({
//   where: { id: { [Op.in]: rolePrivileges } },
//   attributes: ['privileges'] // Specify the attributes to include
// });
          
           
         
              
//              let payload = {id : user.id,
//                           user_name : user.user_name,
//                           email : user.email,
//                           phone_number : user.phone_number,
//                           role_type : userRoles.role_type,
//                           menus : finalmenuResult,
//                           privileges : Privileges,
//                           shops : userassignedShops
//              };
                     
              
              
//               return res.status(200).json({message:"login successful", user: payload});
//       }else{
//           return res.status(400).json({message:"no user found"});
//       }
// }
// //create user    
// exports.createUsers = async (req, res, next)=> {
//           const {user_name,email, phone_number,role_type_id, role_privilege_ids, password,shop_id} = req.body
          
          
//           if(user_name && email && phone_number && role_type_id && role_privilege_ids.length > 0 && password && shop_id.length > 0){
              
              
//               const hashPassword = bcrypt.hashSync(password)
              
              
//               const stringifyShopids =  JSON.stringify(shop_id)
              
//               const stringifiedrole_privilege_ids = JSON.stringify(role_privilege_ids)
              
//               let checkDuplicate
//               for(const value of shop_id){
//                   checkDuplicate = await Users.findOne({where:{email: email, user_name: user_name, phone_number:phone_number, shop_id:  value}})
//                   if(checkDuplicate){
//                       break
//                   }
                   
                   
//               }
              
              
              
//               if(checkDuplicate){
//                  return res.status(400).json({message: "duplicate record"}) 
//               }
//               try{
//                   await Users.create({
//                     user_name,
//                     email,
//                     phone_number,
//                     role_type_id,
//                     role_privilege_ids:stringifiedrole_privilege_ids,
//                     password: hashPassword,
//                     shop_id : stringifyShopids
//                   })
                  
//                   return res.status(200).json({message:"user created  successfully"});
//               }catch(error){
//                   return res.status(400).json(error);
//               }
              
//           }
          
//           return res.status(400).json({message:"All fields are required"});
           
// }
// //get list of shops

// exports.getShops = async (req, res, next)=>{
//     const allShops = await Shop.findAll()
    
//     return res.status(200).json(allShops);
// }

// //update user info
// exports.updateUser = async (req, res, next)=>{
//      const {id,user_name,email, phone_number,role_type_id, role_privilege_ids, password, shop_id} = req.body
     
//      if(id && user_name && email && phone_number && role_type_id && role_privilege_ids.length > 0 && password && shop_id.length > 0){
         
         
              
//               const stringifiedrole_privilege_ids = JSON.stringify(role_privilege_ids)
              
//               const stringifyShopids =  JSON.stringify(shop_id)
              
              
             
              
              
//          try{
//              await Users.update({
//                     user_name,
//                     email,
//                     phone_number,
//                     role_type_id,
//                     role_privilege_ids:stringifiedrole_privilege_ids,
//                     shop_id : stringifyShopids
                    
//              },{where:{id : id}})
//               return res.status(200).json({message:"user updated  successfully"});
//          }catch(error){
//                   return res.status(400).json(error);
//               }
         
//      }
     
//      return res.status(400).json({message:"All fields are required"});
     
// }

// //updateuserPassword

// exports.updateUserPassword = async (req, res, next) => {
//     const {id,password} = req.body
    
//     if(password && id){
//         const hashPassword = bcrypt.hashSync(password)
        
//         await Users.update({password: hashPassword},{where:{id: id}})
        
//         return res.status(200).json({message:"user password updated  successfully"})
//         }
//     return res.status(400).json({message:"All fields are required"});

// }


// //get all users

// exports.getAllusers = async (req, res, next)=>{
    
//     const shopId = Number(req.query.shop_id)
    
//     if(!shopId){
//         return res.status(400).json({message:"All fields are required"});
//     }
//      const allUsers = await Users.findAll();

//     const filteredUsers = await Promise.all(
//       allUsers.map(async (user) => {
//         const shopIds = JSON.parse(user.shop_id);

//         // Check if user is disabled for this shop (asynchronously)
//         const isDisabled = await disabled_users_products_and_suppliers.findOne({
//           where: {
//             type: "user",
//             type_id: user.id,
//             shop_id: shopId,
//           },
//         });

//         return shopIds.includes(shopId) && !isDisabled ? user : null;
//       })
//     );

//     // Filter out null values after Promise.all resolves
   
//     const filteredUserarray = filteredUsers.filter(Boolean)
//     let usersArray = []
//     for(const user of filteredUserarray){
        
//              let rolePrivileges = JSON.parse(user.role_privilege_ids)
              
//           let   userRoles = await Userroles.findOne({where:{id: user.role_type_id}})
              
        
       
//           const menuIds =  JSON.parse(userRoles.menus)
//           const parseShopid = JSON.parse(user.shop_id)
          
                      
//               const checkDeletestatus =  await disabled_users_products_and_suppliers.findOne({where: { type: "user", type_id: user.id ,shop_id: { [Op.in]:parseShopid} }})
              
//              const filteredShopIds = checkDeletestatus?.shop_id
//     ? parseShopid.filter((id) => id !== checkDeletestatus.shop_id)
//     : parseShopid;
          
//           const userassignedShops = await Shop.findAll({
//   where: { id: { [Op.in]:filteredShopIds} }
// });

//           const Menunames = await Menus.findAll({
//   where: { id: { [Op.in]: menuIds} },
//   attributes: ['id','menu_name'] // Specify the attributes to include
// });


//           const Privileges = await Privilege.findAll({
//   where: { id: { [Op.in]: rolePrivileges } },
//   attributes: ['id','privileges'] // Specify the attributes to include
// });

//  let Userspayload = {id : user.id,
//                           user_name : user.user_name,
//                           email : user.email,
//                           phone_number : user.phone_number,
//                           role_type : {
//                               role_type_id : userRoles.id,
//                               role : userRoles.role_type
//                           },
//                           menus : Menunames,
//                           privileges : Privileges,
//                           assigned_shop: userassignedShops
                           
//              };

//   usersArray.push(Userspayload)
         
         

//     }
//     return res.status(200).json(usersArray)
// }

// //disable user
// exports.deleteUser = async (req, res, next)=>{
//      const {user_id, shop_id} = req.body
     
//       if(!user_id && !shop_id){
//          return res.status(400).json({message:"All fields are required"});
//      }
     
//      if(user_id == 1){
//           return res.status(400).json({message: "system user can not be deleted"});
//      }
     
//     //duplicate 
//     const checkDuplicate = await disabled_users_products_and_suppliers.findOne({where:{shop_id: shop_id,
//          type : "user",
//          type_id :user_id}})
         
//     if(checkDuplicate){
//         return res.status(200).json({message:"user deleted"})
//     }
    
//      try{
//          await disabled_users_products_and_suppliers.create({
//          shop_id,
//          type : "user",
//          type_id :user_id
//      })
//      return res.status(200).json({message:"user deleted"})
//      }catch(error){
//               return res.status(400).json(error);
//           }
          
    
// }

// //get all user role
// exports.getAlluserrole = async (req, res, next)=>{
    
//       res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
//                   res.setHeader('Pragma', 'no-cache');
//                   res.setHeader('Expires', '0')
                  
//               const  userRoles = await Userroles.findAll()
              
//               const userRolesarray = []
              
//               for(const value of userRoles){
//                   const privilegeData =await Privilege.findAll({where:{role_type_id: value.id}, attributes : ['id','privileges']})
                  
//                       const data = {
//                           role_id : value.id,
//                           role_type : value.role_type,
//                           privileges : privilegeData
//                       }
                      
//                       userRolesarray.push(data)
//               }
              
//               return res.status(200).json(userRolesarray)
// }







