


// exports.createOrUpdateStore = async (req, res) => {
//     const business_id = req.user.id;
//     const { store_name, store_username, store_description, social_media_links, location, allow_delivery_date_and_time_incheckout } = req.body;
    
//     try {
//         let store = await Business_online_store_front.findOne({ where: { business_id } });
//         const storeData = { business_id, store_name, store_username, store_description, social_media_links, location, allow_delivery_date_and_time_incheckout: !!allow_delivery_date_and_time_incheckout };

//         if (store) {
//             await store.update(storeData);
//         } else {
//             store = await Business_online_store_front.create(storeData);
//         }
//         return res.status(200).json({ message: "Store information saved.", store });
//     } catch (error) {
//         return res.status(500).json({ message: "An error occurred.", error: error.message });
//     }
// };

// /**
//  * Gets the storefront information for the logged-in business.
//  */
// exports.getStore = async (req, res) => {
//     const business_id = req.user.id;
//     try {
//         const store = await Business_online_store_front.findOne({ where: { business_id } });
//         if (!store) {
//             return res.status(404).json({ message: "Storefront not found." });
//         }
//         return res.status(200).json(store);
//     } catch (error) {
//         return res.status(500).json({ message: "An error occurred.", error: error.message });
//     }
// };


// // --- Store Appearance Management ---

// /**
//  * Updates the visual appearance of the storefront (logos, banners, colors).
//  */
// exports.updateStoreAppearance = async (req, res) => {
//     const business_id = req.user.id;
//     const { store_id } = req.params;
//     const { background_color, button_style, button_color, button_font_color } = req.body;

//     try {
//         const store = await Business_online_store_front.findOne({ where: { id: store_id, business_id } });
//         if (!store) {
//             return res.status(403).json({ message: "Forbidden: You do not own this store." });
//         }

//         const updateData = { background_color, button_style, button_color, button_font_color };

//         if (req.files) {
//             if (req.files.profile_image) updateData.store_profile_image = req.files.profile_image[0].filename;
//             if (req.files.banner_image) updateData.banner_image = req.files.banner_image[0].filename;
//             if (req.files.background_image) updateData.background_image = req.files.background_image[0].filename;
//         }

//         await store.update(updateData);
//         return res.status(200).json({ message: "Store appearance updated.", store });
//     } catch (error) {
//         return res.status(500).json({ message: "An error occurred.", error: error.message });
//     }
// };


// // --- Service Management ---

// /**
//  * Creates a new service for a business's storefront.
//  */
// exports.createService = async (req, res) => {
//     const business_id = req.user.id;
//     const { store_id } = req.params;
//     const { service_title, service_description, service_price, service_duration, availability, location, call_to_action } = req.body;
    
//     try {
//         const store = await Business_online_store_front.findOne({ where: { id: store_id, business_id } });
//         if (!store) {
//             return res.status(403).json({ message: "Forbidden: You do not own this store." });
//         }

//         const serviceData = { business_id, store_id, service_title, service_description, service_price: parseFloat(service_price), service_duration, availability, location, call_to_action };
//         if (req.file) {
//             serviceData.service_image = req.file.filename;
//         }
        
//         const newService = await Business_online_store_services.create(serviceData);
//         return res.status(201).json({ message: "Service created.", service: newService });
//     } catch (error) {
//         return res.status(500).json({ message: "An error occurred.", error: error.message });
//     }
// };

// /**
//  * Gets all services for a specific store.
//  */
// exports.getServicesByStore = async (req, res) => {
//     const { store_id } = req.params;
//     try {
//         const services = await Business_online_store_services.findAll({ where: { store_id } });
//         return res.status(200).json(services);
//     } catch (error) {
//         return res.status(500).json({ message: "An error occurred.", error: error.message });
//     }
// };

// /**
//  * Updates an existing service.
//  */
// exports.updateService = async (req, res) => {
//     const business_id = req.user.id;
//     const { service_id } = req.params;

//     try {
//         const service = await Business_online_store_services.findOne({ where: { id: service_id, business_id } });
//         if (!service) {
//             return res.status(404).json({ message: "Service not found or you do not have permission to edit it." });
//         }
        
//         const updateData = { ...req.body };
//         if (req.file) {
//             updateData.service_image = req.file.filename;
//         }

//         await service.update(updateData);
//         return res.status(200).json({ message: "Service updated successfully.", service });
//     } catch (error) {
//         return res.status(500).json({ message: "An error occurred.", error: error.message });
//     }
// };

// /**
//  * Deletes a service.
//  */
// exports.deleteService = async (req, res) => {
//     const business_id = req.user.id;
//     const { service_id } = req.params;

//     try {
//         const result = await Business_online_store_services.destroy({ where: { id: service_id, business_id } });
//         if (result === 0) {
//             return res.status(404).json({ message: "Service not found or you do not have permission to delete it." });
//         }
//         // You may also need to remove this service from any collections it's part of.
//         await Collection_items.destroy({ where: { item_id: service_id, item_type: 'service' } });
//         return res.status(200).json({ message: "Service deleted successfully." });
//     } catch (error) {
//         return res.status(500).json({ message: "An error occurred.", error: error.message });
//     }
// };


// // --- Store Product Management ---

// /**
//  * Gets all of a business's existing inventory products.
//  */
// exports.getBusinessInventory = async (req, res) => {
//     const business_id = req.user.id;
//     try {
//         const productLinks = await Business_product_pivot_table.findAll({ where: { business_id }, attributes: ['product_id'] });
//         const productIds = productLinks.map(p => p.product_id);
//         const products = await Product.findAll({ where: { id: productIds } });
//         return res.status(200).json(products);
//     } catch (error) {
//         return res.status(500).json({ message: "An error occurred.", error: error.message });
//     }
// };

// /**
//  * Adds selected inventory products to the online store.
//  */
// exports.addProductsToStore = async (req, res) => {
//     const business_id = req.user.id;
//     const { store_id } = req.params;
//     const { product_ids } = req.body;

//     if (!Array.isArray(product_ids) || product_ids.length === 0) {
//         return res.status(400).json({ message: "product_ids must be a non-empty array." });
//     }

//     try {
//         const store = await Business_online_store_front.findOne({ where: { id: store_id, business_id } });
//         if (!store) { return res.status(403).json({ message: "Forbidden." }); }

//         const links = product_ids.map(product_id => ({ business_id, store_id, product_id }));
//         await Business_online_store_products.bulkCreate(links, { ignoreDuplicates: true });
//         return res.status(200).json({ message: "Products added to store." });
//     } catch (error) {
//         return res.status(500).json({ message: "An error occurred.", error: error.message });
//     }
// };

// /**
//  * Gets all products currently listed on a specific online store.
//  */
// exports.getStoreProducts = async (req, res) => {
//     const { store_id } = req.params;
//     try {
//         const storeProducts = await Business_online_store_products.findAll({
//              where: { store_id },
//              include: [Product]
//         });
//         return res.status(200).json(storeProducts);
//     } catch (error) {
//         return res.status(500).json({ message: "An error occurred.", error: error.message });
//     }
// };


// // --- Collection Management ---

// /**
//  * Creates a new collection and links products AND/OR services to it.
//  */
// exports.createCollection = async (req, res) => {
//     const business_id = req.user.id;
//     const { store_id } = req.params;
//     const { collection_name, description, items } = req.body;

//     const transaction = await sequelize.transaction();
//     try {
//         const store = await Business_online_store_front.findOne({ where: { id: store_id, business_id } });
//         if (!store) {
//             await transaction.rollback();
//             return res.status(403).json({ message: "Forbidden." });
//         }
        
//         const newCollection = await Business_online_store_collection.create({ business_id, store_id, collection_name, description }, { transaction });

//         if (Array.isArray(items) && items.length > 0) {
//             const links = items.map(item => ({ business_id, store_id, collection_id: newCollection.id, item_id: item.id, item_type: item.type }));
//             await Collection_items.bulkCreate(links, { transaction });
//         }

//         await transaction.commit();
//         return res.status(201).json({ message: "Collection created.", collection: newCollection });
//     } catch (error) {
//         await transaction.rollback();
//         return res.status(500).json({ message: "An error occurred.", error: error.message });
//     }
// };

// /**
//  * Updates a collection's name, description, and its linked items.
//  */
// exports.updateCollection = async (req, res) => {
//     const business_id = req.user.id;
//     const { collection_id } = req.params;
//     const { collection_name, description, items } = req.body;

//     const transaction = await sequelize.transaction();
//     try {
//         const collection = await Business_online_store_collection.findOne({ where: { id: collection_id, business_id } });
//         if (!collection) {
//             await transaction.rollback();
//             return res.status(404).json({ message: "Collection not found." });
//         }

//         await collection.update({ collection_name, description }, { transaction });
//         await Collection_items.destroy({ where: { collection_id }, transaction });

//         if (Array.isArray(items) && items.length > 0) {
//             const links = items.map(item => ({ business_id, store_id: collection.store_id, collection_id: collection.id, item_id: item.id, item_type: item.type }));
//             await Collection_items.bulkCreate(links, { transaction });
//         }

//         await transaction.commit();
//         return res.status(200).json({ message: "Collection updated." });
//     } catch (error) {
//         await transaction.rollback();
//         return res.status(500).json({ message: "An error occurred.", error: error.message });
//     }
// };

// /**
//  * Gets all collections and their linked items for a store.
//  */
// exports.getCollectionsByStore = async (req, res) => {
//     const { store_id } = req.params;
//     try {
//         const collections = await Business_online_store_collection.findAll({
//             where: { store_id },
//             include: [{ model: Collection_items, attributes: ['item_id', 'item_type'] }]
//         });
//         return res.status(200).json(collections);
//     } catch (error) {
//         return res.status(500).json({ message: "An error occurred.", error: error.message });
//     }
// };

// /**
//  * Deletes a collection.
//  */
// exports.deleteCollection = async (req, res) => {
//     const business_id = req.user.id;
//     const { collection_id } = req.params;

//     const transaction = await sequelize.transaction();
//     try {
//         // First, delete the collection itself, ensuring ownership
//         const result = await Business_online_store_collection.destroy({ where: { id: collection_id, business_id }, transaction });
//         if (result === 0) {
//             await transaction.rollback();
//             return res.status(404).json({ message: "Collection not found or you do not have permission to delete it." });
//         }
        
//         // Then, delete all items that were linked to it
//         await Collection_items.destroy({ where: { collection_id }, transaction });
        
//         await transaction.commit();
//         return res.status(200).json({ message: "Collection deleted successfully." });
//     } catch (error) {
//         await transaction.rollback();
//         return res.status(500).json({ message: "An error occurred.", error: error.message });
//     }
// }