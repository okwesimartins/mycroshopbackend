// const db = require("../models");

// const Customers = db.customers
// const Op = db.Sequelize.Op;

// const pagination = async (items, page) => {

//   var page = page || 1,
//   per_page = 10,
//   offset = (page - 1) * per_page,
//   paginatedItems = items.slice(offset).slice(0, per_page),
//   total_pages = Math.ceil(items.length / per_page);
  
//   return {
//   page: page,
//   per_page: per_page,
//   pre_page: page - 1 ? page - 1 : null,
//   next_page: (total_pages > page) ? page + 1 : null,
//   total: items.length,
//   total_pages: total_pages,
//   data: paginatedItems
//   };
  
// }







// exports.getAllcustomers = async (req, res, next)=>{
//      const search_value = req.query.search_value
     
//      try{
//       let page = 0;
//             const pagenumber = req.query.page;
            
//             if(pagenumber == 0 || pagenumber > 0){
              
//             if(!Number.isNaN(pagenumber) && pagenumber > 0 ){
//                 page = pagenumber;
//             }
            
//             }
            
//      if(search_value){
         
//          const Customerdata = await Customers.findAll({
//       where: {
//         [Op.or]: [
//           { name: { [Op.like]: `%${search_value}%` } },
//           { phone_number : { [Op.like]: `%${search_value}%` } },
//           { email: search_value},
//         ]
//       }
//     })
    
   
    
//      if(pagenumber == "All"){
//               return res.status(200).json(Customerdata)
//          }
//          const paginatedData = await pagination( Customerdata, page)
         
//     return res.status(200).json(paginatedData)
    
//      }
      
      
//              const getCustomerdata = await Customers.findAll({attributes:['id','name','phone_number','email']}) 
//       if(pagenumber == "All"){
//           return res.status(200).json(getCustomerdata)
//          }
//          const paginatedData = await pagination( getCustomerdata, page)
         
//     return res.status(200).json(paginatedData)
      
 
    
//      } catch (error) {
//         return res.status(500).json({ message: error.message });
//     }

// }

