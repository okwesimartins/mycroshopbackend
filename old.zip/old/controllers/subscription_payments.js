const db = require("../models");
const axios = require('axios');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const dayjs = require('dayjs');
const Business = db.business
const Subscription_plans = db.subscription_plans
const Subscription_payments = db.subscription_payments
const Business_notifications = db.business_notifications
const ejs = require('ejs');
const path = require('path');
const fs = require('fs');
const  Sequelize= db.sequelize

const { sendEmailWithTemplate } = require('../service/mail-services.js');

const PAYSTACK_BASE_URL = 'https://api.paystack.co';

const headers = {
  'Authorization': 'Bearer sk_test_0255f1f40367a9712aba18e65864b3440d10d879',
  'Content-Type': 'application/json',
};

exports.subscribeToPlan = async(req, res, next)=> {
  try {
    const { email, phone_number,business_user_name, name, plan_id } = req.body;

    const plan = await Subscription_plans.findOne({where:{id:plan_id}});
    if (!plan) return res.status(404).json({ message: 'Subscription plan not found' });

    const existingBusiness = await Business.findOne({ where: { email } });
    let amountToPay = parseInt(plan.yearly_fee);
    let business_id = null;
    let upgradeFromPlan = null;

    if (existingBusiness) {
      business_id = existingBusiness.id;

      // Check if an active subscription exists
      const currentSub = await Subscription_payments.findOne({
        where: { business_id, status: 'active' },
        order: [['date', 'DESC']],
      });

      if (currentSub) {
        const currentPlan = await Subscription_plans.findByPk(currentSub.subscription_plan_id);
        const daysLeft = dayjs(currentSub.expiration_date).diff(dayjs(), 'day');
        const unusedValue = (daysLeft / 365) * parseInt(currentPlan.yearly_fee);

        // Prorated balance
        amountToPay = Math.max(amountToPay - Math.floor(unusedValue), 0);
        upgradeFromPlan = currentPlan.plan_name;
      }
    }

    const metadata = {
      email,
      plan_id,
      is_existing: !!existingBusiness,
      business_id,
      name,
      phone_number
    };

    const paystackRes = await axios.post(`${PAYSTACK_BASE_URL}/transaction/initialize`, {
      email,
      amount: amountToPay * 100,
      metadata,
      callback_url: `https://mycroshop.com`,
    }, { headers });

    return res.status(200).json({
      message: existingBusiness ? 'Redirect for upgrade payment' : 'Redirect for registration payment',
      authorization_url: paystackRes.data.data.authorization_url,
      upgrade_from: upgradeFromPlan || null,
    });
  } catch (error) {
    return res.status(500).json({message: error.message})
  }
}

//verify payments
exports.verifyPayment = async (req, res, next) => {
  const { reference } = req.query;
  
       const transaction = await Sequelize.transaction()
       
     
  
   
  try {
      
    const response = await axios.get(`${PAYSTACK_BASE_URL}/transaction/verify/${reference}`, { headers });
    const paymentData = response.data.data;

    if (paymentData.status !== 'success') {
      return res.status(400).json({ message: 'Payment not successful' });
    }

    const { email, plan_id, is_existing, business_id,business_user_name, name, phone_number } = paymentData.metadata;
    const plan = await Subscription_plans.findByPk(plan_id);
    if (!plan) return res.status(404).json({ message: 'Plan not found after payment' });

    let business = null;
    let tempPassword = null;
     const isExisting = String(is_existing).toLowerCase() === 'true';
     
    if (isExisting) {
      business = await Business.findOne({where:{id:business_id}});
       if (!business) throw new Error('Existing business not found')
    }else{
        tempPassword = crypto.randomBytes(4).toString('hex');
      const hashedPassword = await bcrypt.hash(tempPassword, 10);
    //   const uniqueUsername = email.split('@')[0] + Math.floor(Math.random() * 10000);
     if (!email || !name || !phone_number) throw new Error('Missing registration data');
     
      business = await Business.create({
        name,
        email,
        phone_number,
        password: hashedPassword,
        status: 'active',
        date: dayjs().format('YYYY-MM-DD'),
        business_user_name: business_user_name,
        business_category: 'general', // or get from req.body if needed
      },{ transaction });
    }
    
    if (!business || !business.id) {
  throw new Error('Business record not created or found.');
}
    

    const expirationDate = dayjs().add(1, 'year').format('YYYY-MM-DD');

    await Subscription_payments.create({
      subscription_plan_id: plan_id,
      payment_reference: reference,
      business_id: business.id,
      status: 'active',
      date: dayjs().format('YYYY-MM-DD'),
      expiration_date: expirationDate
    },{ transaction });


    if (tempPassword) {
        // Render HTML email content from EJS template manually
const templatePath = path.join(__dirname, '../service/templates/loginDetailsEmail.ejs');
const emailHtml = await ejs.renderFile(templatePath, {
  name: business.name,
  email: business.email,
  password: tempPassword
});

     // Send email
const emailSent = await sendEmailWithTemplate(
   business.email,
  'Welcome to Mycroshop',
   emailHtml
);

// Log full HTML to business_notifications
await Business_notifications.create({
  message: emailHtml,
  business_id: business.id,
  business_type: "vendor",
  sent_status: emailSent ? 1 : 0,
},{ transaction });
    }
    await transaction.commit() 
    return res.status(200).json({ message: 'Subscription successful', business_id: business.id });
  } catch (error) {
       await transaction.rollback();
   return res.status(500).json({message: error});
  }
}


