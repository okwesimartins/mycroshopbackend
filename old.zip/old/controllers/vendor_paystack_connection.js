



// CONTROLLER FUNCTIONS

exports.generatePaystackConnectUrl = async (req, res) => {
  const companyId = req.user.id;

  try {
    const company = await LogisticsCompanies.findByPk(companyId);
    const connect_url = `https://connect.paystack.com/authorize?client_id=${PAYSTACK_CLIENT_ID}&redirect_uri=https://yourdomain.com/api/logistics/paystack-connect/callback&response_type=code&scope=read_write`;
    return res.status(200).json({ connect_url });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

const paystackConnectCallback = async (req, res) => {
  const { code } = req.query;

  try {
    const response = await axios.post(
      'https://api.paystack.co/merchant/oauth/token',
      {
        client_id: PAYSTACK_CLIENT_ID,
        client_secret: PAYSTACK_SECRET,
        code
      },
      {
        headers: { 'Content-Type': 'application/json' }
      }
    );

    const { access_token, account_id } = response.data.data;
    const user = req.user;

    const company = await LogisticsCompanies.findByPk(user.id);
    company.paystack_account_id = account_id;
    company.paystack_access_token = access_token;
    await company.save();

    return res.status(200).json({ message: "success" });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};



