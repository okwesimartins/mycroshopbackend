// const db = require("../models")
// const Purchase =  db.purchase
// const Op = db.Sequelize.Op;
// const  Sequelize=require('sequelize')
// const bcrypt = require("bcryptjs")
// const stock_movement = db.stock_movement
// const stock_summary = db.stock_summary
// const Products = db.products
// const Suppliers =  db.suppliers

// const pagination = async (items, page) => {

//   var page = page || 1,
//   per_page = 10,
//   offset = (page - 1) * per_page,
//   paginatedItems = items.slice(offset).slice(0, per_page),
//   total_pages = Math.ceil(items.length / per_page);
  
//   return {
//   page: page,
//   per_page: per_page,
//   pre_page: page - 1 ? page - 1 : null,
//   next_page: (total_pages > page) ? page + 1 : null,
//   total: items.length,
//   total_pages: total_pages,
//   data: paginatedItems
//   };
  
// }


// exports.createPurchase = async (req, res, next)=>{
//       const {product_id, product_quantity, supplier, inches, shop_id} = req.body
      
//       if(!product_id || !product_quantity || !supplier || !shop_id){
//              return res.status(400).json({message: "All fields are required"})
//       }
//                       //validate product id
//                      const getproductDetails = await Products.findOne({where:{id:  product_id}})
//                      const getpreviouseProductinchesdata = JSON.parse(getproductDetails.inches)
                     
//                      let date_ob = new Date();
//                 let date = ("0" + date_ob.getDate()).slice(-2);
//                 let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
//                 let year = date_ob.getFullYear();
//                 const date_recorded = year + "-" + month + "-" + date;
//                      if(!getproductDetails){
//                          return res.status(400).json({message: "invalid product id passed"})
//                      }
                     
//                      try{
//                           if(getpreviouseProductinchesdata.length > 0){
              
//               let totalStock = 0
//               const newProductincharray = await Promise.all(getpreviouseProductinchesdata.map(async data =>{
//                   if(data.inche == inches){
                      
//                       const quantityIncreasedby = "+" + product_quantity
//                       data.stock = Number(data.stock) + Number(product_quantity)
                      
//                      const lastMovement = await stock_movement.findOne({where:{product_id:product_id,inch: inches, shop_id:shop_id},  order: [['movement_date', 'DESC']]})
                         
//                          const lastBalance = lastMovement ? lastMovement.balance : getproductDetails.total_product_stock
                         
//                          const newBalance = Number(lastBalance) + Number(product_quantity)
//                         await stock_movement.create({
//                         product_id :  product_id,
//                         movement_type :"purchase",
//                         movement_reason	: "New items purchased",
//                         inch: inches,
//                         quantity :  quantityIncreasedby,
//                         balance :  newBalance,
//                         movement_date : date_recorded,
//                         shop_id : shop_id
//                     })
                    
//                   }
//                   totalStock += parseInt(data.stock)
                  
//                   return data
//               }))
                     
                 
//           const totalStockValue = newProductincharray.reduce((total, p) => total + (parseInt(p.buying_price) * parseInt(p.stock)), 0)
                 
//     const updatedInchesJSON = JSON.stringify(newProductincharray)
//               await Products.update({inches: updatedInchesJSON,
//                                 total_product_stock: totalStock,
//                                 total_stock_value:totalStockValue },{where:{id: product_id}})
                      
                    
              
          
//           }
          
//                      if(getpreviouseProductinchesdata.length == 0){
                         
//                          const quantityIncreasedby = "+" + product_quantity
                
                                    
//                                          const lastMovement = await stock_movement.findOne({where:{product_id:product_id,inch: inches, shop_id:shop_id},  order: [['movement_date', 'DESC']]})
//                                          const lastBalance = lastMovement ? lastMovement.balance : getproductDetails.total_product_stock
                         
//                                          const newBalance = Number(lastBalance) + Number(product_quantity)
//                                       const  getTotalproductstock = Number(getproductDetails.total_product_stock) + Number(product_quantity)
                                    
                               
                               
//                                 const newStockvalue = Number(getproductDetails.total_buying_price) * getTotalproductstock
                                
//                               await Products.update({total_product_stock: getTotalproductstock,total_stock_value:newStockvalue },{where:{id: product_id}})
                            
                            
//                           await stock_movement.create({
//                         product_id :  product_id,
//                         movement_type :"purchase",
//                         movement_reason	: "New items purchased",
//                         quantity :  quantityIncreasedby,
//                         balance :  newBalance,
//                         movement_date : date_recorded,
//                         shop_id : shop_id
//                     })
                    
                   
//                      }
//                      }catch(error){
//                          return res.status(400).json({message: error.message})
//                      }
         
//       try{
          
//           await Purchase.create({
//               product_id,
//               product_quantity,
//               supplier,
//               inches,
//               created_by :  req.user.user_name,
//               date : date_recorded,
//               shop_id : shop_id
//           })
          
//           return res.status(200).json({message:"purchase recorded"})
//       }catch(error){
//             return res.status(400).json(error)
//       }
// }




// //update purchase data

// exports.updatePurchase = async (req, res, next) => {
//   const { purchase_id, product_id, product_quantity, supplier, inches, shop_id } = req.body;

//   if (!purchase_id || !product_id || !product_quantity || !supplier || !shop_id) {
//     return res.status(400).json({ message: "All fields are required" });
//   }

//   // 1. Fetch existing purchase and product
//   const purchase = await Purchase.findOne({ where: { id: purchase_id, shop_id } });
//   if (!purchase) return res.status(400).json({ message: "Invalid purchase ID" });

//   const product = await Products.findOne({ where: { id: product_id } });
//   if (!product) return res.status(400).json({ message: "Invalid product ID" });

//   const prevQuantity = Number(purchase.product_quantity); // quantity that was previously recorded
//   const newQuantity = Number(product_quantity); // new quantity being updated
//   const quantityDiff = newQuantity - prevQuantity;

//   const date = new Date().toISOString().split('T')[0]; // "YYYY-MM-DD"

//   try {
//     // =========================
//     // PRODUCT HAS INCHES
//     // =========================
//     if (product.inches) {
//       const inchesArray = typeof product.inches === 'string' ? JSON.parse(product.inches) : product.inches;
//       let updatedTotalStock = 0;
//       const updatedInches = inchesArray.map((item) => {
//         if (item.inche == inches) {
//           // REMOVE previous quantity first
//           item.stock = Number(item.stock) - prevQuantity;

//           // ADD the new quantity
//           item.stock = Number(item.stock) + newQuantity;
//         }

//         updatedTotalStock += Number(item.stock);
//         return item;
//       });

//       const updatedStockValue = updatedInches.reduce((sum, entry) => {
//         return sum + (Number(entry.stock) * Number(entry.buying_price));
//       }, 0);

//       await Products.update({
//         inches: JSON.stringify(updatedInches),
//         total_product_stock: updatedTotalStock,
//         total_stock_value: updatedStockValue
//       }, { where: { id: product_id } });

//       // log stock movement
//       const lastMovement = await stock_movement.findOne({
//         where: { product_id, inch: inches, shop_id },
//         order: [['movement_date', 'DESC']]
//       });

//       const lastBalance = lastMovement ? lastMovement.balance : product.total_product_stock;
//       const newBalance = Number(lastBalance) - prevQuantity + newQuantity;

//       await stock_movement.create({
//         product_id,
//         movement_type: "purchase",
//         movement_reason: "adjusted purchase record",
//         inch: inches,
//         quantity: quantityDiff,
//         balance: newBalance,
//         movement_date: date,
//         shop_id
//       });

//     // =========================
//     // PRODUCT HAS NO INCHES
//     // =========================
//     } else {
//       const newStock = Number(product.total_product_stock) - prevQuantity + newQuantity;
//       const newStockValue = Number(product.total_buying_price) * newStock;

//       await Products.update({
//         total_product_stock: newStock,
//         total_stock_value: newStockValue
//       }, { where: { id: product_id } });

//       const lastMovement = await stock_movement.findOne({
//         where: { product_id, shop_id },
//         order: [['movement_date', 'DESC']]
//       });

//       const lastBalance = lastMovement ? lastMovement.balance : product.total_product_stock;
//       const newBalance = Number(lastBalance) - prevQuantity + newQuantity;

//       await stock_movement.create({
//         product_id,
//         movement_type: "purchase",
//         movement_reason: "adjusted purchase record",
//         quantity: quantityDiff,
//         balance: newBalance,
//         movement_date: date,
//         shop_id
//       });
//     }

//     // Final: Update the purchase record
//     await Purchase.update({
//       product_id,
//       product_quantity: newQuantity,
//       supplier,
//       inches
//     }, { where: { id: purchase_id } });

//     return res.status(200).json({ message: "Purchase updated and stock adjusted correctly" });

//   } catch (error) {
//     return res.status(500).json({ message: error.message });
//   }
// }


// //get all purchase value
// exports.getAllpurchases = async(req, res, next)=>{
//          const date = req.query.date
//          const shop_id = req.query.shop_id
         
//          try{
             
        
//           let page = 0;
//             const pagenumber = Number.parseInt(req.query.page);
            
//             if(!shop_id){
//                 return res.status(200).json({message:"shop id required"})
//             }
            
//             if(pagenumber == 0 || pagenumber > 0){
              
//             if(!Number.isNaN(pagenumber) && pagenumber > 0 ){
//                 page = pagenumber;
//             }
            
//             }
            
//          if(date){
//              const filterPurchasedata =await Purchase.findAll({where:{data: date, shop_id: shop_id}, order: [["id", "DESC"]]})
             
//              let finaldata = []
             
//              for(const value of filterPurchasedata){
//                  const getproductName = await Products.findOne({where:{id:  value.product_id}})
//                  const getsuppliersName = await Suppliers.findOne({where:{id:value.id}})
                 
//                  const result = {
//                       purchase_id : value.id,
//                      product_name : getproductName.product_name,
//                      product_quantity : value.product_quantity,
//                      supplier : getsuppliersName.supplier_name,
//                      inches : value.inches,
//                      created_by : value.created_by,
//                      date : value.date
//                  }
                 
//                  finaldata.push(result)
//              }
//               const paginatedData = await pagination(finaldata, page)
//              return res.status(200).json(paginatedData)
//          }
         
//          //get all records
//          const allPurchasedata =await Purchase.findAll({where:{shop_id : shop_id},order: [["id", "DESC"]]})
         
//           let finaldata = []
             
//              for(const value of allPurchasedata){
//                  const getproductName = await Products.findOne({where:{id:  value.product_id}})
//                  const getsuppliersName = await Suppliers.findOne({where:{id:value.supplier}})
//                  let suppliername
//                  if(getsuppliersName){
//                      suppliername = getsuppliersName.supplier_name
//                  }
//                  const result = {
//                      purchase_id : value.id,
//                      product_name : getproductName.product_name,
//                      product_quantity : value.product_quantity,
//                      supplier : suppliername,
//                      inches : value.inches,
//                      created_by : value.created_by,
//                      date : value.date
//                  }
                 
//                  finaldata.push(result)
//              }
//          const paginatedData = await pagination(finaldata, page)
         
//          return res.status(200).json(paginatedData)
//          }catch(error){
//             return res.status(400).json({message: error.message})
//       }
// }














