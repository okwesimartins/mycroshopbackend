// const db = require("../models");
// const Users = db.users;
// const otpemail = require("../service/mail-services.js");
// const Orders = db.orders;
// const Products = db.products;
// const Admin = db.admin
// const Product_rating = db.product_rating;
// const Op = db.Sequelize.Op;
// const Categories = db.categories;
// const bcrypt = require("bcryptjs");
// const Menu = db.menu;
// const Adminmenuaccess = db.admin_menu_access;
// const Delivery_landmark = db.delivery_landmark
// const Sequelize  = require('sequelize')

// ////////////////////////////////////////////////////////////////////////////////////////////reports management //////////////////////////////////////////////////////////////////////////


// //create delivery landmark
// exports.createDeliverylandmark = async (req, res, next)=>{
//       const {landmarkname,landmarkprice} = req.body
       
//       if(landmarkname && landmarkprice){
//              try{
//           await Delivery_landmark.create({
//               "landmark_name":landmarkname,
//               "landmark_price":landmarkprice
//           })
//       }catch(error){
//             return res.status(500).json(error);
//       }
//         return res.status(200).json({ message: "created successfully"})
       
//       }
//          return res.status(400).json({ message: "All fields required"})
// }
// //get all landmarks
// exports.getAllDeliverylandmark = async (req, res, next)=>{
       
//              try{
//           const data = await Delivery_landmark.findAll()
//           return res.status(200).json({data})
//       }catch(error){
//             return res.status(500).json(error);
//       }
       
       
       
// }
// //update delivery landmark
// exports.updateDeliverylandmark = async (req, res, next)=>{
//       const {id,landmarkname,landmarkprice} = req.body
       
//       if(landmarkname && landmarkprice){
//              try{
//           await Delivery_landmark.update({
//               "landmark_name":landmarkname,
//               "landmark_price":landmarkprice
//           },{where:{id: id}})
//       }catch(error){
//             return res.status(500).json(error);
//       }
//         return res.status(200).json({ message: "created successfully"})
       
//       }
//          return res.status(400).json({ message: "All fields required"})
// }




// exports.Ordersgraph= async (req, res, next)=>{
//     const thirtyDaysAgo = new Date();
// thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
// const formattedDate = `${thirtyDaysAgo.getFullYear()}-${String(thirtyDaysAgo.getMonth() + 1).padStart(2, '0')}-${String(thirtyDaysAgo.getDate()).padStart(2, '0')}`


// const orders = await Orders.findAll({
//   where: {
//     date: {
//       [Op.gte]: '2024-06-09',
//     },
//   },
//   group: ['date'],
//   attributes: [
//     'date',
//     [Sequelize.fn('COUNT', '*'), 'salesCount'],
//   ],
// })

// return res.status(200).json(orders)

// }

// exports.adminDashboard = async (req, res, next) => {
    
//     let totalcustomer
//     let totalactivecustomers
//     let totalinactivecustomers
//     let totalproducts
//     let totalorders
//     let totalcompletedOrders
//     let totalpendingOrders
//     let  newSignupsCount
    
    
 
  
//     //total users
//     try{
//   totalcustomer = await Users.count();
//     }catch (error) {
//     return res.status(500).json({ error: 'An error occurred while counting new signups' });
//   }
  
//      //total active/inactive users (users who have purchased an item or product and those who havent)
//       try{
//   const activeUsers = await Users.findAll({attributes:['id'],where:{account_status: 1}});
//   const  idsArray = activeUsers.map(obj => obj.id);
//   const activeresult = await Orders.count({
//                   where: { user_id: { [Op.in]: idsArray} }, distinct: true,
//   col: 'user_id'
//           });
//   totalactivecustomers = (activeresult/totalcustomer) * 100
//     totalinactivecustomers  = 100 - totalactivecustomers
//     }catch (error) {
//     return res.status(500).json({ error: 'An error occurred while counting new signups' });
//   }
  
  
  
//   //total products
//   try{
//   totalproducts = await Products.count();
//     }catch (error) {
//     return res.status(500).json({ error: 'An error occurred while counting new signups' });
//   }
  
//   //total orders
  
//   try{
//   totalorders = await Orders.count();
//     }catch (error) {
//     return res.status(500).json({ error: 'An error occurred while counting new signups' });
//   }
  
//   //pending orders
//   try{
//   totalpendingOrders = await Orders.count({where:{delivery_status: "pending"}});
//     }catch (error) {
//     return res.status(500).json({ error: 'An error occurred while counting new signups' });
//   }
  
//   // completed orders
//   try{
//   totalcompletedOrders = await Orders.count({where:{delivery_status: "delivered"}});
//     }catch (error) {
//     return res.status(500).json({ error: 'An error occurred while counting new signups' });
//   }
  
  
//   //total new signups
//   try {
//     // Get the date 30 days ago from today
//     const thirtyDaysAgo = new Date();
//     thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

//     // Count users who signed up in the last 30 days
//   newSignupsCount = await Users.count({
//       where: {
//         date: {
//           [Op.gte]: thirtyDaysAgo,
//         },
//       },
//     });
//   }catch (error) {
//     return res.status(500).json({ error: 'An error occurred while counting new signups' });
//   }
  
     
   
//     return res.status(200).json({newSignupsCount, totalpendingOrders, totalcompletedOrders,  totalorders, totalproducts, totalinactivecustomers, totalactivecustomers, totalcustomer})
  
// }


// //pull reports based on report type 
// exports.getrePorts = async (req, res, next)=>{
//       const reportType = req.query.type
      
//       if(reportType == "customers"){
//           const getAllusers = await Users.findAll({attributes:["name","email","phone_number","account_status"]})
          
//           return res.status(200).json(getAllusers)
//       }
      
//         if(reportType == "orders"){
          
//   try {
//     // Fetch all orders, users, products, and categories
//     const getAllOrders = await Orders.findAll();
//     const allUsers = await Users.findAll();
//     const allProducts = await Products.findAll();
//     const allCategories = await Categories.findAll();

//     // Create lookup maps for quick access
//     const userMap = allUsers.reduce((acc, user) => {
//       acc[user.id] = user;
//       return acc;
//     }, {});

//     const productMap = allProducts.reduce((acc, product) => {
//       acc[product.id] = product;
//       return acc;
//     }, {});

//     const categoryMap = allCategories.reduce((acc, category) => {
//       acc[category.id] = category;
//       return acc;
//     }, {});

//     const orderArray = [];
    
//     // Process each order
//     for (const order of getAllOrders) {
//       const products = JSON.parse(order.product);
//       const user = userMap[order.user_id];
//       const orderedProducts = [];

//       // Process each product in the order
//       for (const data of products) {
//         const productDetails = productMap[data.product_id];
//         const categoryDetails = categoryMap[data.category_id];
//         const discounted = data.discounted === "0" ? "NO" : "YES";

//         orderedProducts.push({
//           productName: productDetails ? productDetails.name : 'Unknown',
//           productPrice: data.product_amount,
//           inches: data.inches,
//           orderQuantity: data.order_quantity,
//           discounted,
//           companyName: categoryDetails ? categoryDetails.category_name : 'Unknown',
//         });
//       }

//       // Structure the order response
//       orderArray.push({
//         customerName: user ? user.name : 'Unknown',
//         productsOrdered: orderedProducts,
//         deliveryAddress: order.delivery_address,
//         deliveryState: order.delivery_state,
//         deliveryCountry: order.delivery_country,
//         deliveryLandmark: order.delivery_landmark,
//         deliveryStatus: order.delivery_status,
//         date: order.date,
//         paymentStatus: order.payment_status,
//         paymentMethod: order.payment_method,
//         dateDelivered: order.date_delivered,
//         totalAmountPaid: order.amount_paid,
//         orderId: order.order_id,
//       });
//     }

//     return res.status(200).json(orderArray);
//   } catch (error) {
    
//     return res.status(500).json({ message: 'Server error occurred.' });
//   }


//       }
      
//         if(reportType == "products"){
            
              
//               try {

//     const products = await Products.findAll();
//     const orders = await Orders.findAll({
//       attributes: ['product'], 
//     });
    
//     const productOrderCount = {};
    
//     orders.forEach((order) => {
//       const orderedProducts = JSON.parse(order.product);
      
//       orderedProducts.forEach((orderedProduct) => {
//         const productId = orderedProduct.product_id;
        
//         if (productOrderCount[productId]) {
//           productOrderCount[productId] += orderedProduct.order_quantity;
//         } else {
//           productOrderCount[productId] = orderedProduct.order_quantity;
//         }
//       });
//     });

//     const productsWithOrderCount = products.map((product) => {
//       const orderCount = productOrderCount[product.id] || 0;
//       return {
//         ...product.toJSON(),
//         orderCount,
//       };
//     });

//      return res.status(200).json(productsWithOrderCount)
  
//   } catch (error) {
//     return res.status(400).json({message: "An error occured"})
//   }
         
         
          
//       }
// }








// ///////////////////////////////////////////////////////////////////////////report managent end /////////////////////////////////////////////////////////////


// exports.getmenu = async (req, res, next)=>{
//         const menus = await Menu.findAll()
        
//         return res.status(200).json(menus)
// }
 
// exports.createAdminuser = async (req, res, next)=>{
//     const {name,email,phone_number} = req.body
    
//     const hashPassword = bcrypt.hashSync("LGH1234#");
    
//     const checkAdmin = await Admin.findOne({where:{email:email, name:name}})
    
//     if(checkAdmin){
//         return res.status(400).json({message: "duplicate entry"})
//     }
//     try{
//          await Admin.create({
//             name,
//             email,
//             password: hashPassword,
//             phone_number: phone_number,
//             admin_type: "admin_user"
//         })
//     }catch(err){
//         return res.status(400).json(err)
//     }
       
        
//         return res.status(200).json({message: "success"})
// }
// //get all admin users
// exports.getAdminUser = async (req, res, next)=>{
//     const adminusers = await Admin.findAll({attributes:['id','phone_number','email'],where:{admin_type: "admin_user"}})
    
//     let finalData = []
       
       
       
        
//     for(const value of adminusers){  
//         const menuaccess = await Adminmenuaccess.findOne({where:{admin_id: value.id}})
//         let menu = null
//         if(menuaccess){
//             const menuidarray = JSON.parse(menuaccess.menu_id)
        
//          menu = await Menu.findAll({where:{id: { [Op.in]: menuidarray}}})
//         }
        
        
//         const data = {
//         "id": value.id,
//         "phone_number": value.phone_number,
//         "email": value.email,
//         "menus":menu
//         }
        
//         finalData.push(data)
//     }
    
//       return res.status(200).json(finalData)
// }


// //assign menus
// exports.assignMenu = async (req, res, next)=>{
//       const {menu_id, admin_user_id} = req.body
       
//       if(menu_id.length !=0){
//           const checkUseraccess =  await Adminmenuaccess.findOne({where:{admin_id: admin_user_id}})
       
//       const convertedMenuids = JSON.stringify(menu_id)
//       if(checkUseraccess){
//             try{
//          await Adminmenuaccess.update({ menu_id: convertedMenuids},{where:{admin_id: admin_user_id}})
//     }catch(err){
//         return res.status(400).json(err)
//     }
    
//     return res.status(200).json({message: "success"})
           
//       }else{
           
//           try{
//          await Adminmenuaccess.create({
//             admin_id: admin_user_id,
//             menu_id: convertedMenuids
//         })
//     }catch(err){
//         return res.status(400).json(err)
//     }
    
//     return res.status(200).json({message: "success"})
    
//       }
       
//       }
//         return res.status(400).json({message: "failed all fields are required"})
       
       
// }


// //update admin bank details
// exports.updateBankdetails = async (req, res, next)=>{
//     const {bank_name, account_number, account_name} = req.body
    
//     const Bankdata = [
//     {
//         "bank_name": bank_name,
//         "account_number":account_number,
//         "account_name":account_name
//     }
// ]

// const converteddata = JSON.stringify(Bankdata)

// try{
//     await Admin.update({bank_details: converteddata},{where:{admin_type: "super_admin"}})
    
// }catch(err){
//         return res.status(400).json(err)
//     }
    
//     return res.status(200).json({message: "success"})

// }

// //update online payment public and secrete key
// exports.updateOnlinepaymentkeys = async(req, res, next)=>{
//       const {payment_public_key,payment_secrete_key} = req.body
      
//       try{
//     await Admin.update({payment_public_key:payment_public_key, payment_secrete_key: payment_secrete_key},{where:{admin_type: "super_admin"}})
// }catch(err){
//         return res.status(400).json(err)
//     }
    
//      return res.status(200).json({message: "success"})
// }



