// const db = require("../models");
// const Paymentlist = db.payment_list
// const Op = db.Sequelize.Op;
// const  Sequelize=require('sequelize')
// const Shop = db.shop
// const Invoice = db.invoice
// const Customers =  db.customers
// const Users = db.users;
// const bcrypt = require("bcryptjs")
// const Sortorders = db.sortorders
// const Products = db.products;

// const Discount = db.discount
// const pagination = async (items, page) => {

//   var page = page || 1,
//   per_page = 10,
//   offset = (page - 1) * per_page,
//   paginatedItems = items.slice(offset).slice(0, per_page),
//   total_pages = Math.ceil(items.length / per_page);
  
//   return {
//   page: page,
//   per_page: per_page,
//   pre_page: page - 1 ? page - 1 : null,
//   next_page: (total_pages > page) ? page + 1 : null,
//   total: items.length,
//   total_pages: total_pages,
//   data: paginatedItems
//   };
  
// }


// //getall payment list
// exports.getPaymentlist = async (req, res, next)=>{
//      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
//                   res.setHeader('Pragma', 'no-cache');
//                   res.setHeader('Expires', '0')
         
//          try{         
//     const shop_id = req.query.shop_id
   
     
//      const searchValue = req.query.search_value
     
    
    
//         const  allPayment= await Paymentlist.findAll({where:{shop_id : shop_id },order: [["id", "DESC"]]})
    
    
//     if(!shop_id){
//           return res.status(400).json({message: "shop id field is required"})
//     }
   
//     let page = 0;
//             const pagenumber = Number.parseInt(req.query.page);
            
//             if(pagenumber == 0 || pagenumber > 0){
              
//             if(!Number.isNaN(pagenumber) && pagenumber > 0 ){
//                 page = pagenumber;
//             }
            
//             }
    
//     const finalResult = []
//     for(const value of allPayment){
//         const getInvoicedetails = await Invoice.findOne({where:{invoice_number: value.invoice_number}})
        
//         if(getInvoicedetails){
//               const getCustomerdata = await Customers.findOne({where:{id: value.customer_id}, attributes:['id','name']})
//              const parseOrderedproduct = JSON.parse(getInvoicedetails.products_ordered_array	)
            
//              const invoiceData = {
//                  "invoice_number": getInvoicedetails.invoice_number,
//                  "customer_name": getCustomerdata.name,
//                  "date": getInvoicedetails.date,
//                  "payment_method": getInvoicedetails.payment_method,
//                  "total_amount": getInvoicedetails.total_amount,
//                  "created_by": getInvoicedetails.created_by,
//                  "payment_status": getInvoicedetails.status,
//                  "products_ordered": parseOrderedproduct,
//                  "discount_name" : getInvoicedetails.discount_name
//              }
             
//              const paymentListdata = {
//                  customer_name : getCustomerdata.name,
//                  invoice_number : getInvoicedetails.invoice_number,
//                  date : getInvoicedetails.date,
//                  payment_method: getInvoicedetails.payment_method,
//                  payment_status : value.status,
//                  invoicedata : invoiceData
//              }
             
//              finalResult.push(paymentListdata)
//         }
      
//     }
    
    
//      if(searchValue){
//         const searchTerm = searchValue.toLowerCase(); // Convert search term to lowercase for case-insensitive search
        
//         const paymentlistSearchdata = finalResult.filter(payment => {
//             return (
//                 payment.customer_name.toLowerCase().includes(searchTerm) ||
//                 payment.invoice_number.toLowerCase().includes(searchTerm) ||
//                 payment.payment_method.toLowerCase().includes(searchTerm) ||
//                 payment.payment_status.toLowerCase().includes(searchTerm)
//             );
//         });
  
//       const paginatedData = await pagination(paymentlistSearchdata, page)
//       return res.status(200).json(paginatedData)
    
    
//     }
//      const paginatedData = await pagination(finalResult, page)
//      return res.status(200).json(paginatedData)
     
// }catch(error){
//                   return res.status(400).json({message:error.message})
//             }
// }


// //validate invoice payment pin
// exports.ValidateinvoicePaymentpin = async (req, res, next)=>{
//     const {invoice_number, pin} = req.body
    
//     //this is to get the default super  admin
//     const getAdminuser = await Users.findOne({where:{id : 1}})
    
//     const unhashpin = bcrypt.compareSync(pin, getAdminuser.	update_invoice_payment_pin);
              
//               if(!unhashpin){
//                   return res.status(400).json({message:"Incorrect pin"})
//               }
            
//             try{
//                 await Invoice.update({validated: 1},{where:{invoice_number: invoice_number}})
                
//                   return res.status(200).json({message:"success"})
//             }catch(error){
//                   return res.status(400).json(error)
//             }
        
       
// }

// //admin cancel update payment status process
// exports.cancelUpdatePaymentstatus = async (req, res, next)=>{
//     const invoice_number = req.body.invoice_number
    
//           try{
//                 await Invoice.update({validated: 0},{where:{invoice_number: invoice_number}})
                
//                   return res.status(200).json({message:"success"})
//             }catch(error){
//                   return res.status(400).json(error)
//             }
// }





// //update invoice payment status
// exports.UpdateinvoicePaymentstatus =  async (req, res, next)=>{
//       const {invoice_number, shop_id, status} = req.body
      
//       if(status == "Cancel" || status == "Refund" && shop_id){
//         const invoiceDetails =   await Invoice.findOne({where:{invoice_number:invoice_number, shop_id:shop_id}})
        
//         if(invoiceDetails.validated == 1){
                   
//                   const productOrdered = JSON.parse(invoiceDetails.products_ordered_array)
                   
//                   if(status == "Refund" ){
                       
//                       //check if invoice has been paid for
//                       if(invoiceDetails.status == "Unpaid" || invoiceDetails.status == "Cancel"){
//                           return res.status(400).json({message:"You cant refund an invoice that is unpaid or canceled "})
//                       }
                       
                     
//                       for(const value of productOrdered){
//                           const inch = value.inches
                           
//                               const getProductdetails = await Products.findOne({where:{id: value.product_id}})
                              
//                           if(inch){
                            
                               
//                               const getProductinches =  JSON.parse(getProductdetails.inches)
                               
                              
                               
//                               const getQuantityordered = Number(value.quantity)
                               
//                                 let totalStock = 0;
//                                 let buyingPrice = 0
//     const updatedProducts = getProductinches.map(product => {
//         if (Number(product.inche) === Number(inch)) {
//             product.stock = Number(product.stock) + getQuantityordered // Increase stock
//         }
//         totalStock += parseInt(product.stock);// Sum the new stock values
//         buyingPrice += parseInt(product.buying_price)
//         return product;
//     });
//     const updatedInchesJSON = JSON.stringify(updatedProducts)
//                      const newStockvalue = buyingPrice * totalStock
                     
//                     await Products.update({inches:updatedInchesJSON,total_product_stock: totalStock,total_stock_value:newStockvalue  },{where:{id: value.product_id}})
                    
//                           }
                           
//                          if(!inch){
//                               const getQuantityordered = Number(value.quantity)
//                               const getTotalproductstock = Number(getProductdetails.total_product_stock) + getQuantityordered
                               
//                                 const newStockvalue = Number(value.buying_price) * getTotalproductstock
                                
//                               await Products.update({total_product_stock: getTotalproductstock,total_stock_value:newStockvalue },{where:{id: value.product_id}})
//                          }
//                       }
                       
                     
//                   }
                   
//                   if(status == "Cancel"){
//                       //check if invoice is Unpaid
//                         if(invoiceDetails.status == "Paid" || invoiceDetails.status == "Cancel"){
//                           return res.status(400).json({message:"You cant cancel an invoice that has been paid or canceled  you can only perform refund"})
//                       }
                      
//                   }
                   
//                   try{
//                         await Paymentlist.update({
//                             status : status,
//                         },{where:{invoice_number:invoice_number}})
//                   }catch(error){
//                       return res.status(400).json(error)
//                   }
                  
                  
//                   try{
//                       await Invoice.update({
//                           status : status,
//                           validated: 0
//                       },{where:{invoice_number:invoice_number}})
                      
//                       await  Sortorders.destroy({where:{invoice_number: invoice_number}})
                       
//                         return res.status(200).json({message: "Payment updated"})
//                   }catch(error){
//                       return res.status(400).json(error)
//                   }
//         }
        
//         return res.status(400).json({message: "Fraud detected"})
        
        
//       }
// }


// //create discount
// exports.createDiscount= async (req, res, next)=>{
//     const {discount_name, discount_value, expiration_date, status} = req.body
    
//     if(!discount_name && !discount_value && !expiration_date && !status){
//          return res.status(400).json({message: "All fields are required"}) 
//     }
    
//     if(status == "active" || status =="inactive"){
//         //check duplicate 
//     const checkDuplicate = await  Discount.findOne({where:{discount_name:discount_name,
//       discount_value: discount_value, expiration_date  
//     }})
    
//     if(checkDuplicate){
//          return res.status(400).json({message: "Duplicate data"}) 
//     }
//     try{
//         await Discount.create({
//             discount_name,
//             discount_value,
//             expiration_date,
//             status
//         })
        
//       return res.status(200).json({message: "Discount created"}) 
//     }catch(error){
//         return res.status(400).json(error)
//     }
//     }
   
    
//       return res.status(400).json({message: "status value should be active or inactive"}) 
// }

// //update discount
// exports.updateDiscount = async (req, res, next)=>{
//     const {discount_id, discount_name, discount_value, expiration_date, status} = req.body
    
//     if(!discount_id && !discount_name && !discount_value && !expiration_date && !status){
//          return res.status(400).json({message: "All fields are required"}) 
//     }
    
//     if(status == "active" || status =="inactive"){
//           try{
//         await Discount.update({
//             discount_name : discount_name,
//             discount_value : discount_value,
//             expiration_date: expiration_date,
//             status : status
//         },{where:{id: discount_id}})
        
//          return res.status(200).json({message: "discount updated"})
//     }catch(error){
//         return res.status(400).json(error)
//     }
//     }
   
    
//     return res.status(400).json({message: "status value should be active or inactive"}) 
// }

// //get all discount
// exports.getDiscount = async(req, res, next)=>{
//       const search_value = req.query.search_value
      
//       if(search_value){
//           const getDiscount = await Discount.findOne({where:{ [Op.or]: [
//           { discount_name: { [Op.like]: `%${search_value}%` } },
//           { expiration_date: { [Op.like]: `%${search_value}%` } },
//           { status: { [Op.like]: `%${search_value}%` } }
//         ]}})
      
//       return res.status(200).json(getDiscount)
//       }
      
//       const getDiscount = await Discount.findAll()
      
//       return res.status(200).json(getDiscount)
// }



























