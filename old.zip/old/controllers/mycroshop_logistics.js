const bcrypt = require('bcryptjs');
const db = require("../models");
const jwt = require('jsonwebtoken');
const axios = require('axios');
const crypto = require('crypto');
const { sendEmailWithTemplate } = require('../service/mail-services.js');
const { generateOtp, encryptOtpPayload, decryptOtpPayload } = require('../utils/otpUtils');
const ejs = require('ejs');
const { Op } = require('sequelize');
const Logistics_agents =   db.logistics_agents
const Business = db.business
const Form_expiration_token = db.form_expiration_token
const dayjs = require('dayjs');
const Logistic_agent_listings = db.logistic_agent_listings

const Logistic_bookings = db.logistic_bookings
const LogisticsCompanies = db.logisticsCompanies

const FreelanceAgents = db.freelance_agents

const PickupRequests = db.pickup_request
const Mycroshop_logistics_customers = db.mycroshop_logistics_customers
const  Sequelize= db.sequelize
const Logistics_token_payments = db.logistics_token_payments
const Manual_terminal_bookings = db.manual_terminal_bookings

const AGENT_SECRET = 'tywuwiiiwoohhwbbbhhwhhbbnn';
// AGENT_SECRET_TOKEN = 'tywuwiiiwoohhwbbbhhwhhbbnn'
const PAYSTACK_SECRET = 'sk_test_0255f1f40367a9712aba18e65864b3440d10d879';
const PAYSTACK_BASE_URL = 'https://api.paystack.co';
const INTERNAL_TOKEN_SECRET = 'tywuwiiiwoohhwbbbhhwhhbbnn';
//token cost is billed in naira meaning 1 token is 500  naira
const TOKEN_COST = 500;


const  calculateDistanceInKm = async (lat1, lon1, lat2, lon2)=> {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) *
    Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) *
    Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

const pagination = async (items, page) => {

  var page = page || 1,
  per_page = 10,
  offset = (page - 1) * per_page,
  paginatedItems = items.slice(offset).slice(0, per_page),
  total_pages = Math.ceil(items.length / per_page);
  
  return {
  page: page,
  per_page: per_page,
  pre_page: page - 1 ? page - 1 : null,
  next_page: (total_pages > page) ? page + 1 : null,
  total: items.length,
  total_pages: total_pages,
  data: paginatedItems
  };
  
}

exports.generateLogisticCompanyFormToken = async (req, res) => {
  
  try {
    const rawToken = crypto.randomBytes(20).toString('hex');
    const expirationTime = dayjs().add(30, 'minute').format('YYYY-MM-DD HH:mm:ss');

    // Create encoded token that contains the commission
    const encodedToken = jwt.sign(
      {rawToken},
      INTERNAL_TOKEN_SECRET,
      { expiresIn: '30m' }
    );

    // Save raw token to DB
    await Form_expiration_token.create({
      token: rawToken,
      expiration_date_and_time: expirationTime,
      trials: 0
    });

    return res.status(201).json({
      message: 'Token generated successfully',
      token: encodedToken,
      expires_at: expirationTime
    });

  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
}
////////////////////////////////////////////////////////////////////////////////////////////logistics customers////////////////////////////////////////////////////////////////////////////////////


exports.registerLogisticsCustomer = async (req, res) => {
  const { name, email, phone_number, password } = req.body;
  try {
      
      //check if customer exist
      const checkCustomer = await Mycroshop_logistics_customers.findOne({where:{email:email, phone_number:phone_number}})
      
      if(checkCustomer){
          res.status(400).json({ message: "Record exist already" });
      }
      
    const hash = await bcrypt.hash(password, 10);
    const customer = await Mycroshop_logistics_customers.create({
      name, email, phone_number, password: hash,
      date_created: new Date().toISOString(),
      logistic_token: 0
    });
    res.status(201).json({ message: 'Customer registered', customer });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.loginLogisticsCustomer = async (req, res) => {
  const { email, password } = req.body;
  try {
    const customer = await Mycroshop_logistics_customers.findOne({ where: { email } });
    if (!customer) return res.status(404).json({ message: 'Invalid credentials' });
    const valid = await bcrypt.compare(password, customer.password);
    if (!valid) return res.status(401).json({ message: 'Invalid credentials' });
    const token = jwt.sign({ id: customer.id , type:"logistics", privileges : ["logistics customer"]}, AGENT_SECRET);
    res.status(200).json({ message: 'Login successful', token });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.initiateTokenPayment = async (req, res) => {
  const customerId = req.user?.id;
  const type  = req.user.type
  const { tokens } = req.body;

  if (!tokens || tokens < 1) return res.status(400).json({ message: 'Minimum 1 token required' });
  const amount = tokens * TOKEN_COST * 100;

  try {
      let customer
      if(type == "logistics"){
            customer = await Mycroshop_logistics_customers.findByPk(customerId);
      }
      
      if(type == "business"){
          customer = await Business.findByPk(customerId)
      }
      
      if(!customer){
          res.status(500).json({ message:"error occured"});
      }
    const response = await axios.post(`${PAYSTACK_BASE_URL}/transaction/initialize`, {
      email: customer.email,
      amount,
      metadata: { tokens },
      callback_url: `https://mycroshop.netlify.app/`
    }, {
      headers: { Authorization: `Bearer ${PAYSTACK_SECRET}` }
    });

    res.status(200).json({ payment_link: response.data.data.authorization_url });
  } catch (err) {
    res.status(500).json({ message: err.response?.data?.message || err.message });
  }
};

exports.verifyTokenPayment = async (req, res) => {
  const customerId = req.user?.id;
  const { reference } = req.query;
   const type  = req.user.type
  try {
    const verifyRes = await axios.get(`${PAYSTACK_BASE_URL}/transaction/verify/${reference}`, {
      headers: { Authorization: `Bearer ${PAYSTACK_SECRET}` }
    });

    if (verifyRes.data.data.status !== 'success') {
      return res.status(400).json({ message: 'Payment not successful' });
    }

    const tokens = verifyRes.data.data.metadata.tokens;
    const amount_paid = verifyRes.data.data.amount / 100;
     //check duplicate
     const checkDuplicate = await Logistics_token_payments.findOne({where:{payment_reference:reference}})
     
     if(checkDuplicate){
         return res.status(400).json({ message: 'duplicated record' });
     }
    await Logistics_token_payments.create({
      user_id: customerId,
      user_type: type,
      payment_reference: reference,
      token_purchased: tokens,
      amount_paid,
      date: new Date().toISOString()
    });

    const customer = await Mycroshop_logistics_customers.findByPk(customerId);
    customer.logistic_token += parseInt(tokens);
    await customer.save();

    res.status(200).json({ message: 'Payment verified and tokens added', balance: customer.logistic_token });
  } catch (err) {
    res.status(500).json({ message: err.response?.data?.message || err.message });
  }
};



// Get All Listings for Customers (Only Active or In Transit)
exports.getAllListingsForCustomers = async (req, res) => {
  const customerId = req.user?.id;
  const { status, route, search = '', my_bookings } = req.query;

  try {
    let listings = await Logistic_agent_listings.findAll({
      order: [['id', 'DESC']]
    });

    if (status) {
      listings = listings.filter(l => l.status === status);
    }

    if (route) {
      listings = listings.filter(async l => {
        const agent = await Logistics_agents.findByPk(l.logistics_agent_id);
        return `${agent.state} - ${l.destination_state}` === route;
      });
    }

    if (search) {
      listings = await Promise.all(listings.map(async (l) => {
        const agent = await Logistics_agents.findByPk(l.logistics_agent_id);
        if (agent.transport_company_name.toLowerCase().includes(search.toLowerCase())) {
          return l;
        }
        return null;
      }));
      listings = listings.filter(l => l);
    }

    if (my_bookings === 'true') {
      const bookings = await Logistic_bookings.findAll({
        where: { user_id: customerId }
      });
      const bookingIds = bookings.map(b => b.listing_id);
      listings = listings.filter(l => bookingIds.includes(`${l.id}`));
    }

    return res.status(200).json(listings);
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}

//Initiate Logistics Payment
exports.initiateLogisticsPayment = async (req, res) => {
  const {
    listing_id, parcel_kg, seat_numbers,
    request_agent_pickup = false, pickup_address, pickup_lat, pickup_lng, lga
  } = req.body;

  const user = req.user;
  const usertype = req.user.user_type;

  try {
    const listing = await Logistic_agent_listings.findByPk(listing_id);
    const company = await LogisticsCompanies.findByPk(listing.company_id);

    let customer;
    if (usertype === "logistics") {
      customer = await Mycroshop_logistics_customers.findByPk(user.id);
    } else if (usertype === "business") {
      customer = await Business.findByPk(user.id);
    }

    let amount = 0;
    let pickup_fee = 0;

    if (listing.logistic_type === 'delivery') {
      if (!parcel_kg) return res.status(400).json({ message: 'Parcel weight required' });
      if (parcel_kg > listing.available_kg) return res.status(400).json({ message: `Only ${listing.available_kg}kg available` });
      amount = listing.price_per_kg * parcel_kg;
    } else if (listing.logistic_type === 'travel') {
      if (!Array.isArray(seat_numbers) || seat_numbers.length === 0) return res.status(400).json({ message: 'Seat numbers required' });
      const seatMap = listing.seat_map || [];
      const isInvalid = seat_numbers.some(seat => {
        const match = seatMap.find(s => s.seat === seat);
        return !match || match.booked;
      });
      if (isInvalid) return res.status(400).json({ message: 'One or more seats unavailable' });
      amount = parseFloat(listing.price) * seat_numbers.length;
    }

    // Calculate pickup fee if selected
    if (request_agent_pickup && pickup_lat && pickup_lng) {
      const company_lat = company.latitude;
      const company_lng = company.longitude;

      const distance_km = calculateDistanceInKm(pickup_lat, pickup_lng, company_lat, company_lng);
      const base_fee = 500; // base pickup fee
      const per_km_fee = 100;

      pickup_fee = base_fee + (per_km_fee * distance_km);
      amount += pickup_fee;
    }

    const metadata = {
      user_id: user.id,
      listing_id,
      type: listing.logistic_type,
      user_type: usertype,
      parcel_kg,
      seat_numbers,
      company_id: company.id,
      request_agent_pickup,
      pickup_address,
      pickup_lat,
      pickup_lng,
      lga,
      pickup_fee
    };

    const response = await axios.post(
      'https://api.paystack.co/transaction/initialize',
      {
        email: customer.email,
        amount: amount * 100,
        metadata,
        callback_url: `https://yourdomain.com/api/logistics/payment/verify`
      },
      {
        headers: { Authorization: `Bearer ${company.paystack_public_key}` }
      }
    );

    return res.status(200).json({ payment_link: response.data.data.authorization_url });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}

//Verify Logistics Payment
exports.verifyLogisticsPayment = async (req, res) => {
  const { reference } = req.query;

  try {
    const verifyRes = await axios.get(`https://api.paystack.co/transaction/verify/${reference}`, {
      headers: { Authorization: `Bearer ${company.paystack_secrete_key}` }
    });

    if (verifyRes.data.data.status !== 'success') {
      return res.status(400).json({ message: 'Payment failed or not verified' });
    }

    const metadata = verifyRes.data.data.metadata;
    const listing = await Logistic_agent_listings.findByPk(metadata.listing_id);

    if (metadata.type === 'travel') {
      const updatedMap = listing.seat_map.map(s => {
        if (metadata.seat_numbers.includes(s.seat)) return { ...s, booked: true };
        return s;
      });
      listing.seat_map = updatedMap;
      listing.available_seats -= metadata.seat_numbers.length;
      await listing.save();
    } else if (metadata.type === 'delivery') {
      listing.available_kg -= metadata.parcel_kg;
      await listing.save();
    }

    const booking = await Logistic_bookings.create({
      user_id: metadata.user_id,
      logistic_type: metadata.type,
      user_type: metadata.user_type,
      listing_id: metadata.listing_id,
      company_id: metadata.company_id,
      logistic_agent_id: listing.logistics_agent_id,
      seat_number: metadata.seat_numbers || null,
      parcel_kg: metadata.parcel_kg || null,
      amount_paid: verifyRes.data.data.amount / 100,
      pickup_fee: metadata.pickup_fee || 0,
      payment_reference: reference,
      booking_id: `LOG-${Math.floor(100000 + Math.random() * 900000)}`,
      status: 1,
      date: new Date().toISOString()
    });

    if (metadata.request_agent_pickup) {
      await PickupRequests.create({
        customer_id: metadata.user_id,
        booking_id: booking.id,
        status: 'pending',
        pickup_address: metadata.pickup_address,
        pickup_lat: metadata.pickup_lat,
        pickup_lng: metadata.pickup_lng,
        lga: metadata.lga,
        created_at: new Date().toISOString(),
        responded: false
      });
    }

    return res.status(200).json({ message: 'Booking created', booking });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////END///////////////////////////////////////////////////////////////////////////////////




///////////////////////////////////////////////////////////////////////////////////logistic company ///////////////////////////////////////////


const  isValidLocationArray = async (locations) => {
  if (!Array.isArray(locations)) return false;
  for (const loc of locations) {
    if (typeof loc !== 'object' || !loc.state || !loc.address) return false;
    if (typeof loc.state !== 'string' || typeof loc.address !== 'string') return false;
  }
  return true;
}

// Register Logistics Company
exports.registerCompany = async (req, res) => {
  const { name, email, phone_number, password, country, location, token } = req.body;
  try {
    if (!isValidLocationArray(location)) {
      return res.status(400).json({ message: 'Invalid location format. Expected JSON array of objects with state and address.' });
    }

    let decoded;
    try {
      decoded = jwt.verify(token, INTERNAL_TOKEN_SECRET);
    } catch (err) {
      return res.status(403).json({ message: 'Invalid or expired token' });
    }

    const {rawToken} = decoded;

    const tokenRecord = await Form_expiration_token.findOne({ where: { token: rawToken } });

    if (!tokenRecord) return res.status(400).json({ message: 'Invalid token record' });

    if (dayjs().isAfter(dayjs(tokenRecord.expiration_date_and_time))) {
      return res.status(403).json({ message: 'Token has expired' });
    }

    if (tokenRecord.trials >= 1) {
      return res.status(403).json({ message: 'Token already used' });
    }

    const existing = await LogisticsCompanies.findOne({ where: { [Op.or]: [{ email }, { phone_number }] } });
    if (existing) return res.status(400).json({ message: 'Company already exists' });

    const hash = await bcrypt.hash(password, 10);

    const company = await LogisticsCompanies.create({
      name, email, phone_number,
      password: hash,
      country,
      location, // expects JSON array like: [{state: 'Lagos', address: '4b toyin street'}]
      created_at: new Date().toISOString()
    });
    
     // Mark token as used
    tokenRecord.trials = 1;
    await tokenRecord.save();

    return res.status(201).json({ message: 'Company registered successfully', company });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}


exports.loginCompany = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await LogisticsCompanies.findOne({ where: { email: email } });
    if (!user) {
      return res.status(404).json({ message: "Invalid credentials" });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    // --- START: FIXES ---

    // 1. Convert the Sequelize user instance to a plain JavaScript object
    const userResponseObject = user.toJSON();

    // 2. Securely delete the password so it's never sent to the client
    delete userResponseObject.password;

    // 3. Parse the location string into a proper array
    // Includes a try-catch block to prevent errors if the data is malformed
    try {
      // Check if location is a non-empty string before parsing
      if (userResponseObject.location && typeof userResponseObject.location === 'string') {
        userResponseObject.location = JSON.parse(userResponseObject.location);
      } else {
        // If location is null, undefined, or not a string, default to an empty array
        userResponseObject.location = [];
      }
    } catch (e) {
      console.error("Error parsing location JSON:", e);
      // If parsing fails, default to an empty array for a consistent response shape
      userResponseObject.location = [];
    }

    // --- END: FIXES ---

    const token = jwt.sign({ id: user.id,  privileges : ["company"] }, INTERNAL_TOKEN_SECRET, { expiresIn: "7d" });

    // Return the cleaned user object and the token
    return res.status(200).json({ user: userResponseObject, token });

  } catch (err) {
    // It's better to send a generic message for server errors
    console.error("Login Error:", err); // Log the actual error for debugging
    return res.status(500).json({ message: "An internal server error occurred." });
  }
}


exports.getCompanyListings = async (req, res) => {
    try {
        const companyId = req.user.id;
        
        // Use distinct query params for clarity
        const {
            origin_state,
            origin_address,
            destination_state,
            destination_address,
            status,
            startDate,
            endDate
        } = req.query;

        const filters = {
            company_id: companyId
        };

        // --- Handle Origin Location (JSON Column) ---
        if (origin_address && !origin_state) {
            return res.status(400).json({ message: "Filtering by origin address requires an origin state." });
        } else if (origin_state && origin_address) {
            filters.state_created_in = { [Op.contains]: [{ state: origin_state, address: origin_address }] };
        } else if (origin_state) {
            filters.state_created_in = { [Op.contains]: [{ state: origin_state }] };
        }

        // --- Handle Destination Location (Separate Columns) ---
        if (destination_state) {
            filters.destination_state = destination_state;
        }
        if (destination_address) {
            // Use LIKE for partial matches on the destination address
            filters.destination_address = { [Op.like]: `%${destination_address}%` };
        }

        // --- Handle Status and Date Filters ---
        if (status) {
            if (['open', 'closed'].includes(status.toLowerCase())) {
                filters.status = status.toLowerCase();
            }
        }
        if (startDate && endDate) {
            filters.date_created = { [Op.between]: [new Date(startDate), new Date(endDate)] };
        } else if (startDate) {
            filters.date_created = { [Op.gte]: new Date(startDate) };
        } else if (endDate) {
            filters.date_created = { [Op.lte]: new Date(endDate) };
        }

        // --- Primary Query ---
        const listings = await Logistic_agent_listings.findAll({ where: filters });

        if (listings.length === 0) {
            return res.status(200).json([]);
        }

        // --- Fetch and Map Agent Data Manually ---
        const agentIds = [...new Set(listings.map(listing => listing.logistics_agent_id))];
        const agents = await Logistics_agents.findAll({
            where: { id: agentIds },
            attributes: ['id', 'name', 'email', 'phone']
        });
        const agentMap = agents.reduce((map, agent) => {
            map[agent.id] = agent;
            return map;
        }, {});
        const results = listings.map(listing => ({
            ...listing.toJSON(),
            agent: agentMap[listing.logistics_agent_id] || null
        }));

        return res.status(200).json(results);
    } catch (err) {
        console.error("Listings Error:", err);
        return res.status(500).json({ message: "Internal server error" });
    }
}


exports.getCompanyDashboard = async (req, res) => {
    try {
        const companyId = req.user.id;
        const { state, address, startDate, endDate } = req.query;

        // Base filter for all queries
        const filters = { logistics_company_id: companyId };

        // --- Updated Location Logic ---
        if (address && !state) {
            return res.status(400).json({ message: "Filtering by address requires a state to be specified." });
        } else if (state && address) {
            filters.location = { [Op.contains]: [{ state, address }] };
        } else if (state) {
            filters.location = { [Op.contains]: [{ state }] };
        }
        // --- End of Updated Logic ---

        // Date range filters
        if (startDate && endDate) {
            filters.date_created = { [Op.between]: [new Date(startDate), new Date(endDate)] };
        } // ... (rest of date logic)

        // ... (rest of the function is the same)
        const totalBookings = await Logistic_bookings.count({ where: filters });
        const totalRevenueResult = await Logistic_bookings.findOne({
            where: filters,
            attributes: [[Logistic_bookings.sequelize.fn("SUM", Logistic_bookings.sequelize.col("amount_paid")), "totalRevenue"]],
            raw: true
        });
        const totalRevenue = parseFloat(totalRevenueResult.totalRevenue) || 0;
        const agentCount = await Logistics_agents.count({ where: { company_id: companyId } });

        return res.status(200).json({ totalBookings, totalRevenue, agentCount });

    } catch (err) {
        console.error("Dashboard Error:", err);
        return res.status(500).json({ message: "Internal server error" });
    }
}


exports.getCompanyAgents = async (req, res) => {
    try {
        const companyId = req.user.id;
        const { state, address } = req.query;

        const filters = { company_id: companyId };

        // --- Updated Location Logic ---
        if (address && !state) {
            return res.status(400).json({ message: "Filtering by address requires a state to be specified." });
        } else if (state && address) {
            filters.location = { [Op.contains]: [{ state, address }] };
        } else if (state) {
            filters.location = { [Op.contains]: [{ state }] };
        }
        // --- End of Updated Logic ---

        const agents = await Logistics_agents.findAll({
            where: filters,
            attributes: ["id", "name", "email", "phone", "location"]
        });

        return res.status(200).json(agents);
    } catch (err) {
        console.error("Agents Error:", err);
        return res.status(500).json({ message: "Internal server error" });
    }
}


exports.getCompanyBookings = async (req, res) => {
    try {
        const companyId = req.user.id;
        const { state, address, agent_id, startDate, endDate } = req.query;

        const filters = { logistics_company_id: companyId };

        if (agent_id) {
            filters.agent_id = agent_id;
        }

        // --- Updated Location Logic ---
        if (address && !state) {
            return res.status(400).json({ message: "Filtering by address requires a state to be specified." });
        } else if (state && address) {
            filters.location = { [Op.contains]: [{ state, address }] };
        } else if (state) {
            filters.location = { [Op.contains]: [{ state }] };
        }
        // --- End of Updated Logic ---

        if (startDate && endDate) {
            filters.date_created = { [Op.between]: [new Date(startDate), new Date(endDate)] };
        } // ... (rest of date logic)

        // ... (rest of the function is the same)
        const bookings = await Logistic_bookings.findAll({ where: filters });
        const customerIds = [...new Set(bookings.map(b => b.customer_id))];
        const customers = await Mycroshop_logistics_customers.findAll({
            where: { id: customerIds },
            attributes: ["id", "name", "email"]
        });
        const customerMap = customers.reduce((map, c) => { map[c.id] = c; return map; }, {});
        const results = bookings.map(b => ({ ...b.toJSON(), customer: customerMap[b.customer_id] || null }));

        return res.status(200).json(results);
    } catch (err) {
        console.error("Bookings Error:", err);
        return res.status(500).json({ message: "Internal server error" });
    }
}

exports.getAgentDetailsAndBookings = async (req, res) => {
    // ... (This function remains the same as the previous version)
    try {
        const companyId = req.user.id;
        const { agentId } = req.params;

        const agent = await Logistics_agents.findOne({
            where: { id: agentId, company_id: companyId },
            attributes: ["id", "name", "email", "phone", "location"]
        });

        if (!agent) {
            return res.status(404).json({ message: "Agent not found" });
        }

        const { startDate, endDate } = req.query;
        const bookingFilters = { agent_id: agentId };

        if (startDate && endDate) {
            bookingFilters.date_created = { [Op.between]: [new Date(startDate), new Date(endDate)] };
        } else if (startDate) {
            bookingFilters.date_created = { [Op.gte]: new Date(startDate) };
        } else if (endDate) {
            bookingFilters.date_created = { [Op.lte]: new Date(endDate) };
        }

        const bookings = await Logistic_bookings.findAll({ where: bookingFilters });

        return res.status(200).json({ agent, bookings });

    } catch (err) {
        console.error("Agent Details Error:", err);
        return res.status(500).json({ message: "Internal server error" });
    }
}

exports.getAllLogisticsCompanies = async (req, res) => {
  try {
    const companies = await Logistics_companies.findAll({
      attributes: ['id', 'name', 'location']
    });
    return res.status(200).json({ companies });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}

exports.getCompanyRevenue = async (req, res) => {
    try {
        const companyId = req.user.id;
        const { state, address, agent_id, startDate, endDate } = req.query;

        const filters = { logistics_company_id: companyId };

        if (agent_id) {
            filters.agent_id = agent_id;
        }

        // --- Updated Location Logic ---
        if (address && !state) {
            return res.status(400).json({ message: "Filtering by address requires a state to be specified." });
        } else if (state && address) {
            filters.location = { [Op.contains]: [{ state, address }] };
        } else if (state) {
            filters.location = { [Op.contains]: [{ state }] };
        }
        // --- End of Updated Logic ---

        if (startDate && endDate) {
            filters.date_created = { [Op.between]: [new Date(startDate), new Date(endDate)] };
        }

        const revenueResult = await Logistic_bookings.findOne({
            where: filters,
            attributes: [[Logistic_bookings.sequelize.fn("SUM", Logistic_bookings.sequelize.col("amount_paid")), "totalRevenue"]],
            raw: true
        });

        const totalRevenue = parseFloat(revenueResult.totalRevenue) || 0;

        return res.status(200).json({ filters: req.query, totalRevenue });

    } catch (err) {
        console.error("Revenue Error:", err);
        return res.status(500).json({ message: "Internal server error" });
    }
}



/////////////////////////////////////////////////////////////////////////////////end////////////////////////////////////////////////////////////////////////////////////



////////////////////////////////////freelance agents///////////////////////////////////////////////////////////////////////////////////////////////////////////////
exports.registerFreelanceAgent = async (req, res) => {
  const { name, email, phone_number, password, vehicle_type, nin, location_lat, location_lng, lga } = req.body;
  try {
    const existing = await FreelanceAgents.findOne({ where: { email } });
    if (existing) return res.status(400).json({ message: 'Agent already exists' });

    const hashed = await bcrypt.hash(password, 10);
    const agent = await FreelanceAgents.create({
      name, email, phone_number, password: hashed, vehicle_type, nin, location_lat, location_lng, lga, date_registered: new Date().toISOString(), status: 'pending'
    });

    return res.status(201).json({ message: 'Freelance agent registered', agent });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

exports.loginFreelanceAgent = async (req, res) => {
  const { email, password } = req.body;
  try {
    const agent = await FreelanceAgents.findOne({ where: { email } });
    if (!agent) return res.status(404).json({ message: 'Invalid credentials' });
    const valid = await bcrypt.compare(password, agent.password);
    if (!valid) return res.status(401).json({ message: 'Invalid credentials' });
    const token = jwt.sign({ id: agent.id, privileges: ['freelance agent'] }, AGENT_SECRET);
    
     await FreelanceAgents.update({status: 'active'},{ where: { email } });
    return res.status(200).json({ message: 'Login successful', token });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}

exports.getPickupRequestsForAgent = async (req, res) => {
  const agent = await FreelanceAgents.findByPk(req.user.id)
  const requests = await PickupRequests.findAll({
    where: Sequelize.and(
      { lga: agent.lga, status: 'pending', responded: false },
      Sequelize.literal(`ST_Distance_Sphere(point(pickup_lng, pickup_lat), point(${agent.location_lng}, ${agent.location_lat})) <= 10000`)
    )
  });
  return res.json({ requests });
}


exports.respondToPickupRequest = async (req, res) => {
  const { action } = req.body;
  const request = await PickupRequests.findByPk(req.params.id);
  if (!request) return res.status(404).json({ message: 'Request not found' });

 
  if (action === 'accept') {
    request.responded = true;
    request.agent_id = req.user.id;
    request.status = 'accepted';
    request.accepted_at = new Date();
  } else {
    request.rejected_at = new Date();
  }
  await request.save();
  return res.json({ message: `Pickup request ${action}ed successfully.`});
}



exports.getAcceptedPickupRequests = async (req, res) => {
  const { status, date } = req.query;
  const agent_id = req.user.id;

  try {
    const filters = { agent_id };
    if (status) filters.status = status;
    if (date) {
      const startDate = new Date(date);
      const endDate = new Date(date);
      endDate.setHours(23, 59, 59, 999);
      filters.created_at = { [Op.between]: [startDate, endDate] };
    }

    const requests = await PickupRequests.findAll({ where: filters });

    const result = await Promise.all(
      requests.map(async (req) => {
        const booking = await Logistic_bookings.findByPk(req.booking_id);
        const listing = await Logistic_agent_listings.findByPk(booking.listing_id);
        const company = await LogisticsCompanies.findByPk(listing.company_id);

        return {
          request_id: req.id,
          status: req.status,
          pickup_address: req.pickup_address,
          dropoff_address: company.address,
          pickup_lat: req.pickup_lat,
          pickup_lng: req.pickup_lng,
          dropoff_lat: company.lat,
          dropoff_lng: company.lng,
          lga: req.lga,
          created_at: req.created_at,
        };
      })
    );

    return res.status(200).json({ pickups: result });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}


exports.updatePickupRequestStatus = async (req, res) => {
  const { request_id, status } = req.body;
  const agent_id = req.user.id;
  const validStatuses = ['picked'];

  try {
    const pickup = await PickupRequests.findOne({ where: { id: request_id, agent_id } });
    if (!pickup) return res.status(404).json({ message: 'Pickup request not found or not assigned to you' });

    if (!validStatuses.includes(status)) {
      return res.status(400).json({ message: 'Invalid status update' });
    }

    pickup.status = status;
    await pickup.save();

    return res.status(200).json({ message: 'Status updated', pickup });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}



exports.getFreelanceAgentDashboard = async (req, res) => {
  const agent_id = req.user.id;
  const COMMISSION_RATE = 0.2;

  try {
    const totalPickups = await PickupRequests.count({ where: { agent_id } });
    const accepted = await PickupRequests.count({ where: { agent_id, status: 'accepted' } });
    const picked = await PickupRequests.count({ where: { agent_id, status: 'picked' } });
    const delivered = await PickupRequests.count({ where: { agent_id, status: 'delivered' } });

    const recentRequests = await PickupRequests.findAll({
      where: { agent_id },
      order: [['created_at', 'DESC']],
      limit: 5,
    });

    const deliveredRequests = await PickupRequests.findAll({ where: { agent_id, status: 'delivered' } });
    let totalEarnings = 0;

    for (let request of deliveredRequests) {
      const booking = await Logistic_bookings.findByPk(request.booking_id);
      const pickupFee = parseFloat(booking.pickup_fee || 0);
      totalEarnings += pickupFee;
    }

    const commission = totalEarnings * COMMISSION_RATE;
    const agentTakeHome = totalEarnings - commission;

    return res.status(200).json({
      summary: {
        totalPickups,
        accepted,
        picked,
        delivered,
        earnings: {
          gross: totalEarnings,
          net: agentTakeHome,
        }
      },
      recentRequests,
    });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}


////////////////////////////////////////end//////////////////////////////////////////////////////////////////////////////////////////////////////////////////






///////////////////////////////////////////////////////////////////////////////Logistic agents functions //////////////////////////////////////////////////////////////////////////////////////////////////////////////////

exports.registerLogisticsAgent = async (req, res) => {
  const { name, email, phone_number, password, transport_company_id, country, location } = req.body;
  try {
    
    if (!isValidLocationArray(location)) {
      return res.status(400).json({ message: 'Invalid location format. Expected JSON array of objects with state and address.' });
    }
    
    const hash = await bcrypt.hash(password, 10);
    
    //check if logistic id exist
    const getCompany = await LogisticsCompanies.findOne({id:transport_company_id})
    
    if(!getCompany){
         return res.status(403).json({ message: 'company id does not exist' });
    }
    
     const duplicategetAgent = await Logistics_agents.findOne({where:{email:email, phone_number:phone_number}})
    
    if(duplicategetAgent){
         return res.status(403).json({ message: 'duplicate records' });
    }
    
    const mycroshop_commission = 10
    const agent = await Logistics_agents.create({
      name, email, phone_number, password: hash,
      company_id:transport_company_id, country,location,
      date: new Date().toISOString(), mycroshop_commission:mycroshop_commission
    });
    return res.status(201).json({ message: 'Agent registered successfully', agent });
  } catch (err) {
    return res.status(400).json({ message: err.message });
  }
};

exports.loginLogisticsAgent = async (req, res) => {
  const { email, password } = req.body;
  try {
    const agent = await Logistics_agents.findOne({ where: { email } });
    if (!agent) return res.status(404).json({ message: 'Invalid credentials' });
    const valid = await bcrypt.compare(password, agent.password);
    if (!valid) return res.status(401).json({ message: 'Invalid credentials' });
    const token = jwt.sign({ id: agent.id,  privileges : ["logistics agent"] }, AGENT_SECRET);
    return res.status(200).json({ message: 'Login successful', token });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

//agent update listing status
exports.updateListingStatus = async (req, res) => {
    const { listingId } = req.params;
    const { status } = req.body;
    const agent = req.user; // Authenticated agent

    if (!status) {
        return res.status(400).json({ message: "Status is required." });
    }

    try {
        const listing = await Logistic_agent_listings.findByPk(listingId);
        if (!listing) {
            return res.status(404).json({ message: "Listing not found." });
        }

        // --- START: Advanced Permission Logic ---

        // Basic check: Agent must belong to the same company.
        if (listing.logistics_company_id !== agent.company_id) {
            return res.status(403).json({ message: "Forbidden: You are not authorized to edit this company's listings." });
        }

        // Define the agent's roles for this specific listing
        const isCreator = listing.logistics_agent_id === agent.id;
        const agentLocation = agent.location && agent.location[0] ? agent.location[0] : {};
        const isDestinationAgent = listing.destination_state === agentLocation.state && listing.destination_address === agentLocation.address;

        // Apply rules based on the roles
        if (!isCreator && !isDestinationAgent) {
            return res.status(403).json({ message: "Forbidden: You are not the origin or destination agent for this listing." });
        }

        // Rule: Only the creator can mark a listing as departed.
        if (status === 'departed' && !isCreator) {
            return res.status(403).json({ message: "Forbidden: Only the creating agent can mark a listing as departed." });
        }

        // Rule: Only the destination agent can mark a listing as arrived or closed.
        if ((status === 'arrived' || status === 'closed') && !isDestinationAgent) {
            return res.status(403).json({ message: "Forbidden: Only the destination agent can mark a listing as arrived or closed." });
        }
        
        // Rule: A closed listing cannot be re-opened by anyone.
        if (listing.status === 'closed') {
             return res.status(403).json({ message: "This listing has been closed and cannot be modified." });
        }

        // --- END: Advanced Permission Logic ---

        // If all checks pass, update the status
        listing.status = status;
        await listing.save();

        return res.status(200).json({ message: `Listing status updated to '${status}'.`, listing });

    } catch (error) {
        console.error("Update Status Error:", error);
        return res.status(500).json({ message: "An internal server error occurred.", error: error.message });
    }
}

exports.createListing = async (req, res) => {
    const agentid = req.user.id;

    try {
        const agent = await Logistics_agents.findOne({ where: { id: agentid } });
        if (!agent) {
            return res.status(404).json({ message: "Agent profile not found." });
        }

        const {
            logistic_type, country, destination_state, destination_address, package_category,
            departure_date, departure_time, driver_name, driver_number, driver_second_number,
            price, price_per_kg, total_kg_limit, available_kg, seat_map
        } = req.body;

        if (!logistic_type || !destination_state || !departure_date || !departure_time) {
            return res.status(400).json({ message: "Logistic type, destination, and departure details are required." });
        }

        const company_id = agent.transport_company_id;
        const agent_location = agent.location;

        if (!company_id || !agent_location) {
            return res.status(403).json({ message: "Forbidden: Agent must be associated with a company and have a location set." });
        }

        const locationString = JSON.stringify(agent_location[0]);
        const searchPattern = locationString.substring(1, locationString.length - 1);

        const existingListing = await Logistic_agent_listings.findOne({
            where: {
                logistics_company_id: company_id,
                state_created_in: {
                    [Op.like]: `%${searchPattern}%`
                },
                destination_state: destination_state,
                destination_address: destination_address,
                departure_date: departure_date,
                departure_time: departure_time,

                // --- KEY CHANGE: Added logistic_type to the check ---
                logistic_type: logistic_type
            }
        });

        if (existingListing) {
            return res.status(409).json({
                message: "An active listing for this exact route, date, time, and type already exists. Please close the existing one before creating a duplicate."
            });
        }

        const listingData = {
            logistics_agent_id: agent.id,
            logistics_company_id: company_id,
            state_created_in: agent_location,
            country, destination_state, destination_address, package_category,
            departure_date, departure_time, driver_name, driver_number, driver_second_number,
            logistic_type,
            date_created: new Date().toISOString(),
            status: 'open'
        };

        if (logistic_type === 'travel') {
            if (!price || !Array.isArray(seat_map) || seat_map.length === 0) {
                return res.status(400).json({ message: "Price and a valid seat_map array are required for travel listings." });
            }
            const available_seats_count = seat_map.filter(seat => seat.booked === false).length;
            listingData.price = parseFloat(price);
            listingData.available_seats = available_seats_count;
            listingData.seat_map = seat_map;

        } else if (logistic_type === 'delivery') {
            if (!price_per_kg || !total_kg_limit) {
                return res.status(400).json({ message: "Price per kg and total kg limit are required for delivery listings." });
            }
            const total_kg = parseInt(total_kg_limit, 10);
            if (available_kg && parseInt(available_kg, 10) > total_kg) {
                return res.status(400).json({ message: "Available kg cannot be greater than the total kg limit." });
            }
            listingData.price_per_kg = parseFloat(price_per_kg);
            listingData.total_kg_limit = total_kg;
            listingData.available_kg = available_kg ? parseInt(available_kg, 10) : total_kg;

        } else {
            return res.status(400).json({ message: "Invalid logistic_type. Must be 'travel' or 'delivery'." });
        }

        const newListing = await Logistic_agent_listings.create(listingData);
        res.status(201).json({ message: 'Listing created successfully', listing: newListing });

    } catch (error) {
        console.error("Create Listing Error:", error);
        return res.status(500).json({ message: "Failed to create listing.", error: error.message });
    }
}


//update listing
exports.updateListing = async (req, res) => {
    const { listingId } = req.params; // Get listing ID from the URL, e.g., /listings/123
    const agent = req.user; // Authenticated agent

    try {
        // 1. Fetch the listing and perform security checks
        const listing = await Logistic_agent_listings.findByPk(listingId);

        if (!listing) {
            return res.status(404).json({ message: "Listing not found." });
        }

        // Ensure the agent can only edit listings belonging to their own company
        if (listing.company_id !== agent.company_id) {
            return res.status(403).json({ message: "Forbidden: You are not authorized to edit this listing." });
        }

        // 2. Check if any bookings exist for this listing
        const onlineBookingsCount = await Logistic_bookings.count({ where: { listing_id: listingId } });
        const manualBookingsCount = await Manual_terminal_bookings.count({ where: { listing_id: listingId } });
        const hasBookings = (onlineBookingsCount + manualBookingsCount) > 0;

        const updateData = {};
        const forbiddenFields = [
            'destination_state', 'destination_address', 'departure_date', 'departure_time',
            'price', 'price_per_kg', 'total_kg_limit', 'logistic_type'
        ];

        // 3. Apply business logic based on whether bookings exist
        if (hasBookings) {
            // --- SCENARIO A: LISTING IS PARTIALLY LOCKED ---
            // Check if the agent is trying to update a forbidden field
            for (const field of forbiddenFields) {
                if (req.body[field] !== undefined) {
                    return res.status(403).json({ message: `Cannot update '${field}' because this listing already has bookings.` });
                }
            }
            
            // Allow seat_map updates, but with strict validation
            if (req.body.seat_map) {
                const originalSeatMap = listing.seat_map;
                const newSeatMap = req.body.seat_map;

                if (!Array.isArray(newSeatMap) || newSeatMap.length !== originalSeatMap.length) {
                    return res.status(400).json({ message: "The updated seat map must be a valid array with the same total number of seats." });
                }

                for (const originalSeat of originalSeatMap) {
                    if (originalSeat.booked === true) {
                        const newSeatState = newSeatMap.find(s => s.seat === originalSeat.seat);
                        if (!newSeatState || newSeatState.booked === false) {
                            return res.status(403).json({
                                message: `Cannot un-book a seat that already has a booking (Seat: ${originalSeat.seat}). Please use the formal cancellation process.`
                            });
                        }
                    }
                }
                updateData.seat_map = newSeatMap;
                updateData.available_seats = newSeatMap.filter(seat => seat.booked === false).length;
            }
            
            // Explicitly allow updates to all other non-critical fields
            if (req.body.driver_name !== undefined) updateData.driver_name = req.body.driver_name;
            if (req.body.driver_number !== undefined) updateData.driver_number = req.body.driver_number;
            if (req.body.driver_second_number !== undefined) updateData.driver_second_number = req.body.driver_second_number;
            if (req.body.status !== undefined) updateData.status = req.body.status;
            if (req.body.package_category !== undefined) updateData.package_category = req.body.package_category;
            if (req.body.country !== undefined) updateData.country = req.body.country;


        } else {
            // --- SCENARIO B: LISTING IS FULLY FLEXIBLE (NO BOOKINGS) ---
            // Agent can update any field.
            for (const key in req.body) {
                if (Object.hasOwnProperty.call(req.body, key)) {
                    updateData[key] = req.body[key];
                }
            }
            if (req.body.seat_map) {
                updateData.available_seats = req.body.seat_map.filter(seat => seat.booked === false).length;
            }
            if (req.body.total_kg_limit) {
                updateData.available_kg = parseInt(req.body.total_kg_limit, 10);
            }
        }

        // 4. Perform the update if there is data to update
        if (Object.keys(updateData).length === 0) {
            return res.status(400).json({ message: "No valid fields provided for update." });
        }

        await listing.update(updateData);

        return res.status(200).json({ message: "Listing updated successfully", listing });

    } catch (error) {
        console.error("Update Listing Error:", error);
        return res.status(500).json({ message: "An internal server error occurred.", error: error.message });
    }
}
//validate bookings by agent
exports.validateBookingByAgent = async (req, res) => {
  const agentId = req.user.id; // assuming agent is logged in
  const { booking_id } = req.body;

  if (!booking_id) {
    return res.status(400).json({ message: 'Booking ID is required' });
  }

  try {
    // Find the booking using booking ID and agent ID
    const booking = await Logistic_bookings.findOne({
      where: {
        booking_id,
        logistic_agent_id: agentId
      }
    });

    if (!booking) {
      return res.status(404).json({ message: 'Booking not found for this agent' });
    }

    if (booking.status === 1) {
      return res.status(400).json({ message: 'Booking already validated' });
    }

    // Update booking status to 1 (validated)
    booking.status = 1;
    await booking.save();
     const pickup = await PickupRequests.update({status: "delivered"},{ where: { booking_id: booking_id} });
    return res.status(200).json({
      message: 'Booking validated successfully',
      booking_id: booking.booking_id,
      user_id: booking.user_id,
      status: booking.status
    });

  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}


exports.getAgentDashboardSummary = async (req, res) => {
  const agentId = req.user.id;

  try {
    const listings = await Logistic_agent_listings.findAll({
      where: { logistics_agent_id: agentId }
    });

    const totalActive = listings.filter(l => l.status === 'open').length;
    const totalInTransit = listings.filter(l => l.status === 'departed').length;
    const totalArrived = listings.filter(l => l.status === 'arrived').length;

    const deliveredBookings = await Logistic_bookings.findAll({
      where: {
        logistic_agent_id: agentId,
        status: 1 // validated
      }
    });

    const totalRevenue = deliveredBookings.length * 500;

    return res.status(200).json({
      total_active_routes: totalActive,
      total_in_transit_routes: totalInTransit,
      total_arrived_routes: totalArrived,
      total_deliveries: deliveredBookings.length,
      total_revenue: totalRevenue
    });

  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

// Get All Listings for Agent with Filters





exports.createManualTerminalBooking = async (req, res) => {
    // The authenticated user is the agent making the booking
    
    const agentid = req.user.id
    
    const bookingAgent = await Logistics_agents.findOne({id: agentid});

    // All booking details are sent in the request body
    const {
        listing_id,
        logistic_type, // 'delivery' or 'travel'
        amount_paid,
        payment_method, // 'cash', 'pos', etc.

        // Parcel details
        parcel_kg,
        sender_name,
        sender_phone,
        recipient_name,
        recipient_phone,
        recipient_address,

        // Travel details
        seat_numbers, // e.g., ["A1", "C3"]
        passenger_name,
        passenger_phone,
        emergency_contact_name,
        emergency_contact_phone

    } = req.body;

    try {
        const listing = await Logistic_agent_listings.findByPk(listing_id);

        if (!listing) {
            return res.status(404).json({ message: "Listing not found." });
        }

        // Security check: ensure the agent belongs to the company that owns the listing
        if (listing.company_id !== bookingAgent.company_id) {
            return res.status(403).json({ message: "Forbidden: You cannot book for another company's listing." });
        }

        // Validate and update listing based on booking type
        if (logistic_type === 'delivery') {
            if (!parcel_kg || !sender_name || !recipient_name) {
                return res.status(400).json({ message: 'Parcel weight and sender/recipient names are required.' });
            }
            if (parcel_kg > listing.available_kg) {
                return res.status(400).json({ message: `Booking failed. Only ${listing.available_kg}kg is available.` });
            }
            // Decrement available weight
            listing.available_kg -= parcel_kg;

        } else if (logistic_type === 'travel') {
            if (!Array.isArray(seat_numbers) || seat_numbers.length === 0 || !passenger_name) {
                return res.status(400).json({ message: 'Seat numbers and passenger name are required.' });
            }

            const seatMap = listing.seat_map || [];
            // Check if any of the requested seats are already booked
            const isSeatUnavailable = seat_numbers.some(seatNum => {
                const seatInfo = seatMap.find(s => s.seat === seatNum);
                return !seatInfo || seatInfo.booked;
            });

            if (isSeatUnavailable) {
                return res.status(400).json({ message: 'Booking failed. One or more selected seats are already taken.' });
            }

            // Update seat map and available seat count
            const updatedSeatMap = seatMap.map(s =>
                seat_numbers.includes(s.seat) ? { ...s, booked: true } : s
            );
            listing.seat_map = updatedSeatMap;
            listing.available_seats -= seat_numbers.length;
        }

        // Save the updated listing to ensure real-time inventory sync
        await listing.save();

        // Create the record in the new manual bookings table
        const manualBooking = await Manual_terminal_bookings.create({
            listing_id,
            company_id: listing.company_id,
            booking_agent_id: bookingAgent.id,
            booking_id: `MAN-${Math.floor(100000 + Math.random() * 900000)}`,
            logistic_type,
            amount_paid,
            payment_method,
            parcel_kg,
            sender_name,
            sender_phone,
            recipient_name,
            recipient_phone,
            recipient_address,
            seat_numbers,
            passenger_name,
            passenger_phone,
            emergency_contact_name,
            emergency_contact_phone,
            status: 'booked', // Initial status
            date: new Date().toISOString()
        });

        return res.status(201).json({ message: "Manual booking created successfully.", booking: manualBooking });

    } catch (err) {
        console.error("Manual Booking Error:", err);
        return res.status(500).json({ message: "Internal server error.", error: err.message });
    }
}


exports.getAgentAvailableListings = async (req, res) => {
    try {
        let page = 0;
        const pagenumber = req.query.page;
        if (!Number.isNaN(pagenumber) && pagenumber > 0) {
            page = pagenumber;
        }

        const agentid = req.user.id;
        const agent = await Logistics_agents.findOne({ where: { id: agentid } });
        if (!agent) {
            return res.status(404).json({ message: "Agent profile not found." });
        }

        const companyId = agent.company_id;
        if (!companyId) {
            return res.status(403).json({ message: "Forbidden: Agent not associated with a company." });
        }

        const agentPrimaryLocation = agent.location && agent.location[0] ? agent.location[0] : null;
        if (!agentPrimaryLocation) {
            return res.status(400).json({ message: "Agent's primary location is not set." });
        }

        const { destination_state, departure_date, status, route, logistic_type } = req.query;

        const locationString = JSON.stringify(agentPrimaryLocation);
        const searchPattern = locationString.substring(1, locationString.length - 1);

        const filters = {
            logistics_company_id: companyId,
            status: status || 'open',
            state_created_in: {
                [Op.like]: `%${searchPattern}%`
            }
        };

        if (route && route.includes(' - ')) {
            const destination = route.split(' - ')[1];
            if (destination) {
                filters.destination_state = destination;
            }
        } else if (destination_state) {
            filters.destination_state = destination_state;
        }

        if (departure_date) {
            filters.departure_date = departure_date;
        }
        
        if (logistic_type) {
            filters.logistic_type = logistic_type;
        }

        const listings = await Logistic_agent_listings.findAll({
            where: filters,
            order: [
                ['departure_date', 'ASC'],
                ['departure_time', 'ASC']
            ]
        });
        
        // --- ADD THIS BLOCK to parse the JSON strings ---
        const formattedListings = listings.map(listing => {
            const data = listing.toJSON(); // Get a plain object

            try {
                data.seat_map = JSON.parse(data.seat_map || '[]');
            } catch (e) {
                data.seat_map = []; // Default to empty array on error
            }

            try {
                data.state_created_in = JSON.parse(data.state_created_in || '[]');
            } catch (e) {
                data.state_created_in = []; // Default to empty array on error
            }

            return data;
        });
        // --- END OF BLOCK ---
        
        // Pass the newly formatted data to your pagination function
        const paginatedData = await pagination(formattedListings, page);
        return res.status(200).json(paginatedData);

    } catch (err) {
        console.error("Get Agent Available Listings Error:", err);
        return res.status(500).json({ message: "An internal server error occurred.", error: err.message });
    }
}



exports.getAgentActiveRoutes = async (req, res) => {
    try {
        const agentid = req.user.id;
        const agent = await Logistics_agents.findOne({ where: { id: agentid } });

        if (!agent) {
            return res.status(404).json({ message: "Agent profile not found." });
        }

        // --- START: Corrected Location Parsing ---
        let agentLocationArray = [];
        try {
            // Safely parse the location string into an array
            if (agent.location && typeof agent.location === 'string') {
                agentLocationArray = JSON.parse(agent.location);
            } else if (Array.isArray(agent.location)) {
                // Handle cases where it might already be an object
                agentLocationArray = agent.location;
            }
        } catch (e) {
            
            return res.status(500).json({ message: "Agent location data is corrupted." });
        }

        const companyId = agent.company_id;
        const originState = agentLocationArray.length > 0 ? agentLocationArray[0].state : null;
        // --- END: Corrected Location Parsing ---

        if (!companyId || !originState) {
            return res.status(400).json({ message: "Agent company or location is missing." });
        }
        
        // Find all unique destination states for open listings from the agent's company and origin state
        const availableDestinations = await Logistic_agent_listings.findAll({
            where: {
                logistics_company_id: companyId,
                status: 'open',
                // --- KEY CHANGE: Use Op.like for MariaDB compatibility ---
                state_created_in: {
                    [Op.like]: `%"state":"${originState}"%`
                }
            },
            // This is the key to efficiency: select only the unique destination_state values
            attributes: [
                [Sequelize.fn('DISTINCT', Sequelize.col('destination_state')), 'destination_state']
            ],
            raw: true // Ensures the output is a clean array of objects
        });

        // Format the results into "Origin - Destination" strings
        const routes = availableDestinations.map(item => `${originState} - ${item.destination_state}`);

        return res.status(200).json({ routes });

    } catch (err) {
       
        return res.status(500).json({ message: "An internal server error occurred.", error: err.message });
    }
}



exports.getArrivingListings = async (req, res) => {
    try {
        const agent = req.user; // Authenticated agent
        const agentLocation = agent.location && agent.location[0] ? agent.location[0] : null;

        if (!agent.company_id || !agentLocation) {
            return res.status(403).json({ message: "Agent must be associated with a company and have a location." });
        }

        const arrivingListings = await Logistic_agent_listings.findAll({
            where: {
                logistics_company_id: agent.company_id,
                // Find listings where the destination matches the agent's specific branch
                destination_state: agentLocation.state,
                destination_address: agentLocation.address,
                // Find trips that are on their way or have just arrived
                status: {
                    [Op.in]: ['departed', 'in_transit', 'arrived']
                }
            },
            order: [['departure_date', 'DESC'], ['departure_time', 'DESC']]
        });

        return res.status(200).json(arrivingListings);

    } catch (error) {
        console.error("Get Arriving Listings Error:", error);
        return res.status(500).json({ message: "An internal server error occurred.", error: error.message });
    }
}

///////////////////////////////////////////////////////////////////////////////END///////////////////////////////////////////////////////////////////////////////////////




//get active routes for both agent and customers
exports.getAllActiveRoutes = async (req, res) => {
  try {
    const activeListings = await Logistic_agent_listings.findAll({
      where: { status: 'active' }
    });

    const routesSet = new Set();

    for (const listing of activeListings) {
      const agent = await Logistics_agents.findByPk(listing.logistics_agent_id);
      const routeKey = `${agent.state} - ${listing.destination_state}`;
      routesSet.add(routeKey);
    }

    const routes = Array.from(routesSet);

    return res.status(200).json({ routes });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}

exports.requestForgotPasswordOTP = async (req, res) => {
  const { email, userType } = req.body;

  try {
    let userModel;
    if (userType === 'agent') userModel = Logistics_agents;
    else if (userType === 'customer') userModel = Mycroshop_logistics_customers;
    else return res.status(400).json({ message: 'Invalid user type' });

    const user = await userModel.findOne({ where: { email } });
    if (!user) return res.status(404).json({ message: 'User not found' });

    const otp = generateOtp();
    const expiresAt = Date.now() + 5 * 60 * 1000; // 5 mins
    const encryptedPayload = encryptOtpPayload(otp, expiresAt);

    const emailHtml = await ejs.renderFile(
      path.join(__dirname, '../service/templates/otpTemplate.ejs'),
      { name: user.name, otp }
    );

    await sendEmailWithTemplate(email, 'Reset Password - OTP', emailHtml);

    return res.status(200).json({
      message: 'OTP sent successfully',
      token: encryptedPayload // Store this temporarily on frontend
    });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}

exports.verifyForgotPasswordOTP = async (req, res) => {
  const { enteredOtp, token } = req.body;

  try {
    const { otp, expiresAt } = decryptOtpPayload(token);

    if (Date.now() > expiresAt) {
      return res.status(400).json({ message: 'OTP expired' });
    }

    if (enteredOtp !== otp) {
      return res.status(400).json({ message: 'Invalid OTP' });
    }

    return res.status(200).json({ message: 'OTP verified successfully' });
  } catch (err) {
    return res.status(400).json({ message: 'Invalid or tampered token' });
  }
}

exports.resetForgottenPassword = async (req, res) => {
  const { email, newPassword, userType } = req.body;

  try {
    let userModel;
    if (userType === 'agent') userModel = Logistics_agents;
    else if (userType === 'customer') userModel = Mycroshop_logistics_customers;
    else return res.status(400).json({ message: 'Invalid user type' });

    const user = await userModel.findOne({ where: { email } });
    if (!user) return res.status(404).json({ message: 'User not found' });

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;
    await user.save();

    return res.status(200).json({ message: 'Password reset successfully' });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}



exports.getBookingsForListing = async (req, res) => {
    const { listing_id } = req.params;

    try {
        // 1. Fetch the main listing details and the agent who created it
        const listing = await Logistic_agent_listings.findByPk(listing_id);
        if (!listing) {
            return res.status(404).json({ message: "Listing not found." });
        }

        const listingAgent = await Logistics_agents.findByPk(listing.logistics_agent_id, {
            attributes: ['id', 'name', 'phone', 'email']
        });

        // 2. Fetch all bookings from both tables concurrently
        const [onlineBookings, manualBookings] = await Promise.all([
            Logistic_bookings.findAll({ where: { listing_id } }),
            Manual_terminal_bookings.findAll({ where: { listing_id } })
        ]);

        // 3. Pre-fetch all necessary customer details for the online bookings
        const onlineCustomerIds = [...new Set(onlineBookings.map(b => b.user_id))];
        let customerMap = {};

        if (onlineCustomerIds.length > 0) {
            // NOTE: Query your actual customer table here.
            // This example assumes one customer table. You might need to query two
            // (e.g., Business and Mycroshop_logistics_customers) if user types differ.
            const customers = await Mycroshop_logistics_customers.findAll({
                where: { id: onlineCustomerIds },
                attributes: ['id', 'name', 'phone_number', 'email'] // Adjust attributes as needed
            });
            
            customerMap = customers.reduce((map, customer) => {
                map[customer.id] = customer;
                return map;
            }, {});
        }

        // 4. Process all bookings into a clean manifest
        let passengers = [];
        let parcels = [];

        // Process Online Bookings
        for (const booking of onlineBookings) {
            const customer = customerMap[booking.user_id];
            if (!customer) continue; // Skip if customer data not found

            if (booking.logistic_type === 'travel') {
                passengers.push({
                    booking_id: booking.booking_id,
                    passenger_name: customer.name, // From customer profile
                    passenger_phone: customer.phone_number, // From customer profile
                    seats: booking.seat_number,
                    emergency_contact: {
                        name: booking.emergency_contact_name, // From booking record
                        phone: booking.emergency_contact_phone // From booking record
                    },
                    source: 'online'
                });
            } else if (booking.logistic_type === 'delivery') {
                parcels.push({
                    booking_id: booking.booking_id,
                    parcel_kg: booking.parcel_kg,
                    sender: {
                        name: customer.name, // From customer profile
                        phone: customer.phone_number // From customer profile
                    },
                    recipient: {
                        name: booking.recipient_name, // From booking record
                        phone: booking.recipient_phone, // From booking record
                        address: booking.recipient_address // From booking record
                    },
                    source: 'online'
                });
            }
        }

        // Process Manual Bookings
        for (const booking of manualBookings) {
            if (booking.logistic_type === 'travel') {
                passengers.push({
                    booking_id: booking.booking_id,
                    passenger_name: booking.passenger_name, // From manual booking record
                    passenger_phone: booking.passenger_phone, // From manual booking record
                    seats: booking.seat_numbers,
                    emergency_contact: {
                        name: booking.emergency_contact_name,
                        phone: booking.emergency_contact_phone
                    },
                    source: 'manual'
                });
            } else if (booking.logistic_type === 'delivery') {
                parcels.push({
                    booking_id: booking.booking_id,
                    parcel_kg: booking.parcel_kg,
                    sender: {
                        name: booking.sender_name,
                        phone: booking.sender_phone
                    },
                    recipient: {
                        name: booking.recipient_name,
                        phone: booking.recipient_phone,
                        address: booking.recipient_address
                    },
                    source: 'manual'
                });
            }
        }

        // 5. Return the final, structured manifest object
        return res.status(200).json({
            listing_details: listing,
            listing_agent: listingAgent,
            manifest: {
                passengers,
                parcels
            }
        });

    } catch (err) {
        console.error("Get Manifest Error:", err);
        return res.status(500).json({ message: "Internal server error.", error: err.message });
    }
}



