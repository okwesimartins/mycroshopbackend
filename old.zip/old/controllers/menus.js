// const db = require("../models");
// const Sequelize  = require('sequelize')
// const Op = db.Sequelize.Op;
// const Menus = db.menus
// const Childmenu = db.child_menu

// exports.getallMenus = async (req, res, next)=>{
//     const getAllmenus = await Menus.findAll()
    
//     const menuArray = []
//     let errorMessage
//     for(const value of getAllmenus){
        
//         try{
//             const getChildmenu = await Childmenu.findAll({where:{parent_id:value.id}})
//         const menuInfo = {
//             "menu_name" : value.menu_name,
//             "child_menu" : getChildmenu
//         }
//         }catch(error){
//             errorMessage = error
            
//             break
//         }
        
        
//         menuArray.push(menuInfo)
//     }
    
//     if(errorMessage){
//         return res.status(200).json(errorMessage)
//     }
//     return res.status(200).json(menuArray)
// }