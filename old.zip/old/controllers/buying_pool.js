const db = require("../models");
const axios = require('axios');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const dayjs = require('dayjs');
const ejs = require('ejs');
const path = require('path');
const fs = require('fs');
const { Op } = require('sequelize')
const { generateOtp, encryptOtpPayload, decryptOtpPayload } = require('../utils/otpUtils');
const  Sequelize= db.sequelize
const jwt = require("jsonwebtoken")
const Buying_pools = db.buying_pools
const Buying_pool_customers=db.buying_pool_customers
const Buying_pool_joined_by_customers =  db.buying_pool_joined_by_customers
const Mycroshop_suppliers = db.mycroshop_suppliers 
const Form_expiration_token = db.form_expiration_token
const Buying_pool_subscription_payment = db.buying_pool_subscription_payment
const Subscription_plans = db.subscription_plans
const Business_notifications = db.business_notifications
const Buying_pool_suppliers_sub_plan = db.buying_pool_suppliers_sub_plan
const Category = db.categories
const Buying_pool_extra_purchases =  db.buying_pool_extra_purchases
const { sendEmailWithTemplate } = require('../service/mail-services.js');

const PAYSTACK_BASE_URL = 'https://api.paystack.co';
const IMAGE_BASE_URL = 'https://backend.mycroshop.com/public/image/'
const headers = {
  'Authorization': 'Bearer sk_live_32dac38a3660d1093553eed841f7c83421d9767b',
  'Content-Type': 'application/json',
};

//sk_live_32dac38a3660d1093553eed841f7c83421d9767b
//sk_test_0255f1f40367a9712aba18e65864b3440d10d879
const INTERNAL_TOKEN_SECRET = 'tywuwiiiwoohhwbbbhhwhhbbnn';
const pagination = async (items, page) => {

  var page = page || 1,
  per_page = 10,
  offset = (page - 1) * per_page,
  paginatedItems = items.slice(offset).slice(0, per_page),
  total_pages = Math.ceil(items.length / per_page);
  
  return {
  page: page,
  per_page: per_page,
  pre_page: page - 1 ? page - 1 : null,
  next_page: (total_pages > page) ? page + 1 : null,
  total: items.length,
  total_pages: total_pages,
  data: paginatedItems
  };
  
}
//generate mycroshop supplier's form token


// Generate Token for Supplier Form (includes mycroshop commission)
exports.generateSupplierFormToken = async (req, res) => {
  const { mycroshop_commission } = req.body;

  if (!mycroshop_commission) {
    return res.status(400).json({ message: 'Mycroshop commission is required' });
  }

  try {
    const rawToken = crypto.randomBytes(20).toString('hex');
    const expirationTime = dayjs().add(30, 'minute').format('YYYY-MM-DD HH:mm:ss');

    // Create encoded token that contains the commission
    const encodedToken = jwt.sign(
      { rawToken, mycroshop_commission },
      INTERNAL_TOKEN_SECRET,
      { expiresIn: '30m' }
    );

    // Save raw token to DB
    await Form_expiration_token.create({
      token: rawToken,
      expiration_date_and_time: expirationTime,
      trials: 0
    });

    return res.status(201).json({
      message: 'Token generated successfully',
      token: encodedToken,
      expires_at: expirationTime
    });

  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
}


//register mycroshop buying pool suppliers
exports.registerSupplier = async (req, res) => {
  const { supplier_name, email, phone_number, password, token } = req.body;

  if (!supplier_name || !email || !phone_number || !password || !token) {
    return res.status(400).json({ message: 'All fields are required: supplier_name, email, phone_number, password, token' });
  }

  try {
    // Decode token
    let decoded;
    try {
      decoded = jwt.verify(token, INTERNAL_TOKEN_SECRET);
    } catch (err) {
      return res.status(403).json({ message: 'Invalid or expired token' });
    }

    const { rawToken, mycroshop_commission } = decoded;

    const tokenRecord = await Form_expiration_token.findOne({ where: { token: rawToken } });

    if (!tokenRecord) return res.status(400).json({ message: 'Invalid token record' });

    if (dayjs().isAfter(dayjs(tokenRecord.expiration_date_and_time))) {
      return res.status(403).json({ message: 'Token has expired' });
    }

    if (tokenRecord.trials >= 1) {
      return res.status(403).json({ message: 'Token already used' });
    }

    // Prevent duplicate registration
    const existing = await Mycroshop_suppliers.findOne({ where: { email, phone_number, supplier_name } });
    if (existing) return res.status(400).json({ message: 'Supplier already exists' });

    const hashedPassword = await bcrypt.hash(password, 10);

    const supplier = await Mycroshop_suppliers.create({
      supplier_name,
      email,
      phone_number,
      password: hashedPassword,
      date: dayjs().format('YYYY-MM-DD'),
      status: 1,
      mycroshop_sub_commission: mycroshop_commission
    });

    // Mark token as used
    tokenRecord.trials = 1;
    await tokenRecord.save();

    return res.status(201).json({ message: 'Supplier registered successfully', supplier });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
}


//login supplier 
exports.loginSupplier = async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password)
    return res.status(400).json({ message: 'Email and password are required' });

  try {
    const supplier = await Mycroshop_suppliers.findOne({ where: { email } });

    if (!supplier)
      return res.status(404).json({ message: 'Supplier not found' });

    const match = await bcrypt.compare(password, supplier.password);
    if (!match)
      return res.status(401).json({ message: 'Invalid credentials' });

    const token = jwt.sign(
      { id: supplier.id, email: supplier.email, privileges : ["create_pool", "update_pool", "view_supplier_pool_details","supplier"] },
      INTERNAL_TOKEN_SECRET // This disables expiration
    );

    return res.status(200).json({ message: 'Login successful',supplier_name: supplier.supplier_name, token });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
}

//supplier link paystack account to pre order management system 
exports.linkPaystack = async (req, res)=>{
    const {paystack_public_key, paystack_secrete_key} = req.body
    
    if(!paystack_public_key || !paystack_secrete_key){
        return res.status(400).json({message: "All Fields are required"});
    }
    const supplierid = req.user.id
    const supplier = await Mycroshop_suppliers.update({paystack_public_key:paystack_public_key,paystack_secrete_key:paystack_secrete_key},{where:{id:supplierid}});
    
    
     return res.status(200).json({message: "Success"});
}

//update suplier password from dashboard
exports.updatesupplierPassword = async (req, res)=>{
    const { oldpassword, newpassword } = req.body;
    
    const supplierid = req.user.id
    
    const supplier = await Mycroshop_suppliers.findOne({ where: { id:supplierid } });
    
    const match = await bcrypt.compare(oldpassword, supplier.password);
    
    if (!match)
      return res.status(401).json({ message: 'Invalid credentials' });
      
      const hashedPassword = await bcrypt.hash(newpassword, 10);
      
       await Mycroshop_suppliers.update({password:hashedPassword},{where:{id:supplierid}})
       
       return res.status(200).json({message: "Success"});

}


exports.requestForgotPasswordOTP = async (req, res) => {
  const { email, userType } = req.body;

  try {
    let userModel;
    if (userType === 'supplier') userModel = Mycroshop_suppliers;
    else if (userType === 'customer') userModel = Buying_pool_customers;
    else return res.status(400).json({ message: 'Invalid user type' });

    const user = await userModel.findOne({ where: { email } });
    if (!user) return res.status(404).json({ message: 'User not found' });
     
     let name= ""
     if(userType == 'supplier'){
         name = 	user.supplier_name
     }
     
     if(userType == 'customer'){
         name = 	user.name
     }
    const otp = await generateOtp();
    const expiresAt = Date.now() + 5 * 60 * 1000; // 5 mins
    const encryptedPayload = await encryptOtpPayload(otp, expiresAt);

    const emailHtml = await ejs.renderFile(
      path.join(__dirname, '../service/templates/otpTemplate.ejs'),
      { name: name, otp }
    );

    await sendEmailWithTemplate(email, 'Reset Password - OTP', emailHtml);

    return res.status(200).json({
      message: 'OTP sent successfully',
      token: encryptedPayload
    });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}

exports.verifyForgotPasswordOTP = async (req, res) => {
  const { enteredOtp, token } = req.body;

  try {
    const { otp, expiresAt } = await decryptOtpPayload(token);

    if (Date.now() > expiresAt) {
      return res.status(400).json({ message: 'OTP expired' });
    }

    if (enteredOtp != otp) {
      return res.status(400).json({ message: 'Invalid OTP' });
    }

    return res.status(200).json({ message: 'OTP verified successfully' });
  } catch (err) {
    return res.status(400).json({ message: 'Invalid or tampered token' });
  }
}

exports.resetForgottenPassword = async (req, res) => {
  const { email, newPassword, userType } = req.body;

  try {
    let userModel;
    if (userType === 'supplier') userModel = Mycroshop_suppliers;
    else if (userType === 'customer') userModel = Buying_pool_customers;
    else return res.status(400).json({ message: 'Invalid user type' });

    const user = await userModel.findOne({ where: { email } });
    if (!user) return res.status(404).json({ message: 'User not found' });

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;
    await user.save();

    return res.status(200).json({ message: 'Password reset successfully' });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}



//login customer
exports.loginPoolCustomer = async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ message: 'Email and password required' });

  try {
    const customer = await Buying_pool_customers.findOne({ where: { email } });
    if (!customer) return res.status(404).json({ message: 'Customer not found' });

    const valid = await bcrypt.compare(password, customer.password);
    if (!valid) return res.status(401).json({ message: 'Invalid credentials' });

    const token = jwt.sign(
      { id: customer.id, email: customer.email, privileges : ["view_customer_pool_details","pool_customer"]},
      INTERNAL_TOKEN_SECRET // no expiration
    );

    return res.status(200).json({ token, customer });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
}


//getLoggedInSupplier
exports.getLoggedInSupplier = async (req, res) => {
  const supplierId = req.user.id;
  if (!supplierId) return res.status(401).json({ message: 'Unauthorized' });

  try {
    const supplier = await Mycroshop_suppliers.findByPk(supplierId, {
      attributes: ['id', 'supplier_name', 'email', 'phone_number', 'status', 'mycroshop_sub_commission', 'date', 'paystack_public_key', 'paystack_secrete_key']
    });
    
    if (!supplier) return res.status(404).json({ message: 'Supplier not found' });
    

     const supplierplan = await Buying_pool_suppliers_sub_plan.findOne({where:{"mycroshop_supplier_id":supplierId }, attributes: ['plan_description', 'monthly_duration', 'yearly_sub_amount']})
     
     let paymentaccountLinked = "No"
     if(supplier.paystack_public_key && supplier.paystack_secrete_key){
         paymentaccountLinked = "Yes"
     }
    return res.status(200).json({ supplier, supplierplan, paymentaccountLinked});
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
}


// getLoggedInCustomer
exports.getLoggedInCustomer = async (req, res) => {
  const customerId = req.user?.id;
  if (!customerId) return res.status(401).json({ message: 'Unauthorized' });

  try {
    const customer = await Buying_pool_customers.findByPk(customerId, {
      attributes: ['id', 'name', 'email', 'phone_number', 'date']
    });

    if (!customer) return res.status(404).json({ message: 'Customer not found' });

    // Get active subscription
    const activeSub = await Buying_pool_subscription_payment.findOne({
      where: {
        buying_pool_customer_id: customerId,
        expiration_date: { [Op.gte]: dayjs().format('YYYY-MM-DD') }
      },
      order: [['date', 'DESC']]
    });

    const now = dayjs();
    const cutoff = now.subtract(48, 'hour').format('YYYY-MM-DD HH:mm:ss');

    const scope =
      activeSub?.sub_type === 'supplier' && activeSub.mycroshop_supplier_id
        ? { mycroshop_supplier_id: activeSub.mycroshop_supplier_id }
        : {};

    const recentPools = await Buying_pools.findAll({
      where: {
        ...scope,
        created_at_date: { [Op.gte]: cutoff }
      }
    });

    const joined = await Buying_pool_joined_by_customers.findAll({
      where: { customer_id: customerId },
      attributes: ['pool_id']
    });

    const joinedPoolIds = joined.map(j => j.pool_id);

    const processingUpdates = await Buying_pools.findAll({
      where: {
        id: { [Op.in]: joinedPoolIds },
        processing_date: { [Op.gte]: cutoff }
      }
    });

    const arrivedUpdates = await Buying_pools.findAll({
      where: {
        id: { [Op.in]: joinedPoolIds },
        arrived_date: { [Op.gte]: cutoff }
      }
    });

    const notifications = [
      ...recentPools.map(p => ({
        type: 'new_pool',
        pool_title: p.pool_title,
        product_name: p.product_name,
        supplier_id: p.mycroshop_supplier_id,
        date: p.created_at_date
      })),
      ...processingUpdates.map(p => ({
        type: 'pool_processing',
        pool_title: p.pool_title,
        status: 'processing',
        date: p.processing_date
      })),
      ...arrivedUpdates.map(p => ({
        type: 'pool_arrived',
        pool_title: p.pool_title,
        status: 'arrived',
        date: p.arrived_date
      }))
    ];

    return res.status(200).json({
      customer,
      notifications
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};


//generate payment link for pool sub
exports.initializePoolSubPayment = async (req, res) => {
  const { email, name, phone_number, plan_id, sub_type, supplier_id } = req.body;

  if (!email || !name || !phone_number || !plan_id || !sub_type || !supplier_id) {
    return res.status(400).json({ message: 'Missing required fields' });
  }

  if (sub_type === 'supplier' && !supplier_id) {
    return res.status(400).json({ message: 'Supplier ID is required for supplier subscriptions' });
  }

  try {
    const plan = await Buying_pool_suppliers_sub_plan.findOne({ where: { id: plan_id } });
    const checkmycroshopsubPlan = await Subscription_plans.findOne({where:{id: plan_id, plan_name: "Buying Pool"}})
    
    const getSupplierinfo = await Mycroshop_suppliers.findOne({where:{id: supplier_id}})
    
    if(!getSupplierinfo){
        return res.status(400).json({ message: 'invalid supplier id passed' });
    }
    
    
    if (!plan && !checkmycroshopsubPlan) return res.status(404).json({ message: 'Plan not found' });

    const isExistingCustomer = await Buying_pool_customers.findOne({ where: { email } });

    // Check if user already has an active subscription to this plan
    if (isExistingCustomer) {
      const activeSub = await Buying_pool_subscription_payment.findOne({
        where: {
          buying_pool_customer_id: isExistingCustomer.id,
          plan_id,
          expiration_date: {
            [Op.gte]: dayjs().format('YYYY-MM-DD')
          }
        },
        order: [['date', 'DESC']]
      });

      if (activeSub) {
        return res.status(409).json({ message: 'You already have an active subscription for this plan' });
      }
    }
    
    let durationMonths
    let amountToPay
    if(plan && sub_type === 'supplier'){
          durationMonths = parseInt(plan.monthly_duration);
          amountToPay = parseInt(plan.yearly_sub_amount);
    }
    
    if(checkmycroshopsubPlan){
         durationMonths = 12;
         amountToPay = parseInt(checkmycroshopsubPlan.yearly_fee);
    }
   

    const metadata = {
      is_existing: !!isExistingCustomer,
      name,
      email,
      phone_number,
      plan_id,
      sub_type,
      supplier_id: supplier_id ? supplier_id : null,
      duration_months: durationMonths,
    };
    
    
    const paystackRes = await axios.post(
      `${PAYSTACK_BASE_URL}/transaction/initialize`,
      {
        email,
        amount: amountToPay * 100,
        metadata,
        callback_url: `https://preorder.mycroshop.com/subscribe/success`,
        channels: ['bank_transfer']
      },
      { headers }
    );
  
    return res.status(200).json({
      message: 'Redirect to Paystack',
      supplier_name: getSupplierinfo.supplier_name,
      authorization_url: paystackRes.data.data.authorization_url
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
}



//verify buying pool sub payments
exports.subscribeToPoolPlan = async (req, res) => {
  const { reference} = req.query;

  if (!reference) return res.status(400).json({ message: 'Payment reference is required' });

  const transaction = await Sequelize.transaction();

  try {
      
          
    //check if payment reference exist 
    const checkReference = await Buying_pool_subscription_payment.findOne({where:{payment_reference:reference}})
    
    if(checkReference){
           return res.status(500).json({ message: "duplicate entry" });
    }

    // Verify payment with Paystack
    const verifyRes = await axios.get(
      `${PAYSTACK_BASE_URL}/transaction/verify/${reference}`,
      { headers }
    );

    const paymentData = verifyRes.data.data;
    if (paymentData.status !== 'success') {
     
      return res.status(400).json({ message: 'Payment was not successful' });
    }

    const {
      is_existing,
      email,
      name,
      phone_number,
      plan_id,
      sub_type,
      supplier_id,
      duration_months,
    } = paymentData.metadata;

    let customer = null;
    let tempPassword = null;

    if (is_existing === true || is_existing === 'true') {
      customer = await Buying_pool_customers.findOne({ where: { email }, transaction: t });
      if (!customer) {
       
        return res.status(404).json({ message: 'Customer marked as existing not found' });
      }
    } else {
      tempPassword = crypto.randomBytes(4).toString('hex');
      const hashedPassword = await bcrypt.hash(tempPassword, 10);
      
      customer = await Buying_pool_customers.create({
        name,
        email,
        phone_number,
        password: hashedPassword,
        date: dayjs().format('YYYY-MM-DD'),
      }, { transaction});

      
    }

    const expirationDate = dayjs().add(duration_months, 'month').format('YYYY-MM-DD');

    await Buying_pool_subscription_payment.create({
      buying_pool_customer_id: customer.id,
      payment_reference: reference,
      plan_id,
      sub_type,
      date: dayjs().format('YYYY-MM-DD'),
      supplier_id,
      expiration_date: expirationDate,
    }, { transaction});


 if (tempPassword) {
        // Render HTML email content from EJS template manually
const supplierDisplayName = sub_type === 'supplier' && supplier_id
    ? (await Mycroshop_suppliers.findByPk(supplier_id))?.supplier_name || 'Mycroshop'
    : 'Mycroshop';

  const templatePath = path.join(__dirname, '../service/templates/buyingPoolLoginDetailsEmail.ejs');

  const emailHtml = await ejs.renderFile(templatePath, {
    name: customer.name,
    email: customer.email,
    password: tempPassword,
    supplierName: supplierDisplayName
  });

  const emailSubject = `Welcome to ${supplierDisplayName} Buying Pool`;

  const emailSent = await sendEmailWithTemplate(
    customer.email,
    emailSubject,
    emailHtml
  );


// Log full HTML to business_notifications
await Business_notifications.create({
  message: emailHtml,
  business_id: customer.id,
  business_type: "pool_customer",
  sent_status: emailSent ? 1 : 0,
},{ transaction });
    }
    await transaction.commit();

    return res.status(200).json({ message: 'Subscription created successfully' });

  } catch (error) {
    await transaction.rollback();
    return res.status(500).json({ message: error.message });
  }
}

//create pool sub plans 
exports.createSupplierPoolSubPlan = async (req, res) => {
  const supplierId = req.user?.id;
  const { plan_description, monthly_duration, yearly_sub_amount } = req.body;

  if (!plan_description || !monthly_duration || !yearly_sub_amount) {
    return res.status(400).json({
      message: 'Missing required fields: plan_description, monthly_duration, yearly_sub_amount',
    });
  }

  if (!supplierId) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  try {
    // Sanitize and parse amount
    const cleanAmount = parseInt(String(yearly_sub_amount).replace(/[^\d]/g, ''), 10);

    if (isNaN(cleanAmount) || cleanAmount <= 0) {
      return res.status(400).json({ message: 'Invalid yearly_sub_amount value' });
    }

    // Prevent multiple plans
    const existingPlan = await Buying_pool_suppliers_sub_plan.findOne({
      where: { mycroshop_supplier_id: supplierId },
    });

    if (existingPlan) {
      return res.status(400).json({ message: 'You already have a subscription plan. Only one plan is allowed.' });
    }

    const plan = await Buying_pool_suppliers_sub_plan.create({
      mycroshop_supplier_id: supplierId,
      plan_description,
      monthly_duration,
      yearly_sub_amount: cleanAmount,
    });

    return res.status(201).json({
      message: 'Subscription plan created successfully',
      plan,
    });

  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
}


//update sub plan 
exports.updateSupplierPoolSubPlan = async (req, res) => {
  const supplierId = req.user?.id;
  const { plan_description, monthly_duration, yearly_sub_amount } = req.body;

  if (!supplierId) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  try {
    const plan = await Buying_pool_suppliers_sub_plan.findOne({
      where: { mycroshop_supplier_id: supplierId },
    });

    if (!plan) {
      return res.status(404).json({ message: 'No subscription plan found for this supplier' });
    }

    let updateData = {};

    if (plan_description) updateData.plan_description = plan_description;
    if (monthly_duration) updateData.monthly_duration = monthly_duration;

    if (yearly_sub_amount) {
      const cleanAmount = parseInt(String(yearly_sub_amount).replace(/[^\d]/g, ''), 10);
      if (isNaN(cleanAmount) || cleanAmount <= 0) {
        return res.status(400).json({ message: 'Invalid yearly_sub_amount value' });
      }
      updateData.yearly_sub_amount = cleanAmount;
    }

    await Buying_pool_suppliers_sub_plan.update(updateData, {
      where: { id: plan.id }
    });

    return res.status(200).json({ message: 'Subscription plan updated successfully' });

  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
}


//create buying pool
exports.createPool = async (req, res) => {
  const supplierId = req.user.id;
  if (!supplierId) return res.status(401).json({ message: 'Unauthorized' });

  const {
    product_name,
    price_per_unit,
    product_description,
    pool_title,
    minimum_order_quantity,
    target_quantity, // may be used as pool-wide target even when variations exist
    min_buyers,
    max_buyers,
    pool_start_date,
    pool_end_date,
    shipping_destination,
    terms_and_condition,
    category_id,
    variation
  } = req.body;

  if (!product_name || !pool_title || !pool_start_date || !min_buyers || !max_buyers || !shipping_destination) {
    return res.status(400).json({ message: 'Missing required fields' });
  }

  // ---- Parse variations (optional) ----
  let parsedVariation = null;
  let hasVariation = false;
  if (variation) {
    try {
      parsedVariation = typeof variation === 'string' ? JSON.parse(variation) : variation;
      if (Array.isArray(parsedVariation) && parsedVariation.length > 0) {
        hasVariation = true;
      }
    } catch (err) {
      return res.status(400).json({ message: `Invalid variation JSON format: ${err.message}` });
    }
  }

  // ---- Pricing rules (unchanged) ----
  if (hasVariation) {
    if (price_per_unit) {
      return res.status(400).json({ message: "price_per_unit must be empty when variations are provided." });
    }
  } else {
    if (!price_per_unit) {
      return res.status(400).json({ message: "price_per_unit is required for a product without variations." });
    }
  }

  // ---- New Target rules ----
  // - If no variations: top-level target_quantity is required (pool-wide target)
  // - If variations exist: per-variation target_quantity is OPTIONAL; however at least one target must exist
  //   (either top-level target_quantity OR at least one variation.target_quantity)
  const int = (v) => {
    const n = parseInt(v, 10);
    return Number.isFinite(n) ? n : 0;
  };

  if (!hasVariation) {
    if (!target_quantity || int(target_quantity) <= 0) {
      return res.status(400).json({ message: "target_quantity is required and must be > 0 for a product without variations." });
    }
  }

  // Validate variation structure (if any)
  if (hasVariation) {
    const ids = new Set();
    let anyVariationHasTarget = false;

    for (const [index, item] of parsedVariation.entries()) {
      if (typeof item !== 'object' || Array.isArray(item) || item === null) {
        return res.status(400).json({ message: `Variation at index ${index} must be a valid object` });
      }

      const { id, price_per_unit: varPrice, target_quantity: varTarget, length, size, color, material, weight } = item;

      if (!id) {
        return res.status(400).json({ message: `id is required in variation at index ${index}` });
      }
      if (!varPrice) {
        return res.status(400).json({ message: `price_per_unit is required in variation at index ${index}` });
      }
      if (ids.has(String(id))) {
        return res.status(400).json({ message: `Duplicate id found in variation at index ${index}` });
      }
      ids.add(String(id));

      // target_quantity is now OPTIONAL; if provided and > 0, mark it
      if (varTarget && int(varTarget) > 0) anyVariationHasTarget = true;

      // keep your "at least one optional field" rule
      const optionalFields = [length, size, color, material, weight];
      const hasOptional = optionalFields.some(val => val !== undefined && val !== null && String(val).trim() !== '');
      if (!hasOptional) {
        return res.status(400).json({ message: `At least one optional field (e.g., color, size) must be provided in variation at index ${index}` });
      }
    }

    const topLevelTargetOk = !!target_quantity && int(target_quantity) > 0;
    if (!topLevelTargetOk && !anyVariationHasTarget) {
      return res.status(400).json({ message: "Provide a pool-wide target_quantity or at least one variation.target_quantity (> 0)." });
    }
  }

  // ---- Images (unchanged) ----
  const images = req.files && req.files['images'] ? req.files['images'] : [];
  if (images.length === 0) {
    return res.status(400).json({ message: 'At least one product image is required' });
  }
  const product_image = images[0].filename;

  try {
    const existingPool = await Buying_pools.findOne({
      where: { pool_title, mycroshop_supplier_id: supplierId }
    });
    if (existingPool) {
      return res.status(400).json({ message: 'A pool with this title already exists for this supplier' });
    }

    const pool = await Buying_pools.create({
      product_name,
      // keep price rule
      price_per_unit: hasVariation ? null : price_per_unit,
      // top-level target may be used even when variations exist (or null if variations carry targets)
      target_quantity: target_quantity || null,
      category_id,
      product_description,
      product_image,
      pool_title,
      minimum_order_quantity,
      min_buyers,
      max_buyers,
      pool_start_date,
      pool_end_date,
      shipping_destination,
      terms_and_condition,
      pool_status: 'active',
      mycroshop_supplier_id: supplierId,
      created_at_date: dayjs().format('YYYY-MM-DD'),
      // do NOT stringify; DB column is JSON
      variation: parsedVariation || null
    });

    return res.status(201).json({ message: 'Buying pool created', pool });
  } catch (error) {
    console.error("Create Pool Error:", error);
    return res.status(500).json({ message: error.message });
  }
}



// edit buying pool
// edit buying pool
exports.updatePool = async (req, res) => {
  const supplierId = req.user?.id;
  const { poolId } = req.params;

  if (!supplierId) return res.status(401).json({ message: 'Unauthorized' });

  const int = (v) => {
    const n = parseInt(v, 10);
    return Number.isFinite(n) ? n : 0;
  };
  const parseMaybe = (v) => {
    if (!v) return null;
    if (Array.isArray(v)) return v;
    if (typeof v === 'string') {
      try { return JSON.parse(v); } catch { return null; }
    }
    return v;
  };

  try {
    const pool = await Buying_pools.findOne({ where: { id: poolId, mycroshop_supplier_id: supplierId } });
    if (!pool) return res.status(404).json({ message: 'Pool not found or not owned by you' });

    const hasJoins = await Buying_pool_joined_by_customers.findOne({ where: { pool_id: poolId } });
    const updates = {};
    const images = req.files && req.files['images'] ? req.files['images'] : [];

    if (hasJoins) {
      // limited updates, but we must still ensure the final config has at least one target somewhere
      const allowedFieldsIfJoined = [
        'minimum_order_quantity',
        'min_buyers',
        'max_buyers',
        'shipping_destination',
        'variation' // can still adjust variations details
      ];

      // Apply allowed direct copies
      allowedFieldsIfJoined.forEach(field => {
        if (req.body[field] !== undefined) {
          updates[field] = req.body[field];
        }
      });

      // If variation is being updated, validate structure and "at least one target" rule
      if (updates.variation !== undefined) {
        const parsedVariation = parseMaybe(updates.variation);
        if (parsedVariation !== null && !Array.isArray(parsedVariation)) {
          return res.status(400).json({ message: 'Variation must be an array of objects' });
        }

        if (Array.isArray(parsedVariation)) {
          const ids = new Set();
          let anyVariationHasTarget = false;

          for (const [index, item] of parsedVariation.entries()) {
            const { id, price_per_unit, target_quantity, length, color, size, material, weight } = item || {};

            if (!id) {
              return res.status(400).json({ message: `id is required in variation at index ${index}` });
            }
            if (!price_per_unit) {
              return res.status(400).json({ message: `price_per_unit is required in variation at index ${index}` });
            }
            if (ids.has(String(id))) {
              return res.status(400).json({ message: `Duplicate id found in variation at index ${index}` });
            }
            ids.add(String(id));

            if (target_quantity && int(target_quantity) > 0) {
              anyVariationHasTarget = true;
            }

            const optionalFields = [length, color, size, material, weight];
            const hasOptional = optionalFields.some(val => typeof val === 'string' ? val.trim() !== '' : val !== undefined && val !== null);
            if (!hasOptional) {
              return res.status(400).json({ message: `At least one optional field must be provided in variation at index ${index}` });
            }
          }

          // After this update, top-level target remains pool.target_quantity (unchanged in hasJoins branch)
          const topLevelTargetOk = !!pool.target_quantity && int(pool.target_quantity) > 0;
          if (!topLevelTargetOk && !anyVariationHasTarget) {
            return res.status(400).json({ message: "Provide a pool-wide target_quantity or at least one variation.target_quantity (> 0)." });
          }

          updates.variation = parsedVariation;
        }
      }

      // image replacement allowed
      if (images.length > 0) {
        const oldImagePath = path.join(__dirname, '../public/image', pool.product_image);
        if (fs.existsSync(oldImagePath)) fs.unlinkSync(oldImagePath);
        updates.product_image = images[0].filename;
      }

    } else {
      // Full edit allowed
      const {
        product_name,
        price_per_unit,
        pool_title,
        target_quantity,
        product_description,
        pool_start_date,
        minimum_order_quantity,
        shipping_destination,
        min_buyers,
        max_buyers,
        terms_and_condition,
        variation
      } = req.body;

      const requiredFields = [
        'product_name', 'pool_title', 'pool_start_date',
        'minimum_order_quantity',
        'shipping_destination', 'min_buyers', 'max_buyers'
      ];

      for (let field of requiredFields) {
        if (!req.body[field]) {
          return res.status(400).json({ message: `Missing required field: ${field}` });
        }
      }

      let parsedVariation = parseMaybe(variation);
      let hasVariation = Array.isArray(parsedVariation) && parsedVariation.length > 0;

      // Pricing rule
      let finalPricePerUnit = price_per_unit;
      if (hasVariation) {
        // when variations exist, top-level price must be null
        finalPricePerUnit = null;
      } else {
        if (!price_per_unit) {
          return res.status(400).json({ message: "price_per_unit is required when no variations exist." });
        }
      }

      // Validate variations (if provided)
      let anyVariationHasTarget = false;
      if (hasVariation) {
        if (!Array.isArray(parsedVariation)) {
          return res.status(400).json({ message: 'Variation must be an array of objects' });
        }
        const ids = new Set();
        for (const [index, item] of parsedVariation.entries()) {
          const { id, price_per_unit: varPrice, target_quantity: varTarget, length, color, size, material, weight } = item || {};
          if (!id) {
            return res.status(400).json({ message: `id is required in variation at index ${index}` });
          }
          if (!varPrice) {
            return res.status(400).json({ message: `price_per_unit is required in variation at index ${index}` });
          }
          if (ids.has(String(id))) {
            return res.status(400).json({ message: `Duplicate id found in variation at index ${index}` });
          }
          ids.add(String(id));
          if (varTarget && int(varTarget) > 0) anyVariationHasTarget = true;

          const optionalFields = [length, color, size, material, weight];
          const hasOptional = optionalFields.some(val => typeof val === 'string' ? val.trim() !== '' : val !== undefined && val !== null);
          if (!hasOptional) {
            return res.status(400).json({ message: `At least one optional field must be provided in variation at index ${index}` });
          }
        }
      }

      // Final target rule after update:
      // compute finalTopLevelTarget (prefer incoming body; else keep existing)
      const finalTopLevelTarget = (target_quantity !== undefined && target_quantity !== null) ? target_quantity : pool.target_quantity;
      const topLevelTargetOk = !!finalTopLevelTarget && int(finalTopLevelTarget) > 0;

      // If variations present (either new or existing), at least one target must exist
      // If NO variations (new/old), top-level target is required.
      // Consider existing variations if client didn’t send a new one.
      const existingVariations = parseMaybe(pool.variation);
      const variationsExistAfter = hasVariation ? true : (Array.isArray(existingVariations) && existingVariations.length > 0);

      let existingAnyVarHasTarget = false;
      if (!hasVariation && variationsExistAfter) {
        for (const v of existingVariations) {
          if (v?.target_quantity && int(v.target_quantity) > 0) {
            existingAnyVarHasTarget = true;
            break;
          }
        }
      }

      if (!variationsExistAfter) {
        // No variations → top-level target must be > 0
        if (!topLevelTargetOk) {
          return res.status(400).json({ message: "target_quantity is required and must be > 0 for a product without variations." });
        }
      } else {
        // Variations exist (new or existing) → at least one target somewhere
        const hasAnyVariationTarget = hasVariation ? anyVariationHasTarget : existingAnyVarHasTarget;
        if (!topLevelTargetOk && !hasAnyVariationTarget) {
          return res.status(400).json({ message: "Provide a pool-wide target_quantity or at least one variation.target_quantity (> 0)." });
        }
      }

      Object.assign(updates, {
        product_name,
        price_per_unit: finalPricePerUnit,
        product_description,
        pool_title,
        minimum_order_quantity,
        target_quantity: finalTopLevelTarget || null,
        min_buyers,
        max_buyers,
        pool_start_date,
        shipping_destination,
        terms_and_condition,
        variation: hasVariation ? parsedVariation : (req.body.variation === undefined ? pool.variation : null)
      });

      if (images.length > 0) {
        const oldImagePath = path.join(__dirname, '../public/image', pool.product_image);
        if (fs.existsSync(oldImagePath)) fs.unlinkSync(oldImagePath);
        updates.product_image = images[0].filename;
      }
    }

    await Buying_pools.update(updates, { where: { id: poolId } });

    return res.status(200).json({ message: 'Pool updated successfully' });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
}





//update pool status
exports.updatePoolstatus = async (req, res) => {
  const supplierId = req.user.id;
  const { poolId } = req.params;
  const poolstatus = req.body.status
  try {
    const pool = await Buying_pools.findOne({ where: { id: poolId, mycroshop_supplier_id: supplierId } });
    if (!pool) return res.status(404).json({ message: 'Pool not found or unauthorized' });
    
     const date = dayjs().format('YYYY-MM-DD')
     
     //check pool status
     const getPool = await Buying_pools.findOne({where:{id: poolId, mycroshop_supplier_id: supplierId}})
     if(getPool.pool_status == "arrived"){
          return res.status(400).json({ message: 'can not update pool of status arrived' });
     }
     
     
     
     
     if(poolstatus == "active" || poolstatus == "processing" || poolstatus == "canceled" || poolstatus == "arrived"){
             
             if( poolstatus == "canceled"){
                 const joinedpool = await Buying_pool_joined_by_customers.findOne({where:{pool_id:pool_id}})
                 
                 if(joinedpool){
                      return res.status(400).json({ message: 'can not cancel a pool that has memebers' });
                 }
             }
             
            if( poolstatus == "processing"){
                 await Buying_pools.update({pool_status : poolstatus, processing_date : date},{where:{id: poolId, mycroshop_supplier_id: supplierId}});
            }
            
            if( poolstatus == "arrived"){
                 await Buying_pools.update({pool_status : poolstatus, arrived_date : date},{where:{id: poolId, mycroshop_supplier_id: supplierId}});
            }
            
            if(poolstatus != "arrived" || poolstatus != "processing"){
                await Buying_pools.update({pool_status : poolstatus},{where:{id: poolId, mycroshop_supplier_id: supplierId}});
            }
            
           
    return res.status(200).json({ message: 'Pool status updated successfully' });
     }
  return res.status(400).json({ message: 'invalid status passed' })
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
}

//get pool suppliers
exports.getSupplierPools = async (req, res) => {
    const supplierId = req.user.id;
    const { pool_status, search = '' } = req.query;

    let page = 0;
    const pagenumber = req.query.page;
    if (!Number.isNaN(pagenumber) && pagenumber > 0) {
        page = pagenumber;
    }

    if (!supplierId) return res.status(401).json({ message: 'Unauthorized' });

    const validStatuses = [
        "active", "processing", "canceled",
        "arrived", "completed", "in progress"
    ];
    const statusFilter = pool_status && validStatuses.includes(pool_status) ? { pool_status } : {};

    try {
        const whereClause = {
            mycroshop_supplier_id: supplierId,
            ...statusFilter,
            [Op.or]: [
                { product_name: { [Op.like]: `%${search}%` } },
                { pool_title: { [Op.like]: `%${search}%` } },
                { pool_start_date: { [Op.like]: `%${search}%` } }
            ]
        };

        const pools = await Buying_pools.findAll({
            where: whereClause,
            // SORTS POOLS BY ID, HIGHEST TO LOWEST (NEWEST FIRST)
            order: [['id', 'DESC']]
        });

        const allSupplierPools = await Buying_pools.findAll({
            where: { mycroshop_supplier_id: supplierId }
        });

        const totalPoolsCreated = allSupplierPools.length;
        const statusSummary = {
            active: 0, processing: 0, completed: 0,
            arrived: 0, canceled: 0, totalpool: totalPoolsCreated
        };

        for (const pool of allSupplierPools) {
            const status = pool.pool_status?.toLowerCase();
            if (statusSummary.hasOwnProperty(status)) {
                statusSummary[status]++;
            }
        }

        const enrichedPools = await Promise.all(
            pools.map(async (pool) => {
                const joined = await Buying_pool_joined_by_customers.findAll({ where: { pool_id: pool.id } });
                const totalJoined = joined.length;
                const totalUnitsBought = joined.reduce((sum, r) => sum + parseInt(r.quantity_purchased || 0), 0);
                const totalPeopleAllowed = parseInt(pool.min_buyers || 0);

                let variations = pool.variation ? (typeof pool.variation === 'string' ? JSON.parse(pool.variation) : pool.variation) : [];

                if (Array.isArray(variations) && variations.length > 0) {
                    variations = variations.map(variation => {
                        let unitsPurchasedForVariation = 0;
                        for (const join of joined) {
                            const purchasedVariations = Array.isArray(join.variation) ? join.variation : [];
                            const matchedVarInPurchase = purchasedVariations.find(pv => pv.id == variation.id);
                            if (matchedVarInPurchase) {
                                unitsPurchasedForVariation += parseInt(matchedVarInPurchase.quantity_purchased || 0);
                            }
                        }
                        const targetForVariation = parseInt(variation.target_quantity || 0);
                        // CALCULATES 'UNITS_LEFT' FOR EACH SPECIFIC VARIATION
                        const unitsLeftForVariation = targetForVariation - unitsPurchasedForVariation;

                        return {
                            ...variation,
                            units_purchased: unitsPurchasedForVariation,
                            units_left: unitsLeftForVariation
                        };
                    });
                }

                let finalTargetQuantity = 0;
                if (Array.isArray(variations) && variations.length > 0) {
                    finalTargetQuantity = variations.reduce((sum, v) => sum + parseInt(v.target_quantity || 0), 0);
                } else {
                    finalTargetQuantity = parseInt(pool.target_quantity || 0);
                }

                return {
                    ...pool.toJSON(),
                    target_quantity: finalTargetQuantity,
                    product_image: `${IMAGE_BASE_URL}${pool.product_image}`,
                    variation: variations,
                    performance: {
                        members_joined: totalJoined,
                        members_left: totalPeopleAllowed - totalJoined,
                        units_purchased: totalUnitsBought,
                        // CALCULATES OVERALL 'UNITS_LEFT' FOR THE ENTIRE POOL
                        units_left: finalTargetQuantity - totalUnitsBought,
                        progress: finalTargetQuantity > 0 ? Math.round((totalUnitsBought / finalTargetQuantity) * 100) : 0
                    }
                };
            })
        );

        const paginatedData = await pagination(enrichedPools, page);

        return res.status(200).json({
            ...paginatedData,
            summary: statusSummary
        });

    } catch (error) {
        return res.status(500).json({ message: error.message });
    }
}


//get pools for customer
exports.getPoolsForCustomer = async (req, res) => {
  const customerId = req.user?.id;
  const { search = '', status, category_id, participating } = req.query;

  let page = 0;
  const pagenumber = parseInt(req.query.page, 10);
  if (!Number.isNaN(pagenumber) && pagenumber > 0) page = pagenumber;

  if (!customerId) return res.status(401).json({ message: 'Unauthorized' });

  // tiny helpers
  const toInt = (n, def = 0) => {
    const v = parseInt(n, 10);
    return Number.isFinite(v) ? v : def;
  };
  const normalizeArr = (val) => {
    if (!val) return [];
    if (Array.isArray(val)) return val;
    if (typeof val === 'string') {
      try { const parsed = JSON.parse(val); return Array.isArray(parsed) ? parsed : []; }
      catch { return []; }
    }
    return [];
  };

  try {
    // Use a real Date (not YYYY-MM-DD string) to avoid timezone/type issues in SQL
    const today = dayjs().startOf('day').toDate();

    // 👉 Get ALL active subs, not just the most recent one
    const subs = await Buying_pool_subscription_payment.findAll({
      where: {
        buying_pool_customer_id: customerId,
        expiration_date: { [Op.gte]: today },
      },
      order: [['expiration_date', 'DESC']],
    });

    // Extract supplierIds from any supplier-type subscriptions
    const supplierIds = [
      ...new Set(
        subs
          .filter(s => {
            const t = String(s?.sub_type || '').trim().toLowerCase();
            return t.startsWith('supplier') && s?.supplier_id;
          })
          .map(s => s.supplier_id)
      )
    ];

    if (!supplierIds.length) {
      return res.status(403).json({ message: 'No active supplier subscription or subscription has expired' });
    }

    // Pools the user has joined (ids)
    const joinedPools = await Buying_pool_joined_by_customers.findAll({
      where: { customer_id: customerId },
      attributes: ['pool_id']
    });
    const joinedPoolIds = joinedPools.map(j => j.pool_id);

    // Build where
    let whereClause;

    if (participating === 'true') {
      // If you want "participating" to still respect supplier subscription, keep the supplier filter.
      // If you want it to ignore supplier scope, remove the supplier filter line below.
      if (!joinedPoolIds.length) {
        const paginatedEmpty = await pagination([], page);
        return res.status(200).json(paginatedEmpty);
      }

      whereClause = {
        [Op.and]: [
          { id: { [Op.in]: joinedPoolIds } },
          { mycroshop_supplier_id: { [Op.in]: supplierIds } },   // keep subscription scope
          search ? { product_name: { [Op.like]: `%${search}%` } } : {},
          category_id ? { category_id } : {},
          status ? { pool_status: status } : {}, // remove this line if you truly want "across all statuses"
        ]
      };
    } else {
      // Normal listing: ALWAYS restrict to subscribed supplier(s)
      whereClause = {
        [Op.and]: [
          { mycroshop_supplier_id: { [Op.in]: supplierIds } },   // <- the critical filter
          search ? { product_name: { [Op.like]: `%${search}%` } } : {},
          category_id ? { category_id } : {},
          status ? { pool_status: status } : {}, // remove if you want across all statuses by default
        ]
      };
    }

    // Fetch pools
    let pools = await Buying_pools.findAll({
      where: whereClause,
      order: [['id', 'DESC']]
    });

    // Enrich pools
    const enrichedPools = await Promise.all(
      pools.map(async (pool) => {
        const joined = await Buying_pool_joined_by_customers.findAll({ where: { pool_id: pool.id } });

        const totalJoined = joined.length;
        const totalUnitsBought = joined.reduce((sum, r) => sum + toInt(r.quantity_purchased, 0), 0);
        const totalPeopleAllowed = toInt(pool.min_buyers, 0);

        const initials = [];
        for (const j of joined) {
          const customer = await Buying_pool_customers.findByPk(j.customer_id, { attributes: ['name'] });
          if (customer?.name) initials.push(customer.name.charAt(0).toUpperCase());
        }

        const supplier = await Mycroshop_suppliers.findByPk(
          pool.mycroshop_supplier_id,
          { attributes: ['supplier_name', 'email', 'phone_number'] }
        );

        let variations = pool.variation
          ? (typeof pool.variation === 'string' ? JSON.parse(pool.variation) : pool.variation)
          : [];
        if (!Array.isArray(variations)) variations = [];

        if (variations.length > 0) {
          variations = variations.map(variation => {
            let unitsPurchasedForVariation = 0;
            for (const join of joined) {
              const purchasedVariations = normalizeArr(join.variation);
              const matched = purchasedVariations.find(pv => String(pv.id) === String(variation.id));
              if (matched) unitsPurchasedForVariation += toInt(matched.quantity_purchased, 0);
            }
            const targetForVariation = toInt(variation.target_quantity, 0);
            const unitsLeftForVariation = Math.max(targetForVariation - unitsPurchasedForVariation, 0);
            return {
              ...variation,
              units_purchased: unitsPurchasedForVariation,
              units_left: unitsLeftForVariation
            };
          });
        }

        let price_per_unit_display;
        if (variations.length > 0) {
          const prices = variations.map(v => toInt(v.price_per_unit, 0)).filter(p => p > 0);
          if (prices.length === 1) price_per_unit_display = `₦${prices[0]}`;
          else if (prices.length > 1) price_per_unit_display = `₦${Math.min(...prices)} - ₦${Math.max(...prices)}`;
          else price_per_unit_display = `₦${toInt(pool.price_per_unit, 0)}`;
        } else {
          price_per_unit_display = `₦${toInt(pool.price_per_unit, 0)}`;
        }

        let finalTargetQuantity = 0;
        if (variations.length > 0) {
          finalTargetQuantity = variations.reduce((sum, v) => sum + toInt(v.target_quantity, 0), 0);
        } else {
          finalTargetQuantity = toInt(pool.target_quantity, 0);
        }

        return {
          ...pool.toJSON(),
          target_quantity: finalTargetQuantity,
          product_image: `${IMAGE_BASE_URL}${pool.product_image}`,
          supplier_name: supplier?.supplier_name || '',
          supplier_email: supplier?.email || '',
          supplier_phone_number: supplier?.phone_number || '',
          initials,
          has_joined: joinedPoolIds.includes(pool.id),
          price_per_unit: price_per_unit_display,
          variation: variations,
          performance: {
            members_joined: totalJoined,
            members_left: Math.max(totalPeopleAllowed - totalJoined, 0),
            units_purchased: totalUnitsBought,
            units_left: Math.max(finalTargetQuantity - totalUnitsBought, 0),
            progress: finalTargetQuantity > 0 ? Math.round((totalUnitsBought / finalTargetQuantity) * 100) : 0
          }
        };
      })
    );

    const paginatedData = await pagination(enrichedPools, page);
    return res.status(200).json(paginatedData);
  } catch (error) {
    console.error('Error fetching customer pools:', error);
    return res.status(500).json({ message: error.message });
  }
}





//join pool
exports.initializePoolJoinPayment = async (req, res) => {
  const customerId = req.user.id;
  const { pool_id, quantity_purchased, variation, redirecturl } = req.body;

  if (!pool_id || (!quantity_purchased && !variation)) {
    return res.status(400).json({ message: 'Pool ID and quantity/variation are required.' });
  }

  const toInt = (v, d = 0) => {
    const n = parseInt(v, 10);
    return Number.isFinite(n) ? n : d;
  };

  try {
    // 1) Fetch pool + customer
    const pool = await Buying_pools.findByPk(pool_id);
    const customer = await Buying_pool_customers.findByPk(customerId);
    if (!pool || !customer) {
      return res.status(404).json({ message: 'Pool or customer not found.' });
    }

    // 2) Subscription check
    const activeSubscription = await Buying_pool_subscription_payment.findOne({
      where: {
        buying_pool_customer_id: customerId,
        expiration_date: { [Op.gte]: dayjs().format('YYYY-MM-DD') }
      },
      order: [['date', 'DESC']]
    });
    if (!activeSubscription) {
      return res.status(403).json({ message: 'You do not have an active subscription to join pools.' });
    }
    if (activeSubscription.sub_type === 'supplier' && activeSubscription.supplier_id !== pool.mycroshop_supplier_id) {
      return res.status(403).json({ message: "Your subscription is not valid for this supplier's pool." });
    }

    // 3) Has the user already joined? (Min-order only on first join)
    const existingJoin = await Buying_pool_joined_by_customers.findOne({
      where: { pool_id, customer_id: customerId }
    });

    // 4) Prep variations + existing sales
    const poolVariations = pool.variation
      ? (typeof pool.variation === 'string' ? JSON.parse(pool.variation) : pool.variation)
      : [];

    const hasVariations = Array.isArray(poolVariations) && poolVariations.length > 0;
    const requestedVariations = Array.isArray(variation) ? variation : [];

    const allJoins = await Buying_pool_joined_by_customers.findAll({ where: { pool_id } });

    // Build helper maps for existing sold units per-variation and for "no-target" consumption
    const varDefById = {};
    const varHasTargetById = {};
    if (hasVariations) {
      for (const vd of poolVariations) {
        const id = String(vd.id);
        varDefById[id] = vd;
        varHasTargetById[id] = toInt(vd.target_quantity, 0) > 0;
      }
    }

    // Sum sold units per variation
    const soldPerVariation = {};
    // Sold units that consumed the POOL-WIDE target (cases where the purchased variation has NO target; or non-variation joins)
    let soldAgainstPoolTarget = 0;

    for (const join of allJoins) {
      const jQty = toInt(join.quantity_purchased, 0);
      const jVars = Array.isArray(join.variation) ? join.variation : [];

      if (Array.isArray(jVars) && jVars.length > 0) {
        // Break down by variation id
        for (const line of jVars) {
          const vid = String(line.id);
          const q = toInt(line.quantity_purchased, 0);
          soldPerVariation[vid] = (soldPerVariation[vid] || 0) + q;

          // If that variation currently has NO target, it consumes pool-wide capacity
          if (!varHasTargetById[vid]) {
            soldAgainstPoolTarget += q;
          }
        }
      } else {
        // A join without variation consumes the pool-wide capacity
        soldAgainstPoolTarget += jQty;
      }
    }

    // 5) Compute amount + enforce capacity
    let amount = 0;
    let totalQuantity = 0;

    // Helper to get var price
    const priceOfVar = (vid) => {
      const def = varDefById[String(vid)];
      return parseFloat(def?.price_per_unit || 0);
    };

    if (hasVariations) {
      if (!Array.isArray(requestedVariations) || requestedVariations.length === 0) {
        return res.status(400).json({ message: 'Please select at least one variation to purchase.' });
      }

      // Partition requests into:
      // A) with own target, B) fallback to pool target
      const reqWithTarget = [];
      const reqNoTarget = [];
      for (const r of requestedVariations) {
        const vid = String(r.id);
        const def = varDefById[vid];
        if (!def) {
          return res.status(404).json({ message: `Variation with ID ${r.id} not found.` });
        }
        const qty = toInt(r.quantity_purchased, 0);
        if (qty <= 0) {
          return res.status(400).json({ message: `Requested quantity for variation ID ${r.id} must be > 0.` });
        }
        if (varHasTargetById[vid]) reqWithTarget.push({ id: vid, qty });
        else reqNoTarget.push({ id: vid, qty });
      }

      // A) Check each with-target variation against its own remaining capacity
      for (const { id: vid, qty } of reqWithTarget) {
        const target = toInt(varDefById[vid].target_quantity, 0);
        const sold = toInt(soldPerVariation[vid], 0);
        const left = target - sold;
        if (qty > left) {
          return res.status(400).json({
            message: `Not enough stock for variation (ID: ${vid}). Only ${left >= 0 ? left : 0} unit(s) available for this variation.`
          });
        }
      }

      // B) For no-target variations, enforce against pool-wide target
      const poolTarget = toInt(pool.target_quantity, 0);
      if (reqNoTarget.length > 0) {
        if (poolTarget <= 0) {
          return res.status(400).json({
            message: 'This pool has no pool-wide target; variations without their own targets cannot be purchased.'
          });
        }
        const requestedNoTargetQty = reqNoTarget.reduce((s, x) => s + toInt(x.qty, 0), 0);
        const poolLeft = poolTarget - soldAgainstPoolTarget;
        if (requestedNoTargetQty > poolLeft) {
          return res.status(400).json({
            message: `Only ${poolLeft >= 0 ? poolLeft : 0} unit(s) available in this pool for variations without individual targets.`
          });
        }
      }

      // Price calculation (all requested variations)
      for (const r of requestedVariations) {
        const vid = String(r.id);
        const qty = toInt(r.quantity_purchased, 0);
        const price = priceOfVar(vid);
        if (!Number.isFinite(price) || price <= 0) {
          return res.status(400).json({ message: `Invalid price set for variation ID ${vid}.` });
        }
        amount += qty * price;
        totalQuantity += qty;
      }

    } else {
      // Simple product (no variations)
      const qty = toInt(quantity_purchased, 0);
      if (qty <= 0) {
        return res.status(400).json({ message: 'Quantity must be greater than 0.' });
      }

      const poolTarget = toInt(pool.target_quantity, 0);
      if (poolTarget <= 0) {
        return res.status(400).json({ message: 'This pool has no valid target quantity configured.' });
      }

      const totalUnitsBought = allJoins.reduce((sum, r) => sum + toInt(r.quantity_purchased, 0), 0);
      const poolLeft = poolTarget - totalUnitsBought;
      if (qty > poolLeft) {
        return res.status(400).json({ message: `Only ${poolLeft >= 0 ? poolLeft : 0} unit(s) left in this pool.` });
      }

      const price = parseFloat(pool.price_per_unit || 0);
      if (!Number.isFinite(price) || price <= 0) {
        return res.status(400).json({ message: 'This product has an invalid price.' });
      }
      amount = qty * price;
      totalQuantity = qty;
    }

    // 6) Minimum order quantity (first join only)
    if (!existingJoin) {
      const minOrder = toInt(pool.minimum_order_quantity, 0);
      if (minOrder > 0 && totalQuantity < minOrder) {
        return res.status(400).json({
          message: `The total quantity must be at least the minimum order quantity of ${minOrder} units for your first purchase.`
        });
      }
    }

    // 7) Prepare Paystack metadata + initialize
    const metadata = {
      pool_id,
      customer_id: customerId,
      quantity_purchased: totalQuantity,
      variation: requestedVariations, // exact requested list
      is_additional_purchase: !!existingJoin
    };

    const supplier = await Mycroshop_suppliers.findByPk(pool.mycroshop_supplier_id);
    if (!supplier || !supplier.paystack_secrete_key) {
      return res.status(500).json({ message: 'Supplier payment configuration is missing.' });
    }

    const supplierSecretKey = `Bearer ${supplier.paystack_secrete_key}`;

    const paystackRes = await axios.post(
      `${PAYSTACK_BASE_URL}/transaction/initialize`,
      {
        email: customer.email,
        amount: Math.round(amount * 100),
        metadata,
        callback_url: redirecturl,
        channels: ['bank_transfer','card']
      },
      {
        headers: {
          Authorization: supplierSecretKey,
          'Content-Type': 'application/json',
        }
      }
    );

    return res.status(200).json({
      authorization_url: paystackRes.data.data.authorization_url,
      message: 'Redirect to complete payment',
    });

  } catch (error) {
    console.error("Initialize Pool Join Error:", error);
    if (error.response) {
      console.error("Paystack Error:", error.response.data);
      return res.status(500).json({ message: "Payment gateway error.", details: error.response.data });
    }
    return res.status(500).json({ message: "An internal server error occurred." });
  }
}




//join pool
exports.verifyPoolJoinPayment = async (req, res) => {
  const { reference, pool_id } = req.query;

  if (!reference || !pool_id) {
    return res.status(400).json({ message: "Payment reference and pool_id are required." });
  }

  const transaction = await Sequelize.transaction();

  const normalizeVariations = (val) => {
    if (!val) return [];
    if (Array.isArray(val)) return val;
    if (typeof val === 'string') {
      try {
        const parsed = JSON.parse(val);
        if (Array.isArray(parsed)) return parsed;
        if (parsed && typeof parsed === 'object') return [parsed];
        return [];
      } catch {
        return [];
      }
    }
    if (typeof val === 'object') return [val];
    return [];
  };

  const toInt = (n, def = 0) => {
    const v = parseInt(n, 10);
    return Number.isFinite(v) ? v : def;
  };

  try {
    const pool = await Buying_pools.findByPk(pool_id, { transaction });
    if (!pool) {
      await transaction.rollback();
      return res.status(404).json({ message: "Buying pool not found." });
    }

    const supplier = await Mycroshop_suppliers.findByPk(pool.mycroshop_supplier_id, { transaction });
    if (!supplier || !supplier.paystack_secrete_key) {
      await transaction.rollback();
      return res.status(500).json({ message: "Supplier configuration is missing or invalid." });
    }

    // Verify payment (supplier-scoped)
    const supplierSecretKey = `Bearer ${supplier.paystack_secrete_key}`;
    const response = await axios.get(`${PAYSTACK_BASE_URL}/transaction/verify/${reference}`, {
      headers: { Authorization: supplierSecretKey, 'Content-Type': 'application/json' }
    });

    const data = response?.data?.data;
    if (!data || data.status !== 'success') {
      await transaction.rollback();
      return res.status(400).json({ message: 'Payment verification failed with Paystack.' });
    }

    const {
      customer_id,
      quantity_purchased,
      variation: purchasedVariationInfo,
      is_additional_purchase
    } = data.metadata || {};

    const log_quantity_purchased = quantity_purchased;

    if (!customer_id) {
      await transaction.rollback();
      return res.status(400).json({ message: "Payment metadata missing customer_id." });
    }

    const customer = await Buying_pool_customers.findByPk(customer_id, { transaction });
    if (!customer) {
      await transaction.rollback();
      return res.status(404).json({ message: "Customer profile not found." });
    }

    // Idempotency via extra-purchase table
    const refExists = await Buying_pool_extra_purchases.findOne({
      where: { payment_reference: reference },
      transaction
    });
    if (refExists) {
      await transaction.rollback();
      return res.status(400).json({ message: "This transaction has already been recorded." });
    }

    const purchasedVariations = normalizeVariations(purchasedVariationInfo).map(v => ({
      ...v,
      quantity_purchased: toInt(v.quantity_purchased, 0),
      id: v.id !== undefined && v.id !== null ? String(v.id) : undefined
    }));
    const deltaQty = toInt(quantity_purchased, 0);

    // Upsert join row
    const existingJoin = await Buying_pool_joined_by_customers.findOne({
      where: { pool_id, customer_id },
      transaction
    });

    if (existingJoin) {
      // Merge quantities (overall + per-variation)
      let currentVariations = normalizeVariations(existingJoin.variation).map(v => ({
        ...v,
        quantity_purchased: toInt(v.quantity_purchased, 0),
        id: v.id !== undefined && v.id !== null ? String(v.id) : undefined
      }));

      existingJoin.quantity_purchased = toInt(existingJoin.quantity_purchased, 0) + deltaQty;

      if (purchasedVariations.length > 0) {
        purchasedVariations.forEach(newVar => {
          if (!newVar.id) {
            currentVariations.push(newVar);
            return;
          }
          const idx = currentVariations.findIndex(ev => String(ev.id) === String(newVar.id));
          if (idx > -1) {
            currentVariations[idx].quantity_purchased =
              toInt(currentVariations[idx].quantity_purchased, 0) + toInt(newVar.quantity_purchased, 0);
          } else {
            currentVariations.push(newVar);
          }
        });
      }

      // Write JSON back (no stringify)
      existingJoin.variation = currentVariations.length ? currentVariations : null;
      await existingJoin.save({ transaction });

      await Buying_pool_extra_purchases.create({
        pool_join_id: existingJoin.id,
        varaition: purchasedVariations, // JSON column, keep object
        quantity_purchased: log_quantity_purchased,
        payment_reference: reference
      }, { transaction });

    } else {
      // First join
      const inserted = await Buying_pool_joined_by_customers.create({
        pool_id,
        customer_id,
        quantity_purchased: deltaQty,
        transaction_reference: reference,
        date: dayjs().format('YYYY-MM-DD'),
        variation: purchasedVariations.length ? purchasedVariations : null
      }, { transaction });

      await Buying_pool_extra_purchases.create({
        pool_join_id: inserted.id,
        quantity_purchased: log_quantity_purchased,
        varaition: purchasedVariations,
        payment_reference: reference
      }, { transaction });
    }

    // Email details for THIS transaction
    const poolVariations = normalizeVariations(pool.variation);
    let emailPurchaseDetails = [];
    let finalTargetQuantity = 0;

    // Prefer pool-wide target if present; otherwise sum variation targets
    const poolWideTarget = toInt(pool.target_quantity, 0);
    if (poolWideTarget > 0) {
      finalTargetQuantity = poolWideTarget;
    } else if (poolVariations.length > 0) {
      finalTargetQuantity = poolVariations.reduce((sum, v) => sum + toInt(v.target_quantity, 0), 0);
    }

    if (purchasedVariations.length > 0) {
      emailPurchaseDetails = purchasedVariations.map(pv => {
        const def = pv.id
          ? poolVariations.find(d => String(d.id) === String(pv.id))
          : null;
        return { ...(def || {}), quantity_purchased: toInt(pv.quantity_purchased, 0) };
      });
    }

    const templatePath = path.join(__dirname, '../service/templates/joinedPoolemailTemplate.ejs');
    const emailHtml = await ejs.renderFile(templatePath, {
      name: customer.name,
      supplier_name: supplier.supplier_name,
      phone_number: supplier.phone_number,
      email: supplier.email,
      pool_title: pool.pool_title,
      product_name: pool.product_name,
      product_description: pool.product_description,
      purchaseDetails: emailPurchaseDetails,
      total_quantity_purchased: deltaQty,
      finalTargetQuantity,
      shipping_destination: pool.shipping_destination,
    });

    const emailSent = await sendEmailWithTemplate(
      customer.email,
      `Successfully joined ${pool.pool_title}`,
      emailHtml
    );

    await Business_notifications.create({
      message: emailHtml,
      business_id: customer.id,
      business_type: "pool_customer",
      sent_status: emailSent ? 1 : 0,
    }, { transaction });

    await transaction.commit();
    return res.status(200).json({
      message: existingJoin ? 'Additional purchase recorded successfully.' : 'Pool joined successfully.'
    });

  } catch (error) {
    await transaction.rollback();
    console.error("Verify Pool Join Error:", error);
    return res.status(500).json({
      message: "An internal server error occurred.",
      error: error.message
    });
  }
};








//pool customer withdraw from pool
exports.withdrawFromPool = async (req, res) => {
  const customerId = req.user.id;
  const { joinId } = req.params; // ID of the pool join record

  try {
    // Fetch the join record
    const joinRecord = await Buying_pool_joined_by_customers.findOne({
      where: { id: joinId, customer_id: customerId }
    });

    if (!joinRecord) {
      return res.status(404).json({ message: 'Join record not found' });
    }

    // Fetch the pool
    const pool = await Buying_pools.findByPk(joinRecord.pool_id);
    if (!pool) {
      return res.status(404).json({ message: 'Pool not found' });
    }

    // Allow withdrawal only if pool is still in progress
    if (pool.pool_status !== 'active') {
      return res.status(403).json({ message: 'Withdrawal not allowed. Pool is no longer active.' });
    }

    // Attempt refund via Paystack
    const refundResponse = await axios.post(
      `${PAYSTACK_BASE_URL}/refund`,
      {
        transaction: joinRecord.transaction_reference,
        // optional: add reason and deduction logic if needed
      },
      { headers }
    );

    // Mark the join as withdrawn (optional: if you add a status column)
    await joinRecord.update({ mycroshop_admin_payment_status: 'withdrawn' });

    // Fetch customer and supplier
    const customer = await Buying_pool_customers.findByPk(customerId);
    const supplier = await Mycroshop_suppliers.findByPk(pool.mycroshop_supplier_id);

    // Notify customer
    const customerTemplatePath = path.join(__dirname, '../service/templates/poolWithdrawCustomer.ejs');
    const customerHtml = await ejs.renderFile(customerTemplatePath, {
      name: customer.name,
      poolTitle: pool.pool_title
    });
    await sendEmailWithTemplate(customer.email, 'You Have Withdrawn from a Pool', customerHtml);

    // Notify supplier
    const supplierTemplatePath = path.join(__dirname, '../service/templates/poolWithdrawSupplier.ejs');
    const supplierHtml = await ejs.renderFile(supplierTemplatePath, {
      supplierName: supplier.supplier_name,
      customerName: customer.name,
      poolTitle: pool.pool_title
    });
    await sendEmailWithTemplate(supplier.email, 'A Customer Has Withdrawn from Your Pool', supplierHtml);

    return res.status(200).json({ message: 'Withdrawal successful and refund initiated.' });
  } catch (error) {
    return res.status(500).json({ message: error.response?.data?.message || error.message });
  }
}



//validatePickup for pool
exports.validatePickup = async (req, res) => {
  const supplierId = req.user.id;
  const { poolId } = req.params;
  const { phone_number } = req.body;

  // small helpers
  const toInt = (n, def = 0) => {
    const v = parseInt(n, 10);
    return Number.isFinite(v) ? v : def;
  };
  const toNum = (n, def = 0) => {
    const v = Number(n);
    return Number.isFinite(v) ? v : def;
  };
  const normArr = (val) => {
    if (!val) return [];
    if (Array.isArray(val)) return val;
    if (typeof val === 'string') {
      try {
        const parsed = JSON.parse(val);
        return Array.isArray(parsed) ? parsed : [];
      } catch { return []; }
    }
    return [];
  };

  const t = await Sequelize.transaction();
  try {
    // 1) pool must belong to supplier and be arrived
    const pool = await Buying_pools.findOne({
      where: { id: poolId, mycroshop_supplier_id: supplierId, pool_status: 'arrived' },
      transaction: t,
      lock: t.LOCK.UPDATE
    });
    if (!pool) {
      await t.rollback();
      return res.status(404).json({ message: 'Pool not found' });
    }

    // 2) find customer by phone
    const customer = await Buying_pool_customers.findOne({
      where: { phone_number },
      transaction: t
    });
    if (!customer) {
      await t.rollback();
      return res.status(404).json({ message: 'No matching record found for this phone number' });
    }

    // 3) joined record for this pool + customer
    const joined = await Buying_pool_joined_by_customers.findOne({
      where: { pool_id: poolId, customer_id: customer.id },
      transaction: t,
      lock: t.LOCK.UPDATE
    });
    if (!joined) {
      await t.rollback();
      return res.status(404).json({ message: 'No matching record found for this phone number' });
    }

    // Use ONE status field consistently (support old data too)
    const currentStatus = joined.status || joined.pool_status || null;
    if (currentStatus === 'pickedup') {
      await t.rollback();
      return res.status(400).json({ message: 'This order has already been picked up' });
    }

    // 4) compute revenue
    const poolVariations = pool.variation
      ? (typeof pool.variation === 'string' ? JSON.parse(pool.variation) : pool.variation)
      : [];
    const purchasedVariations = normArr(joined.variation);

    let purchaseDetails = [];
    let totalQuantity = 0;
    let revenue = 0;


    if (purchasedVariations.length > 0 && Array.isArray(poolVariations) && poolVariations.length > 0) {
      // multi-variation purchase
      purchaseDetails = purchasedVariations.map(pv => {
        const match = poolVariations.find(v => String(v.id) === String(pv.id)) || {};
        const pricePerUnit = toNum(match.price_per_unit, toNum(pool.price_per_unit, 0));
        const qty = toInt(pv.quantity_purchased, 0);
        const lineTotal = qty * pricePerUnit;
        totalQuantity += qty;
        revenue += lineTotal;
        return {
          id: match.id ?? pv.id,
          color: match.color,
          length: match.length,
          size: match.size,
          weight: match.weight,
          material: match.material,
          price_per_unit: pricePerUnit,
          quantity_purchased: qty,
          line_total: lineTotal
        };
      });
    } else {
      // no variations picked (pool-level price)
      const qty = toInt(joined.quantity_purchased, 1);
      const pricePerUnit = toNum(pool.price_per_unit, 0);
      totalQuantity = qty;
      revenue = qty * pricePerUnit;
    }

    // 5) mark this join as picked up (both fields for compatibility)
    joined.status = 'pickedup';
    joined.pool_status = 'pickedup';
    await joined.save({ transaction: t });

    // 6) if everyone else is picked up, complete the pool
    // "remaining" means rows where NEITHER 'status' nor 'pool_status' equal 'pickedup'
    const remaining = await Buying_pool_joined_by_customers.count({
      where: {
        pool_id: poolId,
        [Op.and]: [
          { [Op.or]: [{ status: { [Op.ne]: 'pickedup' } }, { status: null }] },
          { [Op.or]: [{ status: { [Op.ne]: 'pickedup' } }, { status: null }] }
        ]
      },
      transaction: t
    });

    if (remaining === 0) {
      pool.pool_status = 'completed';
      await pool.save({ transaction: t });
    }

    await t.commit();

    // 7) response: customer info + pool info + exact purchased variations
    return res.status(200).json({
      message: 'Pickup validated successfully.',
      customerinfo: {
        name: customer.name,
        email: customer.email,
        phone_number: customer.phone_number,
        quantity: totalQuantity,
        revenue: revenue
      },
      poolinfo: {
        id: pool.id,
        pool_title: pool.pool_title,
        product_name: pool.product_name,
        product_description: pool.product_description,
        shipping_destination: pool.shipping_destination,
        expected_arrival_date: pool.expected_arrival_date,
        pool_status: remaining === 0 ? 'completed' : pool.pool_status, // reflects updated status
        // Only the variations the user actually purchased, with line totals:
        purchase_details: purchaseDetails,
        totals: {
          quantity: totalQuantity,
          revenue
        }
      }
    });

  } catch (err) {
    try { await t.rollback(); } catch {}
    return res.status(500).json({ message: err.message });
  }
}




//supplier get pool detail
exports.getPoolDetails = async (req, res) => {
  const supplierId = req.user.id;
  const { poolId } = req.params;

  let page = 0;
  const pagenumber = parseInt(req.query.page);
  if (!Number.isNaN(pagenumber) && pagenumber > 0) {
    page = pagenumber;
  }

  // helpers
  const parseArrayMaybe = (val) => {
    try {
      if (!val) return [];
      if (Array.isArray(val)) return val;
      if (typeof val === 'string') return JSON.parse(val || '[]');
      return [];
    } catch {
      return [];
    }
  };
  const toInt = (v) => {
    const n = parseInt(v, 10);
    return Number.isFinite(n) ? n : 0;
  };
  const toFloat = (v) => {
    const n = parseFloat(v);
    return Number.isFinite(n) ? n : 0;
  };

  try {
    const pool = await Buying_pools.findOne({
      where: { id: poolId, mycroshop_supplier_id: supplierId }
    });

    if (!pool) return res.status(404).json({ message: 'Pool not found' });

    const allJoins = await Buying_pool_joined_by_customers.findAll({
      where: { pool_id: poolId }
    });

    // Parse pool variations (if any)
    let variations = parseArrayMaybe(pool.variation);
    const basePrice = toFloat(pool.price_per_unit);

    // Build per-variation purchased units (across all joins)
    if (Array.isArray(variations) && variations.length > 0) {
      variations = variations.map((variation) => {
        const varId = (variation?.id ?? '').toString();
        let unitsPurchasedForVariation = 0;

        for (const join of allJoins) {
          const purchasedVariations = parseArrayMaybe(join.variation);
          if (purchasedVariations.length > 0) {
            const matchedVarInPurchase = purchasedVariations.find((pv) => (pv?.id ?? '').toString() === varId);
            if (matchedVarInPurchase) {
              unitsPurchasedForVariation += toInt(matchedVarInPurchase.quantity_purchased);
            }
          }
        }

        const targetForVariation = toInt(variation.target_quantity);
        const unitsLeftForVariation = Math.max(0, targetForVariation - unitsPurchasedForVariation);

        return {
          ...variation,
          units_purchased: unitsPurchasedForVariation,
          units_left: unitsLeftForVariation
        };
      });
    }

    // Compute cumulative target across variations (or use pool.target_quantity if none)
    let cumulativeTargetQuantity = 0;
    if (Array.isArray(variations) && variations.length > 0) {
      cumulativeTargetQuantity = variations.reduce((sum, v) => sum + toInt(v.target_quantity), 0);
    } else {
      cumulativeTargetQuantity = toInt(pool.target_quantity);
    }

    // Variation price map for quick lookup
    const variationPriceMap = {};
    for (const v of variations) {
      const id = (v?.id ?? '').toString();
      if (id) variationPriceMap[id] = toFloat(v.price_per_unit);
    }

    // Variation-aware totals
    let totalRevenue = 0;
    let totalUnitsBought = 0;

    // If you later need the per-customer breakdown again, you can return `customers` too.
    // For now we keep response shape as in your current function.
    for (const j of allJoins) {
      const jVars = parseArrayMaybe(j.variation);

      if (jVars.length > 0) {
        // Sum by each variation: qty * variation price
        for (const item of jVars) {
          const id = (item?.id ?? '').toString();
          const qty = toInt(item?.quantity_purchased);
          const unitPrice = variationPriceMap[id] != null ? variationPriceMap[id] : basePrice;
          totalRevenue += unitPrice * qty;
          totalUnitsBought += qty;
        }
      } else {
        // No variation on join → base price * quantity_purchased
        const qty = toInt(j.quantity_purchased);
        totalRevenue += basePrice * qty;
        totalUnitsBought += qty;
      }
    }

    const unitsLeftOverall = Math.max(0, cumulativeTargetQuantity - totalUnitsBought);
    const progress = cumulativeTargetQuantity > 0
      ? Math.round((totalUnitsBought / cumulativeTargetQuantity) * 100)
      : 0;

    return res.status(200).json({
      pool: {
        ...pool.toJSON(),
        variation: variations, // enriched with units_purchased/units_left when present
        product_image_url: `${IMAGE_BASE_URL}${pool.product_image}`
      },
      performance: {
        progress,
        totalUnitsBought,
        totalTarget: cumulativeTargetQuantity,
        units_left: unitsLeftOverall,
        totalPeople: allJoins.length,
        totalRevenue
      }
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: err.message });
  }
}





// Track Pool (only for status = 'arrived')
exports.suppliertrackPoolStatus = async (req, res) => {
  const supplierId = req.user.id;
  const { poolId } = req.params;

  try {
    const pool = await Buying_pools.findOne({
      where: { id: poolId, mycroshop_supplier_id: supplierId, pool_status: 'arrived' }
    });
    if (!pool) {
      return res.status(404).json({ message: 'Pool not found or not yet arrived' });
    }

    const joined = await Buying_pool_joined_by_customers.findAll({
      where: { pool_id: poolId }
    });

    // ---- Parse pool variations (if any) & build price map ----
    let poolVariations = [];
    try {
      if (pool.variation) {
        poolVariations = Array.isArray(pool.variation) ? pool.variation : JSON.parse(pool.variation);
      }
    } catch (_) {
      poolVariations = [];
    }

    const variationPriceMap = {};
    for (const v of poolVariations) {
      const vid = (v?.id ?? '').toString();
      const price = parseFloat(v?.price_per_unit || 0) || 0;
      if (vid) variationPriceMap[vid] = price;
    }

    const basePrice = parseFloat(pool.price_per_unit || 0) || 0;

    // Helper: parse a joined.variation (array or string), returns [] if none
    const parseJoinedVariations = (v) => {
      try {
        if (!v) return [];
        if (Array.isArray(v)) return v;
        return JSON.parse(v);
      } catch {
        return [];
      }
    };

    // Helper: total units for a join, using variations if present
    const totalUnitsForJoin = (join) => {
      const jVars = parseJoinedVariations(join.variation);
      if (Array.isArray(jVars) && jVars.length > 0) {
        return jVars.reduce((sum, item) => sum + (parseInt(item?.quantity_purchased || 0) || 0), 0);
      }
      return parseInt(join.quantity_purchased || 0) || 0;
    };

    // Helper: revenue for a join (variation-aware)
    const revenueForJoin = (join) => {
      const jVars = parseJoinedVariations(join.variation);
      if (Array.isArray(jVars) && jVars.length > 0) {
        return jVars.reduce((sum, item) => {
          const id = (item?.id ?? '').toString();
          const qty = parseInt(item?.quantity_purchased || 0) || 0;
          const price = id && variationPriceMap[id] != null ? variationPriceMap[id] : basePrice;
          return sum + price * qty;
        }, 0);
      }
      const qty = parseInt(join.quantity_purchased || 0) || 0;
      return basePrice * qty;
    };

    // ---- Aggregate revenues by status (variation-aware) ----
    let revenueJoined = 0;
    let revenuePickedUp = 0;
    let revenuePending = 0;
    let revenueRefunds = 0;

    const pickedUp = [];
    const pending = [];
    const refunds = [];

    for (const j of joined) {
      const r = revenueForJoin(j);
      revenueJoined += r;

      if (j.status === 'pickedup') {
        pickedUp.push(j);
        revenuePickedUp += r;
      } else if (j.status === 'refunded') {
        refunds.push(j);
        revenueRefunds += r;
      } else {
        pending.push(j);
        revenuePending += r;
      }
    }

    // ---- Compute target quantity reached date (variation-aware units) ----
    //   If pool has variations => target = sum of variations' target_quantity
    //   else => target = pool.target_quantity
    let finalTargetQuantity = 0;
    if (Array.isArray(poolVariations) && poolVariations.length > 0) {
      finalTargetQuantity = poolVariations.reduce(
        (sum, v) => sum + (parseInt(v?.target_quantity || 0) || 0),
        0
      );
    } else {
      finalTargetQuantity = parseInt(pool.target_quantity || 0) || 0;
    }

    let accumulatedQty = 0;
    let targetReachedDate = null;

    const sortedByDate = [...joined].sort((a, b) => new Date(a.date) - new Date(b.date));
    for (const record of sortedByDate) {
      accumulatedQty += totalUnitsForJoin(record);
      if (finalTargetQuantity > 0 && accumulatedQty >= finalTargetQuantity) {
        targetReachedDate = record.date;
        break;
      }
    }

    return res.status(200).json({
      pool: {
        ...pool.toJSON(),
        product_image_url: `${IMAGE_BASE_URL}${pool.product_image}`
      },
      metrics: {
        totalJoined: joined.length,
        totalPickedUp: pickedUp.length,
        totalPending: pending.length,
        totalRefunds: refunds.length,

        // variation-aware
        revenueJoined,
        revenuePickedUp,
        revenuePending,
        revenueRefunds,
        totalRevenue: revenueJoined,

        created_at: pool.created_at_date,
        target_reached_at: targetReachedDate,
        processing_at: pool.processing_date,
        arrived_at: pool.arrived_date
      }
    });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}




// Extrapurchase
//supplier customer pool list
exports.supplierTrackPoolCustomerList = async (req, res) => { 
  const supplierId = req.user.id;
  const { poolId, type } = req.params;
  const { search = '' } = req.query;

  // page index (0-based)
  let page = 0;
  const pagenumber = parseInt(req.query.page, 10);
  if (!Number.isNaN(pagenumber) && pagenumber > 0) {
    page = pagenumber;
  }

  // helpers
  const toInt = (n, def = 0) => {
    const v = parseInt(n, 10);
    return Number.isFinite(v) ? v : def;
  };
  const toNum = (n, def = 0) => {
    const v = Number(n);
    return Number.isFinite(v) ? v : def;
  };
  const normArr = (val) => {
    if (!val) return [];
    if (Array.isArray(val)) return val;
    if (typeof val === 'string') {
      try {
        const parsed = JSON.parse(val);
        return Array.isArray(parsed) ? parsed : [];
      } catch { return []; }
    }
    return [];
  };

  try {
    // status filter
    let statusFilter;
    if (type === 'pickedup') {
      statusFilter = 'pickedup';
    } else if (type === 'pending') {
      statusFilter = { [Op.notIn]: ['pickedup', 'refunded'] };
    } else if (type === 'refunded') {
      statusFilter = 'refunded';
    } else if (type === 'all'){
        statusFilter = 'all'
    }
     
     let joinedRecords
    // joined rows for this pool + status
    if(statusFilter == 'all' || !statusFilter){
        joinedRecords = await Buying_pool_joined_by_customers.findAll({
      where: { pool_id: poolId}
    })
    }else{
         joinedRecords = await Buying_pool_joined_by_customers.findAll({
      where: { pool_id: poolId, status: statusFilter }
    });
    }
    

    if (!joinedRecords.length) {
      return res.status(200).json({
        page,
        per_page: 10,
        pre_page: page > 1 ? page - 1 : null,
        next_page: null,
        total: 0,
        total_pages: 0,
        data: []
      });
    }

    // resolve customers for search filtering
    const customerIds = joinedRecords.map(j => j.customer_id);
    const customers = await Buying_pool_customers.findAll({
      where: {
        id: { [Op.in]: customerIds },
        [Op.or]: [
          { name: { [Op.like]: `%${search}%` } },
          { email: { [Op.like]: `%${search}%` } },
          { phone_number: { [Op.like]: `%${search}%` } }
        ]
      }
    });
    const matchedCustomerIds = new Set(customers.map(c => c.id));
    const filteredJoinedRecords = joinedRecords.filter(j => matchedCustomerIds.has(j.customer_id));

    // pool info (minimal, always returned; no heavy pool.variation list in response)
    const pool = await Buying_pools.findOne({ where: { id: poolId, mycroshop_supplier_id: supplierId } });
    if (!pool) {
      return res.status(404).json({ message: 'Pool not found' });
    }

    // parse pool variations & build map for quick lookups
    const poolVariations = pool.variation
      ? (typeof pool.variation === 'string' ? JSON.parse(pool.variation) : pool.variation)
      : [];
    const varMap = new Map(
      (Array.isArray(poolVariations) ? poolVariations : []).map(v => [String(v.id), v])
    );
    const hasVariations = Array.isArray(poolVariations) && poolVariations.length > 0;

    // enrich each joined row
    const enriched = await Promise.all(
      filteredJoinedRecords.map(async (j) => {
        const customer = customers.find(c => c.id === j.customer_id);

        // cumulative revenue from the join row
        let cumulativeRevenue = 0;
        if (hasVariations) {
          const jVars = normArr(j.variation);
          for (const item of jVars) {
            const v = varMap.get(String(item.id));
            if (v) {
              cumulativeRevenue += toNum(v.price_per_unit, toNum(pool.price_per_unit, 0)) * toInt(item.quantity_purchased, 0);
            }
          }
        } else {
          cumulativeRevenue = toNum(pool.price_per_unit, 0) * toInt(j.quantity_purchased, 0);
        }

        // fetch extra purchases logs for this join
        const logs = await Buying_pool_extra_purchases.findAll({
          where: { pool_join_id: j.id },
          order: [['id', 'ASC']]
        });

        // shape logs → each log’s variations_purchased enriched from pool.variation
        const payment_logs = logs.map(log => {
          // NOTE: model column name is 'varaition' (typo), so read both just in case
          const rawVar = log.varaition ?? log.variation ?? log.dataValues?.varaition ?? log.dataValues?.variation;
          const logVarItems = normArr(rawVar);

          let variations_purchased = [];
          let log_total = 0;

          if (hasVariations && logVarItems.length > 0) {
            variations_purchased = logVarItems.map(li => {
              const v = varMap.get(String(li.id)) || {};
              const price = toNum(v.price_per_unit, toNum(pool.price_per_unit, 0));
              const qty = toInt(li.quantity_purchased, 0);
              const line = price * qty;
              log_total += line;
              // merge the pool-variation info + purchased qty + line total
              return {
                id: v.id ?? li.id,
                length: v.length ?? null,
                size: v.size ?? null,
                color: v.color ?? null,
                weight: v.weight ?? null,
                material: v.material ?? null,
                price_per_unit: price,
                target_quantity: v.target_quantity ?? null,
                quantity_purchased: qty,
                line_total: line
              };
            });
          } else {
            // pool doesn’t use variations OR log has no variation array
            const qty = toInt(log.quantity_purchased, 0);
            const price = toNum(pool.price_per_unit, 0);
            log_total = price * qty;
            variations_purchased = []; // per requirement
          }

          return {
            payment_reference: log.payment_reference,
            quantity_purchased: toInt(log.quantity_purchased, 0),
            variations_purchased,
            total_amount: log_total,
            created_at: log.createdAt || log.date || null
          };
        });

        // light pool info (no variation array returned here)
        const pool_info = {
          id: pool.id,
          pool_title: pool.pool_title,
          product_name: pool.product_name,
          product_description: pool.product_description,
          product_image_url: `${IMAGE_BASE_URL}${pool.product_image}`,
          pool_status: pool.pool_status,
          shipping_destination: pool.shipping_destination,
          price_per_unit: toNum(pool.price_per_unit, 0),
          expected_arrival_date: pool.expected_arrival_date
        };

        return {
          customer: {
            id: customer?.id,
            name: customer?.name,
            email: customer?.email,
            phone_number: customer?.phone_number
          },
          joined_summary: {
            join_id: j.id,
            date: j.date,
            status: j.status,
            quantity_purchased: toInt(j.quantity_purchased, 0),
            total_revenue: cumulativeRevenue
          },
          pool: pool_info,
          payment_logs
        };
      })
    );

    const paginatedData = await pagination(enriched, page);
    return res.status(200).json(paginatedData);

  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};



//pool customers track list 
exports.trackCustomerPool = async (req, res) => {
  const customerId = req.user.id;
  const { poolId } = req.params;

  // Helpers (scoped here so this stays drop-in)
  const toInt = (n, def = 0) => {
    const v = parseInt(n, 10);
    return Number.isFinite(v) ? v : def;
  };

  const normalizeVariations = (val) => {
    // Accept: null | [] | {} | "[]"/"{}" | stringified array
    if (!val) return [];
    if (Array.isArray(val)) return val;
    if (typeof val === 'string') {
      try {
        const parsed = JSON.parse(val);
        if (Array.isArray(parsed)) return parsed;
        if (parsed && typeof parsed === 'object') return [parsed];
        return [];
      } catch {
        return [];
      }
    }
    if (typeof val === 'object') return [val];
    return [];
  };

  try {
    const joinedRecord = await Buying_pool_joined_by_customers.findOne({
      where: { pool_id: poolId, customer_id: customerId }
    });
    if (!joinedRecord) {
      return res.status(404).json({ message: 'No participation found for this customer in this pool' });
    }

    const pool = await Buying_pools.findOne({ where: { id: poolId } });
    if (!pool) {
      return res.status(404).json({ message: 'Pool not found' });
    }

    const getcustomer = await Buying_pool_customers.findOne({ where: { id: customerId } });

    // All joins in this pool
    const allJoins = await Buying_pool_joined_by_customers.findAll({ where: { pool_id: poolId } });

    // Normalize pool variations (array of objects, or empty if none)
    const variations = normalizeVariations(pool.variation);

    // Compute cumulative (target) quantity across all variations if any, else fall back
    let cumulativeTargetQuantity = 0;
    if (variations.length > 0) {
      cumulativeTargetQuantity = variations.reduce((sum, v) => sum + toInt(v.target_quantity, 0), 0);
    } else {
      cumulativeTargetQuantity = toInt(pool.target_quantity, 0);
    }

    // Normalize the customer's variations from the join row
    const customerVariations = normalizeVariations(joinedRecord.variation).map(v => ({
      ...v,
      id: v?.id !== undefined && v?.id !== null ? String(v.id) : undefined,
      quantity_purchased: toInt(v?.quantity_purchased, 0)
    }));

    // Build variations_purchased by merging display data from pool.variation
    let variations_purchased = [];
    if (customerVariations.length > 0) {
      variations_purchased = customerVariations.map(cv => {
        const fullVar = cv.id
          ? variations.find(v => String(v.id) === String(cv.id))
          : null;

        // Prefer fields from pool variation definition when available,
        // but always include the customer's purchased quantity.
        if (fullVar) {
          return {
            id: fullVar.id,
            length: fullVar.length,
            price_per_unit: fullVar.price_per_unit,
            color: fullVar.color,
            weight: fullVar.weight,
            material : fullVar.material,
            target_quantity: toInt(fullVar.target_quantity, 0),
            quantity_purchased: cv.quantity_purchased
          };
        }

        // Fallback when pool match not found (still return something useful)
        return {
          id: cv.id,
          length: cv.length,
          price_per_unit: cv.price_per_unit,
          color: cv.color,
          weight: cv.weight,
          material : cv.material,
          target_quantity: toInt(cv.target_quantity, 0),
          quantity_purchased: cv.quantity_purchased
        };
      }).filter(x => toInt(x.quantity_purchased, 0) > 0);
    }

    // Pool-level metrics
    const totalPeople = allJoins.length;
    const maxBuyers = toInt(pool.max_buyers, 0);
    const totalUnitsBought = allJoins.reduce((sum, record) => sum + toInt(record.quantity_purchased, 0), 0);

    const unitsLeft = cumulativeTargetQuantity - totalUnitsBought;
    const peopleLeft = maxBuyers - totalPeople;

    return res.status(200).json({
      message: 'Tracking data retrieved successfully',
      pool: {
        title: pool.pool_title,
        product_name: pool.product_name,
        product_description: pool.product_description,
        product_image_url: `${IMAGE_BASE_URL}${pool.product_image}`,
        status: pool.pool_status,
        expected_arrival_date: pool.expected_arrival_date
      },
      metrics: {
        members_joined: totalPeople,
        members_left: peopleLeft >= 0 ? peopleLeft : 0,
        units_purchased: totalUnitsBought,
        units_left: unitsLeft >= 0 ? unitsLeft : 0,
        total_target: cumulativeTargetQuantity
      },
      customer_activity: {
        quantity_purchased: toInt(joinedRecord.quantity_purchased, 0),
        date_joined: joinedRecord.date,
        tracking_number: getcustomer?.phone_number, // as in your code
        variations_purchased
      },
      activity: {
        created_at: pool.created_at_date,
        processing_date: pool.processing_date,
        arrived_date: pool.arrived_date
      }
    });

  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}







// Get supplier dashboard

exports.getSupplierDashboard = async (req, res) => {
  const supplierId = req.user?.id;
  const { filter } = req.query;

  let page = 0;
  const pagenumber = parseInt(req.query.page, 10);
  if (!Number.isNaN(pagenumber) && pagenumber > 0) page = pagenumber;

  if (!supplierId) return res.status(401).json({ message: 'Unauthorized' });

  // ---- helpers --------------------------------------------------------------
  const parseMaybeJson = (v, fallback = []) => {
    if (v == null) return fallback;
    if (Array.isArray(v)) return v;
    if (typeof v === 'object') return v;
    try { return JSON.parse(v); } catch { return fallback; }
  };

  const loadPoolVariations = (pool) => parseMaybeJson(pool?.variation, []);

  const sumVariationQty = (varItems) =>
    (Array.isArray(varItems) ? varItems : []).reduce((s, it) => s + parseInt(it?.quantity_purchased || 0, 10), 0);

  // revenue for a single join (variation-aware)
  const computeJoinRevenue = (pool, join) => {
    const poolVars = loadPoolVariations(pool);
    const basePrice = parseFloat(pool?.price_per_unit || 0);

    if (poolVars.length > 0) {
      const purchased = parseMaybeJson(join?.variation, []);
      if (!purchased.length) {
        // fallback to base price × total units if variation array is empty
        return parseInt(join?.quantity_purchased || 0, 10) * basePrice;
      }
      return purchased.reduce((sum, item) => {
        const pv = poolVars.find(v => String(v.id) == String(item.id));
        const ppu = parseFloat(pv?.price_per_unit || 0);
        const qty = parseInt(item?.quantity_purchased || 0, 10);
        return sum + (ppu * qty);
      }, 0);
    }

    // no variations
    return parseInt(join?.quantity_purchased || 0, 10) * basePrice;
  };

  // quantity for a single join (variation-aware)
  const computeJoinQuantity = (pool, join) => {
    const poolVars = loadPoolVariations(pool);
    if (poolVars.length > 0) {
      const purchased = parseMaybeJson(join?.variation, []);
      return sumVariationQty(purchased);
    }
    return parseInt(join?.quantity_purchased || 0, 10);
  };

  // revenue for entire pool (variation-aware)
  const computePoolRevenue = async (pool) => {
    const joins = await Buying_pool_joined_by_customers.findAll({ where: { pool_id: pool.id } });
    return joins.reduce((sum, j) => sum + computeJoinRevenue(pool, j), 0);
  };

  // target quantity for a pool (variation-aware)
  const getPoolTargetQty = (pool) => {
    const vars = loadPoolVariations(pool);
    if (vars.length > 0) {
      return vars.reduce((s, v) => s + parseInt(v?.target_quantity || 0, 10), 0);
    }
    return parseInt(pool?.target_quantity || 0, 10);
  };

  // amount paid for a recent join (variation-aware)
  const amountPaidForJoin = (pool, join) => computeJoinRevenue(pool, join);

  // build per-log payment details from extra purchases
  const buildPaymentLogsForJoin = async (pool, join) => {
    const poolVars = loadPoolVariations(pool);
    const hasVars = poolVars.length > 0;
    const logs = await Buying_pool_extra_purchases.findAll({
      where: { pool_join_id: join.id },
      order: [['id', 'ASC']]
    });

    return logs.map(log => {
      const qty = parseInt(log?.quantity_purchased || 0, 10);
      let variations_purchased = [];
      let total_amount = 0;

      if (hasVars) {
        const logVars = parseMaybeJson(log?.varaition, []);
        variations_purchased = logVars.map(item => {
          const pv = poolVars.find(v => String(v.id) == String(item.id));
          const lineQty = parseInt(item?.quantity_purchased || 0, 10);
          const ppu = parseFloat(pv?.price_per_unit || 0);
          const lineTotal = ppu * lineQty;
          total_amount += lineTotal;
          return {
            id: item.id,
            ...pv, // length, size, color, weight, material, price_per_unit, target_quantity
            quantity_purchased: lineQty,
            line_total: lineTotal
          };
        });
        // If no variation array in the log, fall back to base price per pool (rare)
        if (!variations_purchased.length) {
          const basePrice = parseFloat(pool?.price_per_unit || 0);
          total_amount = basePrice * qty;
        }
      } else {
        // no variation on pool
        const basePrice = parseFloat(pool?.price_per_unit || 0);
        total_amount = basePrice * qty;
      }

      return {
        payment_reference: log?.payment_reference || '',
        quantity_purchased: qty,
        variations_purchased, // [] if no variations
        total_amount,
        created_at: log?.createdAt || log?.created_at || null
      };
    });
  };

  try {
    const supplier = await Mycroshop_suppliers.findByPk(supplierId);
    if (!supplier) return res.status(404).json({ message: 'Supplier not found' });

    const commissionRate = parseFloat(supplier.mycroshop_sub_commission || '0');

    // all subscribers tied to this supplier
    const allSubscribers = await Buying_pool_subscription_payment.findAll({
      where: { sub_type: 'supplier', supplier_id: supplierId },
      order: [['date', 'DESC']]
    });

    const allCustomerIds = allSubscribers.map(sub => sub.buying_pool_customer_id);

    const supplierPools = await Buying_pools.findAll({
      where: { mycroshop_supplier_id: supplierId },
      order: [['id', 'DESC']]
    });

    // total pool revenue (variation-aware)
    const allPoolRevenue = await Promise.all(supplierPools.map(pool => computePoolRevenue(pool)));
    const totalPoolRevenue = allPoolRevenue.reduce((a, b) => a + b, 0);

    // subscription revenue
    const subPlan = await Buying_pool_suppliers_sub_plan.findOne({ where: { mycroshop_supplier_id: supplierId } });
    const yearlySubAmount = subPlan ? parseInt(subPlan.yearly_sub_amount || 0, 10) : 0;
    const subRevenue = yearlySubAmount * allSubscribers.length;
    const netSubRevenue = subRevenue - (commissionRate / 100) * subRevenue;

    const totalSubscribers = allSubscribers.length;
    const totalPools = supplierPools.length;

    const summaryMetrics = {
      total_subscription_revenue: netSubRevenue,
      total_active_subscribers: totalSubscribers,
      total_pool_created: totalPools,
      total_pool_revenue: totalPoolRevenue
    };

    // ------------------------ FILTER: subscribers ----------------------------
    if (filter === 'subscribers') {
      // latest subscription per customer
      const latestByCustomer = {};
      for (const sub of allSubscribers) {
        const cid = sub.buying_pool_customer_id;
        if (!latestByCustomer[cid] || dayjs(sub.date).isAfter(dayjs(latestByCustomer[cid].date))) {
          latestByCustomer[cid] = sub;
        }
      }

      const subscriberDetails = await Promise.all(
        Object.values(latestByCustomer).map(async (sub) => {
          const customer = await Buying_pool_customers.findByPk(sub.buying_pool_customer_id);
          if (!customer) return null;

          const expirationDate = dayjs(sub.expiration_date);
          const isActive = expirationDate.isAfter(dayjs()) || expirationDate.isSame(dayjs(), 'day');

          // joins for THIS supplier’s pools only
          const joins = await Buying_pool_joined_by_customers.findAll({
            where: { customer_id: customer.id }
          });

          // group by pools that belong to this supplier
          const poolItems = [];
          let aggQty = 0;
          let aggRevenue = 0;

          for (const j of joins) {
            const pool = await Buying_pools.findByPk(j.pool_id);
            if (!pool || String(pool.mycroshop_supplier_id) !== String(supplierId)) continue;

            const joinQty = computeJoinQuantity(pool, j);
            const joinRevenue = computeJoinRevenue(pool, j);
            aggQty += joinQty;
            aggRevenue += joinRevenue;

            const payment_logs = await buildPaymentLogsForJoin(pool, j);

            poolItems.push({
              pool_id: j.pool_id,
              title: pool?.pool_title || '',
              is_pool_active: pool?.pool_status === 'active',
              date_joined: j.date,
              joined_summary: {
                join_id: j.id,
                status: j.status,
                quantity_purchased: joinQty,
                total_revenue: joinRevenue
              },
              payment_logs
            });
          }

          return {
            customer: {
              id: customer.id,
              name: customer.name,
              email: customer.email,
              phone_number: customer.phone_number
            },
            subscription_status: isActive ? 'active' : 'inactive',
            last_subscription_date: sub.date,
            totals: {
              total_quantity_purchased: aggQty,
              total_revenue: aggRevenue
            },
            pools: poolItems
          };
        })
      );

      const cleaned = subscriberDetails.filter(Boolean);
      const paginatedData = await pagination(cleaned, page);

      return res.status(200).json({
        ...summaryMetrics,
        ...paginatedData
      });
    }

    // ------------------------ FILTER: performance ----------------------------
    if (filter === 'performance') {
      const paginatedPools = await pagination(supplierPools, page);

      const performanceData = await Promise.all(
        paginatedPools.data.map(async (pool) => {
          const joins = await Buying_pool_joined_by_customers.findAll({ where: { pool_id: pool.id } });

          // total qty (variation-aware)
          const totalQty = joins.reduce((sum, j) => sum + computeJoinQuantity(pool, j), 0);

          // revenue (variation-aware)
          const revenue = joins.reduce((sum, j) => sum + computeJoinRevenue(pool, j), 0);

          const targetQty = getPoolTargetQty(pool);
          const growthRate = targetQty > 0 ? (totalQty / targetQty) * 100 : 0;

          return {
            title: pool.pool_title,
            status: pool.pool_status,
            people_joined: joins.length,
            growth_rate: `${growthRate.toFixed(2)}%`,
            revenue
          };
        })
      );

      return res.status(200).json({
        ...summaryMetrics,
        performance: performanceData,
        ...paginatedPools
      });
    }

    // ------------------------ DEFAULT: overview + activities ------------------
    const currentMonth = dayjs();
    const monthlyData = [];

    for (let i = 0; i < 6; i++) {
      const month = currentMonth.subtract(i, 'month');
      const monthStr = month.format('YYYY-MM');

      const monthlySubs = allSubscribers.filter(sub => sub.date && String(sub.date).startsWith(monthStr));
      const monthRevenue = yearlySubAmount * monthlySubs.length;
      const netMonthRevenue = monthRevenue - (commissionRate / 100) * monthRevenue;

      monthlyData.push({
        month: month.format('MMM YYYY'),
        revenue: netMonthRevenue,
        subscribers: monthlySubs.length
      });
    }

    const totalRevenueForPeriod = monthlyData.reduce((sum, m) => sum + m.revenue, 0);
    const monthlyWithPercent = monthlyData
      .map(entry => ({
        ...entry,
        percentage: totalRevenueForPeriod
          ? parseFloat(((entry.revenue / totalRevenueForPeriod) * 100).toFixed(2))
          : 0
      }))
      .reverse();

    const recentPoolJoins = await Buying_pool_joined_by_customers.findAll({
      order: [['date', 'DESC']],
      limit: 5
    });

    const recentSubscribers = await Buying_pool_subscription_payment.findAll({
      where: { sub_type: 'supplier', supplier_id: supplierId },
      order: [['date', 'DESC']],
      limit: 5
    });

    const recentSubscriberActivities = await Promise.all(
      recentSubscribers.map(async (sub) => {
        const customer = await Buying_pool_customers.findByPk(sub.buying_pool_customer_id);
        return {
          type: 'new_subscriber',
          name: customer?.name,
          email: customer?.email,
          date: sub.date
        };
      })
    );

    const recentPoolJoinActivities = await Promise.all(
      recentPoolJoins.map(async (join) => {
        const pool = await Buying_pools.findByPk(join.pool_id);
        if (!pool || String(pool.mycroshop_supplier_id) !== String(supplierId)) return null;

        const customer = await Buying_pool_customers.findByPk(join.customer_id);
        return {
          type: 'joined_pool',
          name: customer?.name,
          pool: pool?.pool_title,
          amount_paid: amountPaidForJoin(pool, join), // variation-aware
          date: join.date
        };
      })
    );

    const activities = [
      ...recentSubscriberActivities,
      ...recentPoolJoinActivities.filter(Boolean)
    ];

    return res.status(200).json({
      ...summaryMetrics,
      overview: monthlyWithPercent,
      activities
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};



//get supplier 
exports.getAllBuyingPoolSubscribers = async (req, res) => {
  const { name = '', status = '', startDate = null, endDate = null } = req.query;
  const supplierId = req.user?.id;

  try {
    if (!supplierId) return res.status(401).json({ message: 'Unauthorized' });

    let page = 0;
    const pagenumber = req.query.page;
    if (!Number.isNaN(pagenumber) && pagenumber > 0) page = pagenumber;

    // ---------- Helpers ----------
    const parseJSON = (v, fallback) => {
      if (v == null) return fallback;
      if (Array.isArray(v) || typeof v === 'object') return v;
      try { return JSON.parse(v); } catch (_) { return fallback; }
    };
    const toInt = (n, d = 0) => {
      const x = parseInt(n, 10);
      return Number.isFinite(x) ? x : d;
    };
    const toFloat = (n, d = 0) => {
      const x = parseFloat(n);
      return Number.isFinite(x) ? x : d;
    };
    const buildVarMap = (pool) => {
      const arr = parseJSON(pool.variation, []);
      const map = new Map();
      for (const v of (arr || [])) {
        const key = String(v.id);
        map.set(key, v);
      }
      return map;
    };
    const computeJoinRevenue = (pool, join) => {
      const varMap = buildVarMap(pool);
      const hasVars = varMap.size > 0;

      if (!hasVars) {
        // No variations → base price
        return toInt(join.quantity_purchased) * toFloat(pool.price_per_unit);
      }

      // Variations: join.variation can already be JSON or stringified
      const purchased = parseJSON(join.variation, []);
      if (!Array.isArray(purchased) || purchased.length === 0) {
        // fallback to base price if no variation payload
        return toInt(join.quantity_purchased) * toFloat(pool.price_per_unit);
      }

      let sum = 0;
      for (const it of purchased) {
        const v = varMap.get(String(it.id));
        if (!v) continue;
        sum += toInt(it.quantity_purchased) * toFloat(v.price_per_unit);
      }
      return sum;
    };
    const computeExtraLog = (pool, extraRow) => {
      const varMap = buildVarMap(pool);
      const hasVars = varMap.size > 0;

      // Normalize variations from extra purchase record.
      // We accept either [{id, quantity_purchased}] or a full object array.
      const raw = extraRow?.varaition; // NOTE: field name 'varaition' per your model
      let arr = parseJSON(raw, []);
      if (!Array.isArray(arr)) arr = [];

      let total = 0;
      const variations_purchased = [];

      if (hasVars && arr.length > 0) {
        for (const it of arr) {
          const id = String(it?.id);
          const qty = toInt(it?.quantity_purchased);
          const v = varMap.get(id);
          if (!v) continue;

          const line = qty * toFloat(v.price_per_unit);
          total += line;
          variations_purchased.push({
            ...v,
            id: v.id, // keep id explicit
            quantity_purchased: qty,
            line_total: line
          });
        }
      }

      if (!hasVars) {
        total = toInt(extraRow.quantity_purchased) * toFloat(pool.price_per_unit);
      }

      return {
        payment_reference: extraRow.payment_reference,
        quantity_purchased: toInt(extraRow.quantity_purchased),
        variations_purchased: hasVars ? variations_purchased : [],
        total_amount: total,
        created_at: extraRow.created_at || extraRow.createdAt || null
      };
    };

    // ---------- Supplier + plans for summary ----------
    const supplier = await Mycroshop_suppliers.findByPk(supplierId);
    if (!supplier) return res.status(404).json({ message: 'Supplier not found' });

    const commissionRate = toFloat(supplier.mycroshop_sub_commission || 0);

    const subPlan = await Buying_pool_suppliers_sub_plan.findOne({
      where: { mycroshop_supplier_id: supplierId }
    });
    const yearlySubAmount = toInt(subPlan?.yearly_sub_amount || 0);

    // ---------- Fetch all subs for this supplier ----------
    const allSubscribers = await Buying_pool_subscription_payment.findAll({
      where: { sub_type: 'supplier', supplier_id: supplierId }
    });

    // Deduplicate by customer with most recent sub date
    const latestSubByCustomer = {};
    for (const sub of allSubscribers) {
      const cid = sub.buying_pool_customer_id;
      if (!latestSubByCustomer[cid] || dayjs(sub.date).isAfter(dayjs(latestSubByCustomer[cid].date))) {
        latestSubByCustomer[cid] = sub;
      }
    }
    const latestSubs = Object.values(latestSubByCustomer);

    // Active status (unique customers)
    const activeUnique = latestSubs.filter(s =>
      dayjs(s.expiration_date).isAfter(dayjs()) || dayjs(s.expiration_date).isSame(dayjs(), 'day')
    );

    // ---------- Supplier pools + variation-aware total pool revenue ----------
    const supplierPools = await Buying_pools.findAll({
      where: { mycroshop_supplier_id: supplierId }
    });

    const totalPoolRevenue = await (async () => {
      let total = 0;
      for (const pool of supplierPools) {
        const joins = await Buying_pool_joined_by_customers.findAll({ where: { pool_id: pool.id } });
        for (const j of joins) total += computeJoinRevenue(pool, j);
      }
      return total;
    })();

    // Subscription revenue (net after commission) based on unique active subscribers
    const total_subscription_revenue =
      Math.max(0, activeUnique.length * yearlySubAmount * (1 - commissionRate / 100));

    const summaryMetrics = {
      total_subscription_revenue,
      total_active_subscribers: activeUnique.length,
      total_pool_created: supplierPools.length,
      total_pool_revenue: totalPoolRevenue
    };

    // ---------- Build per-subscriber detail ----------
    const subscriberDetails = await Promise.all(
      latestSubs.map(async (sub) => {
        const customer = await Buying_pool_customers.findByPk(sub.buying_pool_customer_id);
        if (!customer) return null;

        const expirationDate = dayjs(sub.expiration_date);
        const isActive = expirationDate.isAfter(dayjs()) || expirationDate.isSame(dayjs(), 'day');

        // Only pools from THIS supplier:
        const joins = await Buying_pool_joined_by_customers.findAll({
          where: { customer_id: customer.id }
        });

        // Filter to supplier pools
        const joinsForSupplier = [];
        for (const j of joins) {
          const pool = await Buying_pools.findByPk(j.pool_id);
          if (!pool) continue;
          if (pool.mycroshop_supplier_id !== supplierId) continue;
          joinsForSupplier.push({ j, pool });
        }

        // Per-pool details + compute totals per customer
        let totalQty = 0;
        let totalRevenue = 0;

        const pools = await Promise.all(
          joinsForSupplier.map(async ({ j, pool }) => {
            const joinRevenue = computeJoinRevenue(pool, j);
            totalQty += toInt(j.quantity_purchased);
            totalRevenue += joinRevenue;

            // Extra purchase logs for this join
            const extras = await Buying_pool_extra_purchases.findAll({
              where: { pool_join_id: j.id },
              order: [['id', 'ASC']]
            });
            const payment_logs = extras.map(ex => computeExtraLog(pool, ex));

            return {
              pool_id: pool.id,
              title: pool.pool_title,
              is_pool_active: pool.pool_status === 'active',
              date_joined: j.date,
              joined_summary: {
                join_id: j.id,
                status: j.status || 'pending',
                quantity_purchased: toInt(j.quantity_purchased),
                total_revenue: joinRevenue
              },
              payment_logs
            };
          })
        );

        return {
          customer: {
            id: customer.id,
            name: customer.name,
            email: customer.email,
            phone_number: customer.phone_number
          },
          subscription_status: isActive ? 'active' : 'inactive',
          last_subscription_date: sub.date,
          totals: {
            total_quantity_purchased: totalQty,
            total_revenue: totalRevenue
          },
          pools
        };
      })
    );

    // Remove nulls (missing customer rows etc.)
    let rows = subscriberDetails.filter(Boolean);

    // ---------- Apply filters ----------
    if (name) {
      rows = rows.filter(r => r.customer.name?.toLowerCase().includes(String(name).toLowerCase()));
    }
    if (status === 'active' || status === 'inactive') {
      rows = rows.filter(r => r.subscription_status === status);
    }
    if (startDate && endDate) {
      const start = dayjs(startDate).startOf('day');
      const end = dayjs(endDate).endOf('day');
      rows = rows.filter(r => {
        const d = dayjs(r.last_subscription_date);
        return d.isAfter(start) && d.isBefore(end);
      });
    }

    // ---------- Paginate + respond ----------
    const paginated = await pagination(rows, page);

    return res.status(200).json({
      ...summaryMetrics,
      ...paginated
    });
  } catch (error) {
    return res.status(400).json({ message: error.message });
  }
};






//get pool details
exports.getPoolDetailsByParams = async (req, res) => {
    const { poolId, supplierId } = req.query;

    if (!poolId || !supplierId) {
        return res.status(400).json({ message: 'Missing poolId or supplierId in params' });
    }

    try {
        const pool = await Buying_pools.findOne({
            where: {
                id: poolId,
                mycroshop_supplier_id: supplierId
            }
        });

        if (!pool) {
            return res.status(404).json({ message: 'Pool not found for the specified supplier' });
        }

        const joined = await Buying_pool_joined_by_customers.findAll({ where: { pool_id: poolId } });
        const totalJoined = joined.length;
        const totalUnitsBought = joined.reduce((sum, r) => sum + parseInt(r.quantity_purchased || 0), 0);
        const totalPeopleAllowed = parseInt(pool.max_buyers || 0);

        // --- START: New Logic to Handle Variations ---
        let variations = pool.variation ? (typeof pool.variation === 'string' ? JSON.parse(pool.variation) : pool.variation) : [];
        let cumulativeTargetQuantity = 0;

        if (Array.isArray(variations) && variations.length > 0) {
            // Enhance each variation with its own stock count
            variations = variations.map(variation => {
                let unitsPurchasedForVariation = 0;
                for (const join of joined) {
                    const purchasedVariations = Array.isArray(join.variation) ? join.variation : [];
                    const matchedVarInPurchase = purchasedVariations.find(pv => pv.id == variation.id);
                    if (matchedVarInPurchase) {
                        unitsPurchasedForVariation += parseInt(matchedVarInPurchase.quantity_purchased || 0);
                    }
                }
                const targetForVariation = parseInt(variation.target_quantity || 0);
                const unitsLeftForVariation = targetForVariation - unitsPurchasedForVariation;
                return {
                    ...variation,
                    units_purchased: unitsPurchasedForVariation,
                    units_left: unitsLeftForVariation
                };
            });

            // Calculate the overall target from the sum of variation targets
            cumulativeTargetQuantity = variations.reduce((sum, v) => sum + parseInt(v.target_quantity || 0), 0);
        } else {
            // Fallback for pools without variations
            cumulativeTargetQuantity = parseInt(pool.target_quantity || 0);
        }
        // --- END: New Logic ---

        const initials = [];
        for (const j of joined) {
            const customer = await Buying_pool_customers.findByPk(j.customer_id, {
                attributes: ['name']
            });
            if (customer?.name) {
                initials.push(customer.name.charAt(0).toUpperCase());
            }
        }

        const supplier = await Mycroshop_suppliers.findByPk(supplierId, {
            attributes: ['id', 'supplier_name', 'email', 'phone_number']
        });

        const supplierplan = await Buying_pool_suppliers_sub_plan.findOne({
            where: { mycroshop_supplier_id: supplierId },
            attributes: ['id','mycroshop_supplier_id','plan_description','monthly_duration', 'yearly_sub_amount']
        });

        const mycrshopbuyingpoolPLan = await Subscription_plans.findOne({
            where: { plan_name: 'Buying pool' },
            attributes: ['id','plan_name', 'yearly_fee']
        });

        return res.status(200).json({
            message: 'Pool details retrieved successfully',
            supplier_name: supplier?.supplier_name || '',
            supplier_email: supplier.email,
            phone_number: supplier.phone_number,
            pool: {
                ...pool.toJSON(),
                product_image_url: `${IMAGE_BASE_URL}${pool.product_image}`,
                variation: variations // Return the new enhanced variations array
            },
            performance: {
                members_joined: totalJoined,
                members_left: totalPeopleAllowed - totalJoined,
                units_purchased: totalUnitsBought,
                // Use the correct cumulative target for the calculations
                units_left: cumulativeTargetQuantity - totalUnitsBought,
                progress: cumulativeTargetQuantity > 0 ? Math.round((totalUnitsBought / cumulativeTargetQuantity) * 100) : 0
            },
            initials,
            supplierplan,
            mycroshop_pool_plan: mycrshopbuyingpoolPLan
        });
    } catch (err) {
        return res.status(500).json({ message: err.message });
    }
}




//get all suppliers pool
exports.getAllPoolsBySupplierId = async (req, res) => {
  const { supplier_id } = req.query;

  if (!supplier_id) {
    return res.status(400).json({ message: 'supplier_id is required in query params' });
  }

  let page = 0;
  const pagenumber = req.query.page;
  if (!Number.isNaN(pagenumber) && pagenumber > 0) {
    page = pagenumber;
  }

  try {
    const pools = await Buying_pools.findAll({
      where: { mycroshop_supplier_id: supplier_id },
      order: [['id', 'DESC']]
    });

    const formattedPools = await Promise.all(pools.map(async (pool) => {
      const joined = await Buying_pool_joined_by_customers.findAll({ where: { pool_id: pool.id } });
      const totalJoined = joined.length;
      const totalUnitsBought = joined.reduce((sum, r) => sum + parseInt(r.quantity_purchased || 0), 0);
      const totalTarget = parseInt(pool.target_quantity || 0);
      const totalPeopleAllowed = parseInt(pool.max_buyers || 0);

      const initials = [];
      for (const j of joined) {
        const customer = await Buying_pool_customers.findByPk(j.customer_id, {
          attributes: ['name']
        });
        if (customer?.name) {
          initials.push(customer.name.charAt(0).toUpperCase());
        }
      }

      return {
        ...pool.toJSON(),
        product_image_url: `${IMAGE_BASE_URL}${pool.product_image}`,
          variation:  pool.variation
  ? (typeof pool.variation === 'string'
      ? JSON.parse(pool.variation)
      : pool.variation)
  : [],
        performance: {
          members_joined: totalJoined,
          members_left: totalPeopleAllowed - totalJoined,
          units_purchased: totalUnitsBought,
          units_left: totalTarget - totalUnitsBought,
          progress: Math.round((totalUnitsBought / totalTarget) * 100)
        },
        initials
      };
    }));

    const supplier = await Mycroshop_suppliers.findByPk(supplier_id, {
      attributes: ['id', 'supplier_name', 'email', 'phone_number']
    });

    const supplierplan = await Buying_pool_suppliers_sub_plan.findOne({
      where: { mycroshop_supplier_id: supplier_id },
      attributes: ['id','mycroshop_supplier_id','plan_description', 'monthly_duration', 'yearly_sub_amount']
    });

    const mycrshopbuyingpoolPLan = await Subscription_plans.findOne({
      where: { plan_name: 'Buying pool' },
      attributes: ['id','plan_name', 'yearly_fee']
    });

    const paginatedData = await pagination(formattedPools, page);

    return res.status(200).json({
      message: 'Pools retrieved successfully',
      supplier_name: supplier?.supplier_name || '',
      supplier,
      supplierplan,
      mycroshop_pool_plan: mycrshopbuyingpoolPLan,
      pools: paginatedData
    });
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
}


//get category list
exports.getCategory = async (req, res)=>{
    const getAllcategory = await Category.findAll()
    
     return res.status(200).json(getAllcategory);
}

