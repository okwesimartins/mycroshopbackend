// const db = require("../models")
// const Purchase =  db.purchase
// const Op = db.Sequelize.Op;
// const  Sequelize=require('sequelize')
// const bcrypt = require("bcryptjs")
// const stock_movement = db.stock_movement
// const monthly_stock_summary = db.stock_summary
// const Products = db.products
// const Discount = db.discount
// const Customers =  db.customers
// const Invoice = db.invoice

// const pagination = async (items, page) => {

//   var page = page || 1,
//   per_page = 10,
//   offset = (page - 1) * per_page,
//   paginatedItems = items.slice(offset).slice(0, per_page),
//   total_pages = Math.ceil(items.length / per_page);
  
//   return {
//   page: page,
//   per_page: per_page,
//   pre_page: page - 1 ? page - 1 : null,
//   next_page: (total_pages > page) ? page + 1 : null,
//   total: items.length,
//   total_pages: total_pages,
//   data: paginatedItems
//   };
  
// }


// //get stock history 

// exports.getMonthlyStockSummary = async (req, res) => {
//      try {
//         const { month, year, shop_id } = req.query;

//         if (!month || !year || !shop_id) {
//             return res.status(400).json({ message: "Month, year, and shop_id are required" });
//         }
        
//          let page = 0;
//             const pagenumber = req.query.page;
            
           
            
//             if(pagenumber == 0 || pagenumber > 0){
              
//             if(!Number.isNaN(pagenumber) && pagenumber > 0 ){
//                 page = pagenumber;
//             }
            
//             }

//         // Ensure month has leading zero for proper filtering (e.g., "01" instead of "1")
//         const formattedMonth = month.padStart(2, "0");

//         // Get current server date
//         const now = new Date();
//         const currentYear = now.getFullYear();
//         const currentMonth = String(now.getMonth() + 1).padStart(2, "0"); // Ensure two-digit format
//         const currentDay = now.getDate();

//         // Get the last day of the requested month dynamically
//         const lastDayOfMonth = new Date(year, month, 0).getDate();

//         // Determine the previous month and year
//         const prevMonth = formattedMonth === "01" ? "12" : String(Number(formattedMonth) - 1).padStart(2, "0");
//         const prevYear = formattedMonth === "01" ? String(Number(year) - 1) : year;

//         // Check if stock summary for the requested month exists
//         const existingSummary = await monthly_stock_summary.findAll({
//             where: { month: currentMonth, year: currentYear, shop_id },order: [["id", "DESC"]]
//         });

//         if (existingSummary.length === 0) {
//             // No record found for the current month, calculate opening stock from previous month
//             const prevClosingStock = await stock_movement.findAll({
//                 where: {
//                     shop_id,
//                     movement_date: {
//                         [Op.between]: [`${prevYear}-${prevMonth}-01`, `${prevYear}-${prevMonth}-31`]
//                     }
//                 },
//                 attributes: [
//                     "product_id",
//                     "inch",
//                     [Sequelize.fn("SUM", Sequelize.col("balance")), "closing_stock"]
//                 ],
//                 group: ["product_id", "inch"]
//             });

//             // Insert new records for the current month
//             for (const stock of prevClosingStock) {
//                 await monthly_stock_summary.create({
//                     product_id: stock.product_id,
//                     inch: stock.inch,
//                     opening_stock: stock.dataValues.closing_stock || 0,
//                     month: currentMonth,
//                     year: currentYear,
//                     shop_id
//                 });
//             }
//         }
         
//           let totalItemsIn = 0;
//         let totalItemsOut = 0;
//         let totalClosingStock = 0;
//         let totalItemsinstock = 0 
        
//         const getAllproducts = await Products.findAll({
//             attributes: ["total_product_stock", "shop_id"]
//         });

        

//         getAllproducts.forEach(product => {
//             const shopIdsArray = JSON.parse(product.shop_id || "[]"); // Parse shop_id column

//             if (Array.isArray(shopIdsArray) && shopIdsArray.includes(Number(shop_id))) {
//                 totalItemsinstock += Number(product.total_product_stock) || 0;
//             }
//         });
        
//         // Fetch stock summary for requested month & year
//         const stockSummary = await monthly_stock_summary.findAll({
//             where: { month: formattedMonth, year, shop_id },
//             attributes: [
//                 "id",
//                 "product_id",
//                 "inch",
//                 "opening_stock",
//                 "month",
//                 "year",
//                 "shop_id"
//             ],order: [["id", "DESC"]]
//         });

//         // Get stock movements for requested month
//         const stockMovements = await stock_movement.findAll({
//             where: {
//                 shop_id,
//                 movement_date: {
//                     [Op.between]: [`${year}-${formattedMonth}-01`, `${year}-${formattedMonth}-31`]
//                 }
//             },
//             attributes: [
//                 "product_id",
//                 "inch",
//                 "movement_type",
//                 [Sequelize.fn("SUM", Sequelize.col("quantity")), "total_quantity"]
//             ],
//             group: ["product_id", "inch", "movement_type"]
//         });

//         // Map movements for quick lookup
//         const movementMap = {};
//         stockMovements.forEach(movement => {
//             const key = `${movement.product_id}-${movement.inch}`;
//             if (!movementMap[key]) {
//                 movementMap[key] = { total_purchases: 0, total_sales: 0, total_items_in: 0, total_items_out: 0 };
//             }

//             const quantity = Number(movement.dataValues.total_quantity);
//             if (movement.movement_type === "purchase") {
//                 movementMap[key].total_purchases += quantity;
//                 movementMap[key].total_items_in += quantity;
//             } else if (movement.movement_type === "sales") {
//                 movementMap[key].total_sales += quantity;
//                 movementMap[key].total_items_out += quantity;
//             } else if (movement.movement_type === "return") {
//                 movementMap[key].total_items_in += quantity;
//             } else if (movement.movement_type === "damage") {
//                 movementMap[key].total_items_out += quantity;
//             }
//         });

//         // Combine stock summary and movement data
//         const finalSummary = await Promise.all(stockSummary.map(async summary => {
//             const key = `${summary.product_id}-${summary.inch}`;
//             const movementData = movementMap[key] || { total_purchases: 0, total_sales: 0, total_items_in: 0, total_items_out: 0 };
//              const getProductinfo = await Products.findOne({where:{id:summary.product_id}})
             
//               totalItemsIn += movementData.total_items_in;
//             totalItemsOut += movementData.total_items_out;
//             const calcClosingstock =   year == currentYear && formattedMonth == currentMonth && currentDay < lastDayOfMonth
//                         ? "TBD"
//                         : summary.opening_stock + movementData.total_items_in - movementData.total_items_out
                        
//             totalClosingStock += calcClosingstock !== "TBD" ? calcClosingstock : 0;
            
//             return {
//                 summary_id : summary.id,
//                 product_name : getProductinfo.product_name,
//                 product_id: summary.product_id,
//                 inch: summary.inch,
//                 opening_stock: summary.opening_stock,
//                 month: summary.month,
//                 year: summary.year,
//                 shop_id: summary.shop_id,
//                 total_purchases: movementData.total_purchases,
//                 total_sales: movementData.total_sales,
//                 total_items_in: movementData.total_items_in,
//                 total_items_out: movementData.total_items_out,
//                 closing_stock:
//                     year == currentYear && formattedMonth == currentMonth && currentDay < lastDayOfMonth
//                         ? "TBD"
//                         : summary.opening_stock + movementData.total_items_in - movementData.total_items_out
//             };
//         }));
         
//         if(pagenumber == "All"){
//               return res.status(200).json({totalitemsinstock:totalItemsinstock, totalitemsin: totalItemsIn,totalitemsout:totalItemsOut,totalclosingStock: totalClosingStock, stock_summary:finalSummary});
//         }
// const paginatedData = await pagination(finalSummary, page)
//         return res.status(200).json({totalitemsinstock:totalItemsinstock, totalitemsin: totalItemsIn,totalitemsout:totalItemsOut,totalclosingStock: totalClosingStock,stock_summary:paginatedData});
//     } catch (error) {

//         return res.status(500).json({ message: error.message });
//     }
// };

// exports.getstockmovement = async (req, res, next)=>{
//      try {
         
//           let page = 0;
//             const pagenumber = req.query.page;
            
           
            
//             if(pagenumber == 0 || pagenumber > 0){
              
//             if(!Number.isNaN(pagenumber) && pagenumber > 0 ){
//                 page = pagenumber;
//             }
            
//             }
            
//         // Get the stock summary record
//         const summaryId = req.query.summary_id
//         const stockSummary = await monthly_stock_summary.findOne({
//             where: { id: summaryId }
//         });

//         if (!stockSummary) {
//             throw new Error("Stock Summary not found");
//         }

//         const { month, year, shop_id, product_id } = stockSummary;

//         // Convert month & year into a valid date range
//         const startDate = `${year}-${month}-01`; // First day of the month
//         const endDate = new Date(year, month, 0).toISOString().split("T")[0]; // Last day of the month

//         // Query stock movements that match product, shop, and date range
//         const stockMovements = await stock_movement.findAll({
//             where: {
//                 product_id: product_id,
//                 shop_id: shop_id,
//                 movement_date: {
//                     [Op.between]: [startDate, endDate] // Filter stock movements within the month
//                 }
//             },
//             order: [["id", "DESC"]] // Optional: Order by date
//         });
//         let finaldata = []
//         for(const value of stockMovements){
//             const getProducts = await Products.findOne({where:{id:value.product_id}})
//             const result = {
                
//             "id":  value.id,
//             "product_id":  value.product_id,
//             "product_name": getProducts.product_name,
//             "inch":  value.inch,
//             "movement_type":  value.movement_type,
//             "movement_reason": value.movement_reason,
//             "quantity": value.quantity,
//             "balance": value.balance,
//             "movement_date": value.movement_date,
//             "shop_id": value.shop_id
//             }
            
//             finaldata.push(result)
//         }
//          if(pagenumber == "All"){
//              return res.status(200).json(finaldata);
//          }
//         const paginatedData = await pagination(finaldata, page)
//   return res.status(200).json(paginatedData);
        
//     } catch (error) {
//          return res.status(500).json({ message: error.message });
//     }
// }






// exports.getSalesSummary = async (req, res, next) => {
//     try {
        
//         const shop_id = req.query.shop_id
//         const year = req.query.year
//         const month = req.query.month
        
//         if(!shop_id && !year && !month){
//                 return res.status(500).json({ message: "all fields are required"});
//         }
//         // Define months mapping
//         const monthsMap = {
//             "01": "January", "02": "February", "03": "March", "04": "April",
//             "05": "May", "06": "June", "07": "July", "08": "August",
//             "09": "September", "10": "October", "11": "November", "12": "December"
//         };
        
        
      
//         // Ensure month has leading zero for proper filtering (e.g., "01" instead of "1")
//         const formattedMonth = month.padStart(2, "0");
//         // Get all invoices for the shop in the selected year
//         const invoices = await Invoice.findAll({
//             where: {
//                 shop_id: shop_id,
//                 status: "Paid",
//                 date: {
//                      [Op.between]: [`${year}-${formattedMonth}-01`, `${year}-${formattedMonth}-31`], // Filter by year
//                 }
//             },order: [["id", "DESC"]],
//             attributes: ["total_amount", "products_ordered_array", "date"]
//         });

//         let totalSalesValue = 0;
//         let totalItemsSold = 0;
//         let totalOrders = invoices.length;
//         let totalProfit = 0;
//         let yearlySales = {}; // Object to store sales per month
//         let productSalesMap = {}; // Object to store product sales count

//         // Initialize yearly sales structure
//         Object.entries(monthsMap).forEach(([num, name]) => {
//             yearlySales[num] = { 
//                 monthName: name, 
//                 totalSales: 0, 
//                 dailySales: {} 
//             };
//         });



  
//          // Fetch yearly invoices (for yearly sales report)
//     const yearlyInvoices = await Invoice.findAll({
//         where: {
//             shop_id: shop_id,
//             status: "Paid",
//             date: {
//                 [Op.between]: [`${year}-01-01`, `${year}-12-31`] // Fetches all invoices in the year
//             }
//         },
//         attributes: ["total_amount", "date"]
//     });
    
        
//           for (const invoice of yearlyInvoices) { 
//         const invoiceDate = new Date(invoice.date);
//         const monthNum = String(invoiceDate.getMonth() + 1).padStart(2, "0");
//         const dayNum = String(invoiceDate.getDate()).padStart(2, "0");

//         yearlySales[monthNum].totalSales += Number(invoice.total_amount) || 0;
//         yearlySales[monthNum].dailySales[dayNum] = 
//             (yearlySales[monthNum].dailySales[dayNum] || 0) + Number(invoice.total_amount);
//     }
    
    
//         for (const invoice of invoices) {
//             totalSalesValue += Number(invoice.total_amount) || 0;

//             // Parse the ordered products array
//             const orderedProducts = JSON.parse(invoice.products_ordered_array || "[]");

//             for (const product of orderedProducts) {
//                 const { product_id, quantity, inches } = product;
//                 totalItemsSold += Number(quantity) || 0;

//                 // Fetch product details to calculate profit
//               const productDetails = await Products.findOne({
//     where: { id: product_id },
//     attributes: ["total_buying_price", "total_selling_price", "inches", "shop_id"]
// });




// // Parse shop_id array
// const shopIdsArray = JSON.parse(productDetails.shop_id || "[]");
// if (productDetails) {
    
// // Check if the shop_id exists in the array
// if (shopIdsArray.includes(Number(shop_id))) {
      
//                     let sellingPrice = Number(productDetails.total_selling_price) || 0;
//                     let buyingPrice = Number(productDetails.total_buying_price) || 0;

                    
//                     if (inches != "") {
//                         const productInches = JSON.parse(productDetails.inches || "[]");
//                         const matchedInch = productInches.filter(p => Number(p.inche) === Number(inches)).shift()
                           
                          
//                         if (matchedInch) {
//                             sellingPrice = Number(matchedInch.selling_price) || 0;
//                             buyingPrice = Number(matchedInch.buying_price) || 0;
//                         }
//                     }

                    
//                     totalProfit += (Number(sellingPrice) -Number(buyingPrice)) * Number(quantity);

//                     // Track product sales for best-seller calculation
//                     if (!productSalesMap[product_id]) {
//                         productSalesMap[product_id] = { name: product.product_name, totalSold: 0 };
//                     }
//                     productSalesMap[product_id].totalSold += Number(quantity);
//                 }
// }
             
             
              
//             }
            

           
//         }

//         // Find top 5 best-selling products
//         const sortedProducts = Object.entries(productSalesMap)
//             .sort((a, b) => b[1].totalSold - a[1].totalSold) // Sort by totalSold
//             .slice(0, 5); // Get top 5

//         // Calculate percentage for each top product
//         const totalBestSellerSales = sortedProducts.reduce((sum, p) => sum + p[1].totalSold, 0);
//         const bestSellingProducts = sortedProducts.map(([product_id, data]) => ({
//             product_id,
//             product_name: data.name,
//             totalSold: data.totalSold,
//             percentage: ((data.totalSold / totalBestSellerSales) * 100).toFixed(2) + "%",
//         }));

//         const graphData = {
//             totalSalesValue,
//             totalItemsSold,
//             totalOrders,
//             totalProfit,
//             yearlySales: Object.values(yearlySales), // Convert object to array
//             bestSellingProducts
//         };
//         return res.status(200).json(graphData);
//     } catch (error) {
//         return res.status(500).json({ message: error.message });
//     }



// }


// //get sales record 
// exports.getSales = async (req, res, next)=>{
    
//     const {shop_id, year,month, search_value} = req.query
    
//       if(!shop_id && !year && !month){
//                 return res.status(500).json({ message: "all fields are required"});
//         }
    
    
//             let page = 0;
//             const pagenumber = req.query.page;
            
//             if(pagenumber == 0 || pagenumber > 0){
              
//             if(!Number.isNaN(pagenumber) && pagenumber > 0 ){
//                 page = pagenumber;
//             }
            
//             }
            
//             let invoices
//             // Ensure month has leading zero for proper filtering (e.g., "01" instead of "1")
//         const formattedMonth = month.padStart(2, "0");
//             if(search_value){
//                   invoices = await Invoice.findAll({
//             where: {
//                 shop_id: shop_id,
//                 status: "Paid",
//                 invoice_number: search_value,
//                 date: {
//                     [Op.between]: [`${year}-${formattedMonth}-01`, `${year}-${formattedMonth}-31`], // Filter by year
//                 }
//             },order: [["id", "DESC"]]
//         });
//             }
            
            
//      // Get all invoices for the shop in the selected year
//       if(!search_value){
//              invoices = await Invoice.findAll({
//             where: {
//                 shop_id: shop_id,
//                 status: "Paid",
//                 date: {
//                     [Op.between]: [`${year}-${month ? month : "01"}-01`, `${year}-${month ? month : "12"}-31`], // Filter by year
//                 }
//             },order: [["id", "DESC"]]
//         });
//       }
        
//         salesdataArray = []
//          for(const value of invoices){
//              const getCustomerdata = await Customers.findOne({where:{id: value.customer_id}, attributes:['id','name','email','phone_number']})
//              const parseOrderedproduct = JSON.parse(value.products_ordered_array	)
            
//              const invoiceData = {
//                  "invoice_number": value.invoice_number,
//                  "customer_info": getCustomerdata,
//                  "date": value.date,
//                  "payment_method": value.payment_method,
//                  "total_amount": value.total_amount,
//                  "created_by": value.created_by,
//                  "payment_status": value.status,
//                  "products_ordered": parseOrderedproduct,
//                  "discount_name" : value.discount_name
//              }
//              salesdataArray.push(invoiceData)
//          }
//         if(pagenumber == "All"){
//              return res.status(200).json(salesdataArray);
//          }
//         const paginatedData = await pagination(salesdataArray, page)
//   return res.status(200).json(paginatedData);
        
// }









