// const db = require("../models")

// const Supplier = db.suppliers
// const disabled_users_products_and_suppliers = db.disabled_users_products_and_suppliers
// const Shop = db.shop
// const Op = db.Sequelize.Op
// //create
// exports.Createsupplier = async (req, res, next)=>{
//       const {supplier_name, shop_id, supplier_email, supplier_phonenumber, country, state} = req.body
      
//       let date_ob = new Date();
//                 let date = ("0" + date_ob.getDate()).slice(-2);
//                 let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
//                 let year = date_ob.getFullYear();
//                 const date_recorded = year + "-" + month + "-" + date;
                
//         //check duplicate
//         const checkSupplier = await Supplier.findAll({where:{supplier_email : supplier_email,supplier_phonenumber : supplier_phonenumber }})
        
//         if(checkSupplier.length > 0){
//           const parseShopid = Array.isArray(shop_id) ? shop_id : JSON.parse(shop_id);

//             const supplierExists = checkSupplier.some(supplier => {
//                 const shopIds = supplier.shop_id ? JSON.parse(supplier.shop_id) : [];
//                 return parseShopid.some(id => shopIds.includes(id));
//             });

//             if (supplierExists) {
//                 return res.status(400).json({ message: "This supplier already exists in this shop" });
//             }
//         }
      
    
       
          
//           if(shop_id.length == 0){
//               return res.status(400).json({message:"shop_id must be an array"});
//           }
//           const stringifyShopids =  JSON.stringify(shop_id)
          
//       try{
//           await Supplier.create({
//           supplier_name,
//           supplier_email,
//           supplier_phonenumber,
//           country,
//           state,
//           created_by: req.user.user_name,
//           date : date_recorded,
//           shop_id: stringifyShopids
//       })
      
//       return res.status(200).json({message:"Supplier created"});
//       }catch(error){
//           return res.status(400).json(error)
//       }
     
// }

// //update
// exports.Updatesupplier = async (req, res, next)=>{
//         const {supplier_id, supplier_name, shop_id, supplier_email, supplier_phonenumber, country, state} = req.body
        
//         if(!supplier_id && !supplier_name && !supplier_email && !supplier_phonenumber && !country && !state){
            
//             return res.status(400).json({message:"All fields are required"})
            
//         }
//         const stringifyShopids =  JSON.stringify(shop_id)
//          try{
//           await Supplier.update({
//           supplier_name,
//           supplier_email,
//           supplier_phonenumber,
//           country,
//           state,
//           shop_id : stringifyShopids 
//       },{where:{id : supplier_id}})
      
//       return res.status(200).json({message:"Supplier updated"});
//       }catch(error){
//           return res.status(400).json(error)
//       }
// }


// //disable supplier 
// exports.Disablesupplier = async (req, res, next)=>{
//      const {supplier_id, shop_id} = req.body
     
  
//      //check duplicate
//       const checkDuplicate = await disabled_users_products_and_suppliers.findOne({where:{shop_id: shop_id,
//          type : "supplier",
//          type_id :supplier_id}})
         
//     if(checkDuplicate){
//         return res.status(200).json({message:"Supplier deleted"})
//     }
//      try{
//          await disabled_users_products_and_suppliers.create({
//          shop_id,
//          type : "supplier",
//          type_id : supplier_id
//      })
     
//      return res.status(200).json({message:"Supplier deleted"})
//      }catch(error){
//           return res.status(400).json(error)
//       }
      
      
    
   
     
// }

// //get all suppliers 
// exports.Getallsuppliers = async (req, res, next)=>{ 
       
//       const  shopId = Number(req.query.shop_id)
      
//       if(!shopId){
//         return res.status(400).json({message:"All fields are required"});
//     }
    
//       try{
//          const allSuppliers = await Supplier.findAll()
    
//     const filteredSupplier = await Promise.all(
//       allSuppliers.map(async (user) => {
//         const shopIds = JSON.parse(user.shop_id);

//         // Check if user is disabled for this shop (asynchronously)
//         const isDisabled = await disabled_users_products_and_suppliers.findOne({
//           where: {
//             type: "supplier",
//             type_id: user.id,
//             shop_id: shopId,
//           },
//         });

//         return shopIds.includes(shopId) && !isDisabled ? user : null;
//       })
//     );

//     // Filter out null values after Promise.all resolves
   
//     const filteredSuppliersarray = filteredSupplier.filter(Boolean)
    
    
     
//     let Supplierarray = []
    
//     for(const value of filteredSuppliersarray){
        
//              //filter shop ids that the supplier has been deleted from
            
         
//             const parseShopid = JSON.parse(value.shop_id)
          
                      
   

   
    
//                 const checkDeletestatus =  await disabled_users_products_and_suppliers.findOne({where: { type: "supplier", type_id: value.id ,shop_id: { [Op.in]:parseShopid} }})
              
//              const filteredShopIds = checkDeletestatus?.shop_id
//     ? parseShopid.filter((id) => id !== checkDeletestatus.shop_id)
//     : parseShopid;
          
//           const supplierassignedShops = await Shop.findAll({
//   where: { id: { [Op.in]:filteredShopIds} }
// });
        

             
//              const supplierResult = {
//                  supplier_id : value.id,
//                  supplier_name : value.supplier_name,
//                  supplier_email : value.supplier_email,
//                  supplier_phonenumber	: value.supplier_phonenumber,
//                  country : value.country,
//                  state : value.state,
//                  created_by : value.created_by,
//                  assigned_shops : supplierassignedShops
//              }
//              Supplierarray.push(supplierResult)
         
//     }
   
//      return res.status(200).json(Supplierarray)
//       }catch(error){
//           return res.status(400).json(error)
//       }
       
// }


