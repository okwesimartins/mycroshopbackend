// const db = require("../models");
// const Users = db.users;
// const otpemail = require("../service/mail-services.js");
// const Products = db.products;
// const Op = db.Sequelize.Op;
// const  Sequelize=require('sequelize')
// const fs = require('fs');
// const Category = db.categories
// const Supplier = db.suppliers
// const disabled_users_products_and_suppliers = db.disabled_users_products_and_suppliers
// const stock_movement = db.stock_movement
// const stock_summary = db.stock_summary
// const Purchase =  db.purchase
// const Shop = db.shop

// const pagination = async (items, page) => {

//   var page = page || 1,
//   per_page = 10,
//   offset = (page - 1) * per_page,
//   paginatedItems = items.slice(offset).slice(0, per_page),
//   total_pages = Math.ceil(items.length / per_page);
  
//   return {
//   page: page,
//   per_page: per_page,
//   pre_page: page - 1 ? page - 1 : null,
//   next_page: (total_pages > page) ? page + 1 : null,
//   total: items.length,
//   total_pages: total_pages,
//   data: paginatedItems
//   };
  
// }

// //create category
// exports.createCategory = async (req, res, next)=>{
//       const {category_name} = req.body
       
//         let date_ob = new Date();
//                 let date = ("0" + date_ob.getDate()).slice(-2);
//                 let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
//                 let year = date_ob.getFullYear();
//                 const date_recorded = year + "-" + month + "-" + date;
                
//                 //check duplicate
                
//                 const checkcatDuplicate = await Category.findOne({where:{ category_name: category_name}})
                     
//                      if(checkcatDuplicate){
//                          return res.status(400).json({message: "duplicate entry"});
//                      }
                     
//       try{
//           await Category.create({
//               category_name,
//               date: date_recorded,
//               created_by : req.user.user_name
               
//           })
           
//           return res.status(200).json({message: "category created"});
//       }catch(error){
//             return res.status(400).json(error);
//       }
// }

// //edit category

// exports.editCategory = async (req, res, next)=>{
//       res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
//                   res.setHeader('Pragma', 'no-cache');
//                   res.setHeader('Expires', '0')
                  
//       const {cat_id, category_name} = req.body
    
//                 let date_ob = new Date();
//                 let date = ("0" + date_ob.getDate()).slice(-2);
//                 let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
//                 let year = date_ob.getFullYear();
//                 const date_recorded = year + "-" + month + "-" + date;
    
     
//      try{
//           await Category.update({
//               category_name:category_name,
//                 date: date_recorded,
//               created_by : req.user.user_name
//           },{where:{id : cat_id}})
           
//           return res.status(200).json({message: "category updated"});
//       }catch(error){
//             return res.status(400).json(error);
//       }
       
// }

// //delete category
// exports.deleteCategory = async (req, res, next)=>{
//     const cat_id = req.query.cat_id
    
//     try{
//         await Category.destroy({where:{id : cat_id}})
        
//           return res.status(200).json({message: "category deleted"})
//     }catch(error){
//             return res.status(400).json(error);
//       }
// }

// //get all categories 
// exports.getAllcats = async(req, res, next)=>{
//      try{
//      const allCategories =  await Category.findAll()
        
//           return res.status(200).json({message: allCategories})
//     }catch(error){
//             return res.status(400).json(error);
//       }
    
// }


// //create product 
// exports.createProducts = async (req, res, next)=> {
//       const {product_name,color,unit, total_selling_price,  product_category, product_description,inches, total_product_stock,total_stock_value, shop_id, supplier_id, total_buying_price} = req.body
        
         
//          if(product_name  && unit   && product_category  && total_product_stock && total_stock_value && shop_id && supplier_id  ){
             
         
//          const created_by = req.user.user_name
         
//          let fileRecords = []
//           if(req.files && req.files['images']){
               
//               const files = req.files?.['images'];
//               fileRecords = files.map(file => ({
//   filename: file.filename
// })); 

// }
//                      const productNumber = "LHNG" + Math.floor(100000 + Math.random() * 9000)
//                      //date
                     
//                      if(inches){
//                              if (inches.length == 0) {
//                          return res.status(400).json({message: "inches must be an array format"})
//                      }
                     
//                      }
//                         if(!inches && !total_buying_price && !total_selling_price){
//                          return res.status(400).json({message: "selling price and buying price are required"})
//                      }
                  
//                      let sellingPrice = total_selling_price
//                      let buyingPrice = total_buying_price
//                      let totalStockValue = total_stock_value
//                      let date_ob = new Date();
//                 let date = ("0" + date_ob.getDate()).slice(-2);
//                 let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
//                 let year = date_ob.getFullYear();
//                 const date_recorded = year + "-" + month + "-" + date;
                
//                 const stringify_filerecords = JSON.stringify(fileRecords)
                
//                 const convertjson = JSON.parse(inches)
//                 const stringify_inches = JSON.stringify(convertjson)
                
               
                
//                 if(!convertjson.length){
//                     //validate total stock value
//                 const calculateStockvalue = Number(total_product_stock) * Number(buyingPrice)
                
//                 if(calculateStockvalue != Number(total_stock_value)){
//                     return res.status(400).json({message:"fraud detected. Stock value not correct"})
//                 }
//                 }
                
                
                
//                 //validate inches array 
//                 if(convertjson.length > 0){
                    
//                     requiredKeys = ['inche', 'buying_price', 'stock', 'selling_price','color'];
                    
//                     let total_stock = 0
//                   for(const value of convertjson){
                           
//                           total_stock+= Number(value.stock)
                    
//                 } 
                
//                 if(total_stock != Number(total_product_stock)){
//                     return res.status(400).json({message: "total stock must be equivalent to the toal stock of all the inches put together"})
//                 }
                
//                 const errormessage = [];

//   for (let i = 0; i < convertjson.length; i++) {
//     const product = convertjson[i];
//     for (const key of requiredKeys) {
//       if (!product.hasOwnProperty(key)) {
//          errormessage.push({message: `missing key ${key}`});
//       }
//     }
//   }
//       if(errormessage.length != 0){
//           return res.status(400).json({message:errormessage})
//       }
       
//       //store inches selling price for each inches
//                  sellingPrice = convertjson.map(p => `${p.inche}\" = ${p.selling_price}`).join(", ");
//                  //store inches selling price
//                  buyingPrice = convertjson.map(p => `${p.inche}\" = ${p.buying_price}`).join(", ");
                 
//                  totalStockValue = convertjson.reduce((total, p) => total + (parseInt(p.buying_price) * parseInt(p.stock)), 0)
                 
//                   if(totalStockValue != Number(total_stock_value)){
//                       return res.status(400).json({message:"fraud detected. Stock value not correct"})
//                  }
//                 }
                
//         //check duplicate
//         const checkProductduplicate = await  Products.findOne({where:{product_name:product_name,product_category:product_category,color:color}})
        
//         if(checkProductduplicate){
//               return res.status(400).json({message:"Duplicate product"})
//         }
                
//               let createdProduct
                
//                  try{
//                       createdProduct =   await  Products.create({
//                              product_name,
//                              product_category,
//                              color,
//                              unit,
//                              total_selling_price: sellingPrice,
//                              total_buying_price : buyingPrice,
//                              product_description,
//                              total_product_stock,
//                              total_stock_value : totalStockValue,
//                              shop_id: shop_id,
//                              supplier_id,
//                              created_by,
//                              date : date_recorded,
//                              inches: stringify_inches,
//                              image: stringify_filerecords
//                          })
                         
                        
//                      }catch(error){
//                         return res.status(400).json(error)
//                      }
                     
//                       if(convertjson.length > 0){
//                           for(const value of convertjson){
//                               let display_stock = "+" + value.stock
//                               const parseShopid = JSON.parse(shop_id)
//                               for(const data of parseShopid){
//                                      await  Purchase.create({
//                         product_id : createdProduct.id,
//                         product_quantity : value.stock,
//                         supplier : supplier_id,
//                         inches : value.inche,
//                         created_by : created_by,
//                         date : date_recorded,
//                         shop_id : data
//                     })
                    
//                     await stock_movement.create({
//                         product_id :  createdProduct.id,
//                         inch : value.inche,
//                         movement_type :"purchase",
//                         movement_reason	: "New product uploaded",
//                         quantity :  display_stock,
//                         balance :  value.stock,
//                         movement_date : date_recorded,
//                         shop_id : data
//                     })
                    
//                     await stock_summary.create({
//                         	product_id: createdProduct.id,
//                         	inch : value.inche,
//                         	opening_stock : 0,
//                         	month : month,
//                         	year : year,
//                         	shop_id : data
//                     })
//                               }
                               
//                           }
//                       }
                     
//                      if(convertjson.length == 0){
//                          let display_stock = "+" + total_product_stock;
//                          const parseShopid = JSON.parse(shop_id)
//                               for(const data of parseShopid){
//                                      await  Purchase.create({
//                         product_id : createdProduct.id,
//                         product_quantity : total_product_stock ,
//                         supplier : supplier_id,
//                         created_by : created_by,
//                         shop_id : shop_id,
//                         date : date_recorded,
//                         shop_id : data
//                     })
                    
                    
//                     await stock_movement.create({
//                         product_id :  createdProduct.id,
//                         movement_type :"purchase",
//                         movement_reason	: "New product uploaded",
//                         quantity :  display_stock,
//                         balance :  total_product_stock,
//                         movement_date : date_recorded,
//                         shop_id : data
//                     })
                    
//                     await stock_summary.create({
//                         	product_id: createdProduct.id,
//                         	opening_stock : 0,
//                         	purchase : 1,
//                         	month : month,
//                         	year : year,
//                         	shop_id : data
//                     })
//                               }
                          
//                      }
                  
               
               
                    
                    
            
              
//              return res.status(200).json({message: "product created"})
           
         


//       }
       
//       return res.status(400).json({message: "All fields are required"})
       
// }




// //update product
// exports.updateProducts = async (req, res, next)=> {

//     const {product_id, product_name, color, unit, total_selling_price,  product_category, product_description, inches, total_product_stock,total_stock_value, shop_id, supplier_id, total_buying_price } = req.body
        
         
//          if(product_name && product_id && unit  && product_category && product_description && inches && total_product_stock && total_stock_value && shop_id && supplier_id ){
             
        
//           try{
//          const created_by = req.user.user_name
           
            
//          let fileRecords = []
//           if(req.files && req.files['images']){
               
//               const files = req.files?.['images'];
//                 fileRecords = files.map(file => ({
//   filename: file.filename
// })); 

// }   
//                      //validate product id
//                      const getproductDetails = await Products.findOne({where:{id:  product_id}})
                     
//                   if(!getproductDetails){
//                          return res.status(400).json({message: "invalid product id passed"})
//                      }
//                       const getpreviouseProductinchesdata = JSON.parse(getproductDetails.inches)
                      
                     
//                      const productNumber = "LHNG" + Math.floor(100000 + Math.random() * 9000)
//                      //date
                     
//                      if(inches){
//                              if (inches.length == 0) {
//                          return res.status(400).json({message: "inches must be an array format"})
//                      }
                     
//                      }
//                      if(!inches && !total_buying_price && !total_selling_price){
//                          return res.status(400).json({message: "selling price and buying price are required"})
//                      }
                  
//                       let sellingPrice = total_selling_price
//                      let buyingPrice = total_buying_price
//                      let totalStockValue = total_stock_value
//                      let date_ob = new Date();
//                 let date = ("0" + date_ob.getDate()).slice(-2);
//                 let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
//                 let year = date_ob.getFullYear();
//                 const date_recorded = year + "-" + month + "-" + date;
                
//                 const stringify_filerecords = JSON.stringify(fileRecords)
                
//                 const convertjson = JSON.parse(inches)
//                 const stringify_inches = JSON.stringify(convertjson)
                
//                 const stringify_shopIds = JSON.stringify(shop_id)
                
//                 if(!convertjson.length){
//                     //validate total stock value
//                 const calculateStockvalue = Number(total_product_stock) * Number(buyingPrice)
                
//                 if(calculateStockvalue != Number(total_stock_value)){
//                     return res.status(400).json({message:"fraud detected. Stock value not correct"})
//                 }
//                 //stock record
//                  const parseShopid = JSON.parse(shop_id)
//                  for(const shop of parseShopid){
//                      if(Number(getproductDetails.total_product_stock) != Number(total_product_stock)){
//                           let difference = Number(total_product_stock) - Number(getproductDetails.total_product_stock)
                        
//                          if(difference > 0){
//                                     difference = "+" + difference
//                                 }
                                
//                          const lastMovement = await stock_movement.findOne({where:{product_id:product_id,inch: null, shop_id:shop},  order: [['movement_date', 'DESC']]})
                         
//                          const lastBalance = lastMovement ? lastMovement.balance : getproductDetails.total_product_stock
                         
//                          const newBalance = Number(lastBalance) + Number(difference)
//                         await stock_movement.create({
//                         product_id :  product_id,
//                         movement_type :"adjustment",
//                         movement_reason	: "",
//                         quantity :  difference,
//                         balance :  newBalance,
//                         movement_date : date_recorded,
//                         shop_id : shop
//                     })
//                      }
                     
                    
                    
//                  }
               
//                 }
               
              
//                 let test56 = []
                
//                 //validate inches array
//                 if(convertjson.length > 0){
                    
//                     requiredKeys = ['inche', 'buying_price', 'stock', 'selling_price','color'];
                    
//                     let total_stock = 0
//                   for(const value of convertjson){
                           
//                           total_stock+= Number(value.stock)
                    
//                 } 
                
//                 if(total_stock != Number(total_product_stock)){
//                     return res.status(400).json({message: "total stock must be equivalent to the toal stock of all the inches put together"})
//                 }
                
//                 const errormessage = [];

//   for (let i = 0; i < convertjson.length; i++) {
//     const product = convertjson[i];
//     for (const key of requiredKeys) {
//       if (!product.hasOwnProperty(key)) {
//         errormessage.push({message: `missing key ${key}`});
//       }
//     }
//   }
//       if(errormessage.length != 0){
//           return res.status(400).json({message:errormessage})
//       }
                
//                       //store inches selling price for each inches
//                  sellingPrice = convertjson.map(p => `${p.inche}\" = ${p.selling_price}`).join(", ");
//                  //store inches selling price
//                  buyingPrice = convertjson.map(p => `${p.inche}\" = ${p.buying_price}`).join(", ");
                 
//                 totalStockValue = convertjson.reduce((total, p) => total + (parseInt(p.buying_price) * parseInt(p.stock)), 0)
                 
//                  if(totalStockValue != Number(total_stock_value)){
//                       return res.status(400).json({message:"fraud detected. Stock value not correct"})
//                  }
                 
                
//                  const parseShopid = JSON.parse(shop_id)
//                   for(const convertedvalue of convertjson){
//                       for(const inchdata of  getpreviouseProductinchesdata){
//                      if(Number(inchdata.inche) == Number(convertedvalue.inche)){
//                         if(Number(inchdata.stock) != Number(convertedvalue.stock)){
                            
                         
                        
//                          for(const shop of parseShopid){
                          
                             
//                               let difference = Number(convertedvalue.stock) - Number(inchdata.stock) 
                              
//                                 if(difference > 0){
//                                     difference = "+" + difference
//                                 }
                        
//                          const lastMovement = await stock_movement.findOne({where:{product_id:product_id,inch:convertedvalue.inche, shop_id: shop},  order: [['movement_date', 'DESC']]})
                         
//                          const lastBalance = lastMovement ? lastMovement.balance : inchdata.stock
                         
//                          const newBalance = Number(lastBalance) + Number(difference)
                         
//                               await stock_movement.create({
//                         product_id :  product_id,
//                         movement_type :"adjustment",
//                         movement_reason	: "",
//                         quantity :  difference,
//                         balance :  newBalance,
//                         inch: convertedvalue.inche,
//                         movement_date : date_recorded,
//                         shop_id : shop
//                     })
//                          }
                       
                    
                
//                         }
                       
//                      }
//                  }
//                 }
                
                
                 
//                 }
                
//             //   return res.status(200).json(test56)
                
               
//                          await  Products.update({
//                              product_name,
//                              product_category,
//                              color,
//                              unit,
//                              total_selling_price: sellingPrice,
//                              total_buying_price : buyingPrice,
//                              product_description,
//                              total_product_stock,
//                              total_stock_value: totalStockValue,
//                              shop_id: shop_id,
//                              supplier_id,
//                              created_by,
//                              date : date_recorded,
//                              inches: stringify_inches,
//                              image: stringify_filerecords
//                          },{where:{id: product_id}})
                         
//                          return res.status(200).json({message: "product updated"})
//                      }catch(error){
//                         return res.status(400).json({message: error.message})
//                      }
                     
                      
           
              
                     
//       }
       
//       return res.status(400).json({message: "All fields are required"})
    
// }
// const formatPrice = async (data) => {
//     // Function to format a price value
//     const formatValue = (price) => `₦${parseInt(price).toLocaleString()}`;

//     if (data.includes('"')) { // Check if inches exist
//         return data.replace(/(\d+)"\s*=\s*(\d+)/g, (_, inch, price) => {
//             return `${inch}" = ${formatValue(price)}`;
//         });
//     } else {  
//         return formatValue(data); // Format as regular price
//     }
// }
// //search product 
// const searchProduct = async (search_value, shopId ,page, pagenumber)=>{
      
 
      
//       const products = await Products.findAll({
//       where: {
//         [Op.or]: [
//           { product_name: { [Op.like]: `%${search_value}%` } },
//           { product_category: { [Op.like]: `%${search_value}%` } } 
//         ]
//       }
//     });
    
//     const filteredProduct = await Promise.all(
//       products.map(async (product) => {
//         const shopIds = JSON.parse(product.shop_id);

//         // Check if user is disabled for this shop (asynchronously)
//         const isDisabled = await disabled_users_products_and_suppliers.findOne({
//           where: {
//             type: "product",
//             type_id: product.id,
//             shop_id: shopId,
//           },
//         });

//         return shopIds.includes(shopId) && !isDisabled ? product : null;
//       })
//     );

//     // Filter out null values after Promise.all resolves
   
//     const filteredProductarray = filteredProduct.filter(Boolean)
    

//       const productArray= []
//     for(const value of filteredProductarray){
//         const baseUrl = 'https://backend.hairplanetng.com/public/image/';
//         const files= JSON.parse(value.image)
        
//         const filesWithBaseUrl = files.map(file => ({
//           filename: `${baseUrl}${file.filename}`
//              }));
//         const inches = JSON.parse(value.inches)
        
         
           
           
//           const supplierName = await Supplier.findOne({where:{id : value.supplier_id}, attributes:['id','supplier_name']}) 
          
//           const parseShopid = JSON.parse(value.shop_id)
          
                      
//               const checkDeletestatus =  await disabled_users_products_and_suppliers.findOne({where: { type: "product", type_id: value.id ,shop_id: { [Op.in]:parseShopid} }})
              
//              const filteredShopIds = checkDeletestatus?.shop_id
//     ? parseShopid.filter((id) => id !== checkDeletestatus.shop_id)
//     : parseShopid;
          
//           const productassignedShops = await Shop.findAll({
//   where: { id: { [Op.in]:filteredShopIds} }
// });

//  const [totalSellingPrice, totalBuyingPrice, totalStockValue] = await Promise.all([
//         formatPrice(value.total_selling_price),
//         formatPrice(value.total_buying_price),
//         formatPrice(value.total_stock_value),
//     ]);
            
//         const data = {
//             "id": value.id,
//             "product_name": value.product_name,
//             "product_category": value.product_category,
//             "color": value.color,
//             "unit": value.unit,
//             "supplier_name": supplierName,
//             "total_buying_price": totalBuyingPrice,
//             "total_selling_price":totalSellingPrice,
//             "total_stock_value":totalStockValue,
//             "images":filesWithBaseUrl,
//             "product_description": value.product_description,
//             "inches":inches,
//             "assigned_shops": productassignedShops
            
//         }
        
//         productArray.push(data)
//     }
//     if(pagenumber === "All"){
//          return  productArray
//     }
//     const paginatedData = await pagination(productArray, page);
//       return paginatedData
  
// }





// // admin delete product
// exports.deleteProduct = async (req, res, next)=>{
//       res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
//                   res.setHeader('Pragma', 'no-cache');
//                   res.setHeader('Expires', '0')
//      const {shop_id, product_id} = req.body
     
//      const getProducts = await Products.findOne({where:{id:product_id}})
     
//      if(!getProducts){
//          return res.status(400).json({message: "invalid product id"})
//      }
//      const checkDuplicate =  await disabled_users_products_and_suppliers.findOne({where:{type : "product", type_id :product_id, shop_id : shop_id }})
    
//     if(checkDuplicate){
//           return res.status(200).json({message: "product deleted"})
//     }
//          try{
//           await disabled_users_products_and_suppliers.create({
//               type : "product",
//               type_id : product_id,
//               shop_id
//           })
        
//         return res.status(200).json({message: "product deleted"})
//     }catch(error){
//         return res.status(400).json(error)
//     }
    
    
     
    
   
    
// }


// // //admin get all products
// exports.getAllproducts = async(req, res, next)=>{
//       res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
//                   res.setHeader('Pragma', 'no-cache');
//                   res.setHeader('Expires', '0')
//      let page = 0;
     
//             const pagenumber = req.query.page;
//             const shopId = Number(req.query.shop_id)
           
//             if(!shopId){
//                   return res.status(400).json({message : "shop id required"})
//             }
            
//             if(!Number.isNaN(pagenumber) && pagenumber > 0 ){
//                 page = pagenumber;
//             }
//             let search_response
//             const search_value = req.query.search_value
//             if(search_value){
                
               
//                 try{
//                     search_response = await searchProduct(search_value,shopId, page, pagenumber)
//                 }catch(error){
//                      return res.status(400).json(error)
                    
//                 }
                
//                  return res.status(200).json(search_response)
//             }
//     const products = await Products.findAll({order: [["id", "DESC"]]})
    
    
//     const filteredProduct = await Promise.all(
//       products.map(async (product) => {
//         const shopIds = JSON.parse(product.shop_id);

//         // Check if user is disabled for this shop (asynchronously)
//         const isDisabled = await disabled_users_products_and_suppliers.findOne({
//           where: {
//             type: "product",
//             type_id: product.id,
//             shop_id: shopId,
//           },
//         });

//         return shopIds.includes(shopId) && !isDisabled ? product : null;
//       })
//     );

//     // Filter out null values after Promise.all resolves
   
//     const filteredProductarray = filteredProduct.filter(Boolean)
    
 
//       const productArray= []
//     for(const value of filteredProductarray){
//         const baseUrl = 'https://backend.hairplanetng.com/public/image/';
//         const files= JSON.parse(value.image)
        
//         const filesWithBaseUrl = files.map(file => ({
//           filename: `${baseUrl}${file.filename}`
//              }));
//         const inches = JSON.parse(value.inches)
        
         
           
           
//           const supplierName = await Supplier.findOne({where:{id : value.supplier_id}, attributes:['id','supplier_name']}) 
          
//           const parseShopid = JSON.parse(value.shop_id)
          
                      
   

   
    
//                 const checkDeletestatus =  await disabled_users_products_and_suppliers.findOne({where: { type: "product", type_id: value.id ,shop_id: { [Op.in]:parseShopid} }})
              
//              const filteredShopIds = checkDeletestatus?.shop_id
//     ? parseShopid.filter((id) => id !== checkDeletestatus.shop_id)
//     : parseShopid;
          
//           const productassignedShops = await Shop.findAll({
//   where: { id: { [Op.in]:filteredShopIds} }
// });

//  const [totalSellingPrice, totalBuyingPrice, totalStockValue] = await Promise.all([
//         formatPrice(value.total_selling_price),
//         formatPrice(value.total_buying_price),
//         formatPrice(value.total_stock_value),
//     ]);

  

//         const data = {
//             "id": value.id,
//             "product_name": value.product_name,
//             "product_category": value.product_category,
//             "color": value.color,
//             "unit": value.unit,
//             "total_product_stock": value.total_product_stock,
//             "supplier_name": supplierName,
//             "total_stock_value":totalStockValue,
//             "total_buying_price":  totalBuyingPrice,
//             "total_selling_price": totalSellingPrice,
//             "images":filesWithBaseUrl,
//             "product_description": value.product_description,
//             "inches":inches,
//             "assigned_shops": productassignedShops
            
//         }
        
//         productArray.push(data)
//     }
  
//     if(pagenumber === "All"){
//         return res.status(200).json(productArray)  
//     }

      
//     const paginatedData = await pagination(productArray, page);
//       return res.status(200).json(paginatedData)   
// }










