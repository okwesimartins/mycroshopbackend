// const db = require("../models");
// const Users = db.users;
// const otpemail = require("../service/mail-services.js");
// const Products = db.products;
// const Op = db.Sequelize.Op;
// const  Sequelize=require('sequelize')
// const Shop = db.shop
// const Invoice = db.invoice
// const Discount = db.discount
// const Customers =  db.customers
// const Paymentlist = db.payment_list
// const Aisalesrecord =db.aisalesrecord
// const bcrypt = require("bcryptjs")
// const stock_movement = db.stock_movement

// const Sortorders = db.sortorders

// const pagination = async (items, page) => {

//   var page = page || 1,
//   per_page = 10,
//   offset = (page - 1) * per_page,
//   paginatedItems = items.slice(offset).slice(0, per_page),
//   total_pages = Math.ceil(items.length / per_page);
  
//   return {
//   page: page,
//   per_page: per_page,
//   pre_page: page - 1 ? page - 1 : null,
//   next_page: (total_pages > page) ? page + 1 : null,
//   total: items.length,
//   total_pages: total_pages,
//   data: paginatedItems
//   };
  
// }






// exports.Createinvoice = async (req, res, next)=>{
//     const {invoice_number, payment_method, products_ordered_array, total_amount, customer_id, discount_name, shop_id } =req.body
    
//     if(invoice_number && payment_method && products_ordered_array && total_amount &&  customer_id && shop_id){
        
        
//           if (!Array.isArray(products_ordered_array)) {
            
//               return res.status(400).json({message: "products_ordered_array parameter must be an array"})
//         }
        
        
//         try{
            
        
      
//         //valide customer id passed
//         const getCustomerid = await Customers.findOne({where:{id: customer_id}, attributes:['id','name','email','phone_number']})
//         if(!getCustomerid){
//              return res.status(400).json({message:"Invalid customer id passed passed"})
//         }
//         const created_by = req.user.user_name
        
        
//         let date_ob = new Date();
//                 let date = ("0" + date_ob.getDate()).slice(-2);
//                 let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
//                 let year = date_ob.getFullYear();
//                 const date_recorded = year + "-" + month + "-" + date;
                
                
                
                
                
                
//                 const stringifyProductarray =  JSON.stringify(products_ordered_array)
//                 // const parseProductarray = JSON.parse(products_ordered_array)
                
//                 //validate the products_ordered_array array
//                 if(products_ordered_array.length > 0){
//                      requiredKeys = ['product_id','product_name', 'product_price', 'quantity', 'inches','color']
        
//         let errormessage = [];
//         let validateProductarrayinfo =[]
//          for (let i = 0; i < products_ordered_array.length; i++) {
//     const product = products_ordered_array[i];
//     for (const key of requiredKeys) {
//       if (!product.hasOwnProperty(key)) {
//         errormessage.push({message: `missing key ${key}`});
//         break
//       }
//     }
//   }
//   if(errormessage.length != 0){
//           return res.status(400).json(errormessage)
//       }
      
//   for(const value of products_ordered_array){
//      const validateProducts = await  Products.findOne({where:{id: value.product_id,product_name:value.product_name}})
//      if(!validateProducts){
//         validateProductarrayinfo.push({message :"invalid product info passed"})
         
//          break
//      }
//      if(validateProducts){
//           const Parseinch = JSON.parse(validateProducts.inches)
          
//          if(value.inches){
               
                     
//                          const filteredProducts = Parseinch.filter(item => Number(item.inche) === Number(value.inches));
                         
//                          if(filteredProducts.length == 0){
//                           validateProductarrayinfo.push({message :"invalid inch value  passed"})
                          
//                           break
//                          }
                         
//                          if(filteredProducts.length > 0){
//                              const filterInchestock = Parseinch.filter(product =>   
//                                  Number(product.inche) === Number(value.inches) && parseInt(product.stock) >= Number(value.quantity)
//                              );
                             
//                              if(filterInchestock.length == 0){
                                 
//                                  validateProductarrayinfo.push({message :  `Not enough  available stock for   ${value.product_name}`})
                                 
//                                  break
//                              }
//                          }
//          }
         
//          if(value.inches == 0){
//              if(Number(validateProducts.total_product_stock) != Number(value.quantity) && Number(value.quantity) > Number(validateProducts.total_product_stock)){
//                   validateProductarrayinfo.push({message :  `Not enough  available stock for   ${value.product_name}`})
                                 
//                                  break
//              }
//          }
       
//      }
//  }
//   if(validateProductarrayinfo.length != 0){
//           return res.status(400).json(validateProductarrayinfo)
//       }
//                 }
       
       
//       //validate invoice calculations passed 
                
                
//                 let validateDiscount
//                 let discountedBoolean = 0
//                 let sumProductamount = 0
                  
                
//                 if(discount_name != ""){
//                     validateDiscount = await Discount.findOne({where:{discount_name: discount_name}})
                    
//                     if(!validateDiscount){
//                     return res.status(400).json({message:"Invalid discount value passed"})
//                 }
//                 for(const product of products_ordered_array){
//                      const getProductinfo = await  Products.findOne({where:{id:  product.product_id,product_name: product.product_name}})
//                      let sellPrice
//                      const Parseinch = JSON.parse(getProductinfo.inches)
                     
//                          const filteredProducts = Parseinch.filter(item => Number(item.inche) === Number(product.inches));
                         
//                          if(filteredProducts.length > 0){
//                           sellPrice =  filteredProducts[0].selling_price
//                          }
//                          if(filteredProducts.length == 0){
//                              sellPrice = getProductinfo.total_selling_price
//                          }
//                      sumProductamount += Number(sellPrice) * Number(product.quantity)
//                 }
//                 //apply discount value
//               const percentageDiscountvalue = Number(validateDiscount.discount_value) * sumProductamount
//               sumProductamount = sumProductamount - percentageDiscountvalue
//                 discountedBoolean = 1
                
//                 if(sumProductamount != Number(total_amount)){
//                      return res.status(400).json({message: "Fraud detected"})
//                 }
//                 } 
       
//               //validate invoice data without discount 
             
//               if(discount_name == ""){
                    
//                 for(const product of products_ordered_array){
                    
//                      const getProductinfo = await  Products.findOne({where:{id:  product.product_id,product_name: product.product_name}})
//                      let sellPrice
//                      const Parseinch = JSON.parse(getProductinfo.inches)
                     
//                          const filteredProducts = Parseinch.filter(item => Number(Number(item.inche)) === Number(Number(product.inches)));
                          
//                          if(filteredProducts.length > 0){
//                           sellPrice = filteredProducts[0].selling_price
//                          }
//                          if(filteredProducts.length == 0){
//                              sellPrice = getProductinfo.total_selling_price
//                          }
//                      sumProductamount += Number(sellPrice) * Number(product.quantity)
//                 }
              
              
//                   if(sumProductamount != Number(total_amount)){
//                      return res.status(400).json({message: "Fraud detected"})
//                 }
                
                     
//                 }
                
//       //validate order quantity
       
          
       
//   //check duplicate 
//   const Checkduplicate = await Invoice.findOne({where:{invoice_number:  invoice_number}})
  
//   if(Checkduplicate){
//       return res.status(400).json({message:"Duplicate data entry"})
//   }
  

  
//       try{
//           await Paymentlist.create({
//               customer_id,
//               invoice_number,
//               status : "Pending",
//               shop_id
//           })
//       }catch(error){
//           return res.status(400).json(error)
//       }
      
//       try{
//           await Invoice.create({
//               invoice_number,
//               payment_method,
//               discounted : discountedBoolean,
//               products_ordered_array : stringifyProductarray,
//               created_by,
//               status : "Unpaid",
//               date : date_recorded,
//               shop_id,
//               customer_id,
//               total_amount,
//               discount_name
//           })
           
//           const invoiceCreated = {
//         "invoice_number": invoice_number,
//         "customer_info": getCustomerid,
//         "date": date_recorded,
//         "payment_method":payment_method,
//         "total_amount":  total_amount,
//         "created_by": created_by,
//         "payment_status": "Unpaid",
//         "products_ordered": products_ordered_array,
//         "discount_name":  discount_name
//     }
    
//           return res.status(200).json(invoiceCreated)
//       }catch(error){
//           return res.status(400).json(error)
//       }
      
      
      
//     } catch (error) {

//         return res.status(500).json({ message: error.message });
//     }
        
//     }
    
//      return res.status(400).json({message: "All fields are required"})
    
   
// }

// // //update invoice 
// exports.Updateinvoice = async (req, res, next)=>{
//     const {invoice_number, payment_method, products_ordered_array, total_amount, discount_name } =req.body
    
//     if(invoice_number && products_ordered_array && payment_method  && total_amount){
        
//         // const created_by = req.user.user_name
//         if (!Array.isArray(products_ordered_array)) {
            
//               return res.status(400).json({message: "products_ordered_array parameter must be an array"})
//         }
        
         
        
//           let date_ob = new Date();
//                 let date = ("0" + date_ob.getDate()).slice(-2);
//                 let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
//                 let year = date_ob.getFullYear();
//                 const date_recorded = year + "-" + month + "-" + date;
                
                
//                 const stringifyProductarray =  JSON.stringify(products_ordered_array)
               
                
//                 //validate the products_ordered_array array
//               if(products_ordered_array.length > 0){
//                      requiredKeys = ['product_id','product_name', 'product_price', 'quantity', 'inches']
        
//         let errormessage = [];
//         let validateProductarrayinfo =[]
//          for (let i = 0; i < products_ordered_array.length; i++) {
//     const product = products_ordered_array[i];
//     for (const key of requiredKeys) {
//       if (!product.hasOwnProperty(key)) {
//         errormessage.push({message: `missing key ${key}`});
//         break
//       }
//     }
//   }
//   if(errormessage.length != 0){
//           return res.status(400).json(errormessage)
//       }
      
//   for(const value of products_ordered_array){
//      const validateProducts = await  Products.findOne({where:{id: value.product_id,product_name:value.product_name}})
//      if(!validateProducts){
//         validateProductarrayinfo.push({message :"invalid product info passed"})
         
//          break
//      }
//      if(validateProducts){
         
//          if(value.inches){
//                 const Parseinch = JSON.parse(validateProducts.inches)
                     
//                          const filteredProducts = Parseinch.filter(item => Number(item.inche) === Number(value.inches));
                         
//                          if(filteredProducts.length == 0){
//                           validateProductarrayinfo.push({message :"invalid inch value  passed"})
                          
//                           break
//                          }
//          }
       
//      }
//  }
//   if(validateProductarrayinfo.length != 0){
//           return res.status(400).json(validateProductarrayinfo)
//       }
//                 }
       
//   //validate invoice calculations passed 
                
                
//                 let validateDiscount
//                 let discountedBoolean = 0
//                 let sumProductamount = 0
                  
                
//                 if(discount_name != ""){
//                     validateDiscount = await Discount.findOne({where:{discount_name: discount_name}})
                    
//                     if(!validateDiscount){
//                     return res.status(400).json({message:"Invalid discount value passed"})
//                 }
//                 for(const product of products_ordered_array){
//                      const getProductinfo = await  Products.findOne({where:{id:  product.product_id,product_name: product.product_name}})
//                      let sellPrice
//                      const Parseinch = JSON.parse(getProductinfo.inches)
                     
//                          const filteredProducts = Parseinch.filter(item => Number(item.inche) === Number(product.inches));
                         
//                          if(filteredProducts.length > 0){
//                           sellPrice =  filteredProducts[0].selling_price
//                          }
//                          if(filteredProducts.length == 0){
//                              sellPrice = getProductinfo.total_selling_price
//                          }
//                      sumProductamount += Number(sellPrice) * Number(product.quantity)
//                 }
//                 //apply discount value
//               const percentageDiscountvalue = Number(validateDiscount.discount_value) * sumProductamount
//               sumProductamount = sumProductamount - percentageDiscountvalue
//                 discountedBoolean = 1
                
//                 if(sumProductamount != Number(total_amount)){
//                      return res.status(400).json({message: "Fraud detected"})
//                 }
//                 } 
       
//               //validate invoice data without discount 
             
//               if(discount_name == ""){
                    
//                 for(const product of products_ordered_array){
                    
//                      const getProductinfo = await  Products.findOne({where:{id:  product.product_id,product_name: product.product_name}})
//                      let sellPrice
//                      const Parseinch = JSON.parse(getProductinfo.inches)
                     
//                          const filteredProducts = Parseinch.filter(item => Number(Number(item.inche)) === Number(Number(product.inches)));
                          
//                          if(filteredProducts.length > 0){
//                           sellPrice = filteredProducts[0].selling_price
//                          }
//                          if(filteredProducts.length == 0){
//                              sellPrice = getProductinfo.total_selling_price
//                          }
//                      sumProductamount += Number(sellPrice) * Number(product.quantity)
//                 }
              
              
//                   if(sumProductamount != Number(total_amount)){
//                      return res.status(400).json({message: "Fraud detected"})
//                 }
                
                     
//                 }
  
//       try{
//           await Invoice.update({
//               payment_method,
//               discounted : discountedBoolean,
//               products_ordered_array : stringifyProductarray,
//               date : date_recorded,
//               total_amount,
//               discount_name
//           },{where:{invoice_number:invoice_number}})
           
//           return res.status(200).json({message: "Invoice updated"})
//       }catch(error){
//           return res.status(400).json(error)
//       }
        
//     }
    
//      return res.status(400).json({message: "All fields are required"})
    
   
// }



// //validate invoice pin
// exports.Validateinvoicepin = async (req, res, next)=>{
//     const {invoice_number, pin} = req.body
    
//     //this is to get the default super  admin
//     const getAdminuser = await Users.findOne({where:{id : 1}})
    
//     const unhashpin = bcrypt.compareSync(pin, getAdminuser.	update_invoice_payment_pin);
              
//               if(!unhashpin){
//                   return res.status(400).json({message:"Incorrect pin"})
//               }
            
//             try{
//                 await Invoice.update({validated: 1},{where:{invoice_number: invoice_number}})
                
//                   return res.status(200).json({message:"success"})
//             }catch(error){
//                   return res.status(400).json(error)
//             }
        
       
// }

// //admin cancel update payment status process
// exports.cancelUpdatepaymentstatus = async (req, res, next)=>{
//     const invoice_number = req.body.invoice_number
    
//           try{
//                 await Invoice.update({validated: 0},{where:{invoice_number: invoice_number}})
                
//                   return res.status(200).json({message:"success"})
//             }catch(error){
//                   return res.status(400).json(error)
//             }
// }





// //update invoice payment status
// exports.Updateinvoicepaymentstatus =  async (req, res, next)=>{
//       const {invoice_number, shop_id, status} = req.body
      
//       if(status == "Paid"  && shop_id){
//         const invoiceNumber =   await Invoice.findOne({where:{invoice_number:invoice_number, shop_id:shop_id}})
        
//         if(invoiceNumber.validated == 1){
            
//                   let date_ob = new Date();
//                 let date = ("0" + date_ob.getDate()).slice(-2);
//                 let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
//                 let year = date_ob.getFullYear();
//                 const date_recorded = year + "-" + month + "-" + date;
                   
//                   let paymentListstatus = status
                   
                  
//                   try{
//                         await Paymentlist.update({
//                             status : paymentListstatus,
//                             validated: 0
//                         },{where:{invoice_number:invoice_number}})
//                   }catch(error){
//                       return res.status(400).json(error)
//                   }
                  
                 
                    
                 
                  
//                   try{
                     
                       
                       
                       
//                         const Productordered = JSON.parse(invoiceNumber.products_ordered_array)
                        
//                         for(const value of Productordered){
//                             const productQuantitytodeduct = Number(value.quantity)
                            
//                              const getProductdetail = await Products.findOne({where:{id: value.product_id}})
                             
//                               await Aisalesrecord.create({
//                          invoice_number: invoice_number,
//                          product_name : value.product_name,
//                          inch : value.inches,
//                          quantity_sold : productQuantitytodeduct,
//                          date : invoiceNumber.date
//                      })
                             
//                             if(value.inches != ""){
//                                 const getProductinches = JSON.parse(getProductdetail.inches)
                                
//                                 if(getProductinches.length > 0){
                                    
                                
//                                 let  buyingPrice
//                                 let totalStock
//                                     const updatedProducts = await Promise.all(getProductinches.map(async product => {
//         if (Number(product.inche) === Number(value.inches)) {
            
//           let difference ="-" + productQuantitytodeduct
           
//           const lastMovement = await stock_movement.findOne({where:{product_id:value.product_id,inch:product.inche, shop_id: shop_id},  order: [['movement_date', 'DESC']]})
                         
//                          const lastBalance = lastMovement ? lastMovement.balance : product.stock
                         
//                          const newBalance = Number(lastBalance) + Number(difference)
                         
//                               await stock_movement.create({
//                         product_id :  value.product_id,
//                         movement_type :"sales",
//                         movement_reason	: "",
//                         quantity :  difference,
//                         balance :  newBalance,
//                         inch: value.inches,
//                         movement_date : date_recorded,
//                         shop_id : shop_id
//                     })
                    
//             if(Number(product.stock) < productQuantitytodeduct){
//                 product.stock = 0
//             }
            
//             if(Number(product.stock) > productQuantitytodeduct || Number(product.stock) == productQuantitytodeduct){
                
 
//  product.stock = Number(product.stock) - productQuantitytodeduct // deduct stock
//             }
             
                              
                         
            
           
//         }
//          totalStock += parseInt(product.stock)
        

//         return product;
//     }));
//     const updatedInchesJSON = JSON.stringify(updatedProducts)
                               
                         
                 
//               let  totalStockValue = updatedProducts.reduce((total, p) => total + (parseInt(p.buying_price) * parseInt(p.stock)), 0)
                            
                            
//                                 await Products.update({inches: updatedInchesJSON,total_product_stock: totalStock,total_stock_value:totalStockValue},{where:{id: value.product_id}})
                           
//                           //stock movement
                         
                              
//                                 }    
//                             }
//                             if(value.inches == ""){
//                                  const getProductinches = JSON.parse(getProductdetail.inches)
                                
//                                 if(getProductinches.length == 0){
//                                     let getTotalproductstock = 0
                                    
//                                     if(Number(getProductdetail.total_product_stock) > productQuantitytodeduct || Number(getProductdetail.total_product_stock) == productQuantitytodeduct){
//                                         getTotalproductstock = Number(getProductdetail.total_product_stock) - productQuantitytodeduct
//                                     }
                               
                               
//                                 const newStockvalue = Number(getProductdetail.buying_price) * getTotalproductstock
                                
//                               await Products.update({total_product_stock: getTotalproductstock,total_stock_value:newStockvalue },{where:{id: value.product_id}})
                               
                               
//                                 let difference ="-" + productQuantitytodeduct 
                        
                        
                                
//                          const lastMovement = await stock_movement.findOne({where:{product_id:value.product_id,inch: null, shop_id:shop_id},  order: [['movement_date', 'DESC']]})
                         
//                          const lastBalance = lastMovement ? lastMovement.balance : getProductdetail.total_product_stock
                         
                         
//                          const newBalance = Number(lastBalance) + Number(difference)
                         
//                         await stock_movement.create({
//                         product_id :  value.product_id,
//                         movement_type :"sales",
//                         movement_reason	: "",
//                         quantity :  difference,
//                         balance :  newBalance,
//                         movement_date : date_recorded,
//                         shop_id : shop_id
//                     })
//                             }
//                             }
//                         }
                        
//                          await Invoice.update({
//                           status : status,
//                           validated: 0
//                       },{where:{invoice_number:invoice_number}})
                      
                
                
//                      await Sortorders.create({
//                          invoice_number,
//                          payment_status : "Paid",
//                          sorted_status : "Not Sorted",
//                          shop_id,
//                          date: date_recorded
//                      })
                
//                         return res.status(200).json({message: "Invoice updated"})
//                   }catch(error){
//                       return res.status(400).json({message: error.message})
//                   }
//         }
        
//         return res.status(400).json({message: "Fraud detected"})
        
        
//       }
// }


// //search invoice
// const searchInvoicetable = async (shop_id, search_value, page,  inches)=>{
//     //      const Invoicedata = await Invoice.findAll({
//     //   where: {
//     //     [Op.or]: [
//     //       { date: search_value },
//     //       { invoice_number : search_value },
//     //       { status: search_value},
//     //       { payment_method: search_value },
//     //       { shop_id: shop_id } 
//     //     ]
//     //   }
//     // })
//     const allinvoices = await Invoice.findAll({order: [['id', 'DESC']]});

// const Invoicedata = allinvoices.filter(invoice => {
//   const products = JSON.parse(invoice.products_ordered_array);
//   return products.some(product => 
//     product.product_id === search_value && product.inches == inches
//   );
// });
    
       
//          //sum total unpaid invoice value
//          const sumUnpaidinvoice= await Invoice.findOne({
//                      where: {status: "Unpaid", shop_id: shop_id},
//                       attributes: [
//                       [Sequelize.fn('sum', Sequelize.col('total_amount')), 'total'],
//                       [Sequelize.fn('count', Sequelize.col('total_amount')), 'count'],
//                       ],
//                       raw: true,
//                         });
                        
//         //sum total invoice value
//         const sumTotalinvoicevalue =  await Invoice.findOne({where:{shop_id:          shop_id},
//                       attributes: [
//                       [Sequelize.fn('sum', Sequelize.col('total_amount')), 'total'],
//                       [Sequelize.fn('count', Sequelize.col('total_amount')), 'count'],
                       
//                       ],
//                       raw: true,
//                         });
           
//         //sum totalPaidinvoice value
//           const sumPaidinvoice= await Invoice.findOne({
//                      where: {status: "Paid",shop_id: shop_id},
//                       attributes: [
//                       [Sequelize.fn('sum', Sequelize.col('total_amount')), 'total'],
//                       [Sequelize.fn('count', Sequelize.col('total_amount')), 'count'],
//                       ],
//                       raw: true,
//                         });
//               //sum total cancel invoce
//          const sumCancelinvoice= await Invoice.findOne({
//                      where: {status: "Cancel", shop_id: shop_id},
//                       attributes: [
//                       [Sequelize.fn('sum', Sequelize.col('total_amount')), 'total'],
//                       [Sequelize.fn('count', Sequelize.col('total_amount')), 'count'],
//                       ],
//                       raw: true,
//                         });
                     
//         const Totalcancelinvoice =  {
//             total_cancel_value : Number(sumCancelinvoice.total),
//             total_cancel_count : Number(sumCancelinvoice.count) 
//             }  
            
//         const Totalunpaidinvoice =  {
//             total_unpaid_value : Number(sumUnpaidinvoice.total),
//             total_unpaid_count : Number(sumUnpaidinvoice.count) 
//             }   
            
//         const Totalpaidinvoice = {
//               total_paid_value : Number(sumPaidinvoice.total),
//               total_paid_count : Number(sumPaidinvoice.count) 
//         }
        
//         const Totalinvoice = {
//               total_invoice_value : Number(sumTotalinvoicevalue.total),
//               total_invoice_count : Number(sumTotalinvoicevalue.count) 
//         }
        
        
//          let invoicearrayData = []
         
         
         
         
//          for(const value of Invoicedata){
//              const getCustomerdata = await Customers.findOne({where:{id: value.customer_id}, attributes:['id','name','email','phone_number']})
//              const parseOrderedproduct = JSON.parse(value.products_ordered_array	)
            
//              const invoiceData = {
//                  "invoice_number": value.invoice_number,
//                  "customer_info": getCustomerdata,
//                  "date": value.date,
//                  "payment_method": value.payment_method,
//                  "total_amount": value.total_amount,
//                  "created_by": value.created_by,
//                  "payment_status": value.status,
//                  "products_ordered": parseOrderedproduct,
//                  "discount_name" : value.discount_name
//              }
//              invoicearrayData.push(invoiceData)
//          }
         
//          if(page == "All"){
//              return invoicearrayData
//          }
//          const paginatedData = await pagination(invoicearrayData, page)
         
//          const finalResult = {totalinvoice:Totalinvoice,totalpaidinvoice: Totalpaidinvoice,totalcancelinvoice :Totalcancelinvoice, totalunpaidinvoice : Totalunpaidinvoice, data:paginatedData}
         
//          return finalResult
// }


// //get all invoice
// exports.getallInvoice = async (req, res, next)=>{
//          const shop_id = req.query.shop_id
//          const search_value = req.query.search_value
//             const inches = req.query.inches
//             let page = 0;
//             const pagenumber = req.query.page;
            
//             if(pagenumber == 0 || pagenumber > 0){
              
//             if(!Number.isNaN(pagenumber) && pagenumber > 0 ){
//                 page = pagenumber;
//             }
            
//             }
            
            
//          if(!shop_id){
//               return res.status(400).json({message: "shop_id required"})
//          }
         
//          if(search_value){
          
             
//               try{
//                   const  search_response = await searchInvoicetable(shop_id,search_value, page, inches )
                    
//                     return res.status(200).json(search_response)
//                 }catch(error){
//                      return res.status(400).json(error)
                    
//                 }
                
                 
//          }
         
//          const getAllinvoice = await Invoice.findAll({where:{shop_id: shop_id}, order: [["date_time", "DESC"]],})
         
            
            
         
//          //sum total unpaid invoice value
//          const sumUnpaidinvoice= await Invoice.findOne({
//                      where: {status: "Unpaid", shop_id: shop_id},
//                       attributes: [
//                       [Sequelize.fn('sum', Sequelize.col('total_amount')), 'total'],
//                       [Sequelize.fn('count', Sequelize.col('total_amount')), 'count'],
//                       ],
//                       raw: true,
//                         });
                        
//         //sum total invoice value
//         const sumTotalinvoicevalue =  await Invoice.findOne({where:{shop_id:          shop_id},
//                       attributes: [
//                       [Sequelize.fn('sum', Sequelize.col('total_amount')), 'total'],
//                       [Sequelize.fn('count', Sequelize.col('total_amount')), 'count'],
                       
//                       ],
//                       raw: true,
//                         });
           
//         //sum totalPaidinvoice value
//           const sumPaidinvoice= await Invoice.findOne({
//                      where: {status: "Paid",shop_id: shop_id},
//                       attributes: [
//                       [Sequelize.fn('sum', Sequelize.col('total_amount')), 'total'],
//                       [Sequelize.fn('count', Sequelize.col('total_amount')), 'count'],
//                       ],
//                       raw: true,
//                         });
//         //sum total cancel invoce
//          const sumCancelinvoice= await Invoice.findOne({
//                      where: {status: "Cancel", shop_id: shop_id},
//                       attributes: [
//                       [Sequelize.fn('sum', Sequelize.col('total_amount')), 'total'],
//                       [Sequelize.fn('count', Sequelize.col('total_amount')), 'count'],
//                       ],
//                       raw: true,
//                         });
                     
//         const Totalcancelinvoice =  {
//             total_cancel_value : Number(sumCancelinvoice.total),
//             total_cancel_count : Number(sumCancelinvoice.count) 
//             }  
            
//         const Totalunpaidinvoice =  {
//             total_unpaid_value : Number(sumUnpaidinvoice.total),
//             total_unpaid_count : Number(sumUnpaidinvoice.count) 
//             }   
            
//         const Totalpaidinvoice = {
//               total_paid_value : Number(sumPaidinvoice.total),
//               total_paid_count : Number(sumPaidinvoice.count) 
//         }
        
//         const Totalinvoice = {
//               total_invoice_value : Number(sumTotalinvoicevalue.total),
//               total_invoice_count : Number(sumTotalinvoicevalue.count) 
//         }
        
        
//          let invoicearrayData = []
         
         
         
         
//          for(const value of getAllinvoice){
//              const getCustomerdata = await Customers.findOne({where:{id: value.customer_id}, attributes:['id','name','email','phone_number']})
//              const parseOrderedproduct = JSON.parse(value.products_ordered_array	)
            
//              const invoiceData = {
//                  "invoice_number": value.invoice_number,
//                  "customer_info": getCustomerdata,
//                  "date": value.date,
//                  "payment_method": value.payment_method,
//                  "total_amount": value.total_amount,
//                  "created_by": value.created_by,
//                  "payment_status": value.status,
//                  "products_ordered": parseOrderedproduct,
//                  "discount_name" : value.discount_name
//              }
//              invoicearrayData.push(invoiceData)
//          }
         
//          if(pagenumber == "All"){
//              return res.status(200).json({totalinvoice:Totalinvoice,totalpaidinvoice: Totalpaidinvoice,totalunpaidinvoice : Totalunpaidinvoice, data:invoicearrayData})
//          }
         
//          const paginatedData = await pagination(invoicearrayData, page)
         
//          return res.status(200).json({totalinvoice:Totalinvoice,totalpaidinvoice: Totalpaidinvoice,totalcancelinvoice :Totalcancelinvoice,  totalunpaidinvoice : Totalunpaidinvoice, data:paginatedData})
         
         
// }


// //update sorted status
// exports.updateSortedstatus =  async (req, res, next)=>{
//     const invoice_number = req.query.invoice_number
//     const status = req.query.sorted_status
//     if(!status || !invoice_number){
//           return res.status(400).json({message:"status and invoice number required"})
//     }
//     if(status == "Sorted" || status == "Not Sorted"){
//          try{
//         await Sortorders.update({
//             sorted_status : status
//         },{where:{invoice_number: invoice_number}})
        
//         return res.status(200).json({message:"success"})
//     }catch(error){
//              return res.status(400).json({message:error.message})
//     }
//     }
//   return res.status(400).json({message:"invalid status passed"})
// }

// //get all sorted orders
// exports.getAllsortedorders = async (req, res, next)=>{
//     const filtervalue = req.query.search_value
//     const shop_id = req.query.shop_id
//     let getAllrecords
//     try{
        
//     if(!shop_id){
   
//     return res.status(400).json({message:"shop id required"})
    
//     }
    
//      let page = 0;
//             const pagenumber = req.query.page;
            
//             if(pagenumber == 0 || pagenumber > 0){
              
//             if(!Number.isNaN(pagenumber) && pagenumber > 0 ){
//                 page = pagenumber;
//             }
            
//             }
            
//     if(filtervalue){
//       getAllrecords = await Sortorders.findAll({where:{shop_id: shop_id, [Op.or]: [
//           { sorted_status: filtervalue },
//           { invoice_number : filtervalue},

//         ] },order: [["date", "DESC"]]}) 
//     }
//      if(!filtervalue){
//          getAllrecords = await Sortorders.findAll({where:{shop_id : shop_id },order: [["date_time", "DESC"]]}) 
//      }
//     let invoicearrayData = []
    
//     if(getAllrecords.length == 0){
//         return res.status(400).json({message:"no records found"})
//     }
//     //count total sorted 
//     const countSorted =   await Sortorders.count({where:{sorted_status :"Sorted"}, order: [["date_time", "DESC"]]})
    
//     const countNotsorted = await Sortorders.count({where:{sorted_status :"Not Sorted"}})
//     for (const data of getAllrecords){
//           const getinvoice = await Invoice.findOne({where:{invoice_number: data.invoice_number}})
//           const getCustomerdata = await Customers.findOne({where:{id: getinvoice.customer_id}, attributes:['id','name','email','phone_number']})
//              const parseOrderedproduct = JSON.parse(getinvoice.products_ordered_array	)
            
//              const invoiceData = {
//                  "invoice_number": getinvoice .invoice_number,
//                  "customer_info": getCustomerdata,
//                  "date": getinvoice.date,
//                  "payment_method": getinvoice.payment_method,
//                  "total_amount": getinvoice.total_amount,
//                  "created_by": getinvoice.created_by,
//                  "payment_status": data.payment_status,
//                  "products_ordered": parseOrderedproduct,
//                  "discount_name" : getinvoice.discount_name,
//                  "sorted_status" : data.sorted_status,
//                  "payment_approved_date": data.date
//              }
//              invoicearrayData.push(invoiceData)
//     }
//      const paginatedData = await pagination(invoicearrayData, page)
     
//       return res.status(200).json({totalsorted: countSorted,totalnotsorted: countNotsorted, data:  paginatedData })
       
//     }catch(error){
//              return res.status(400).json({message:error.message})
//     }
// }
// //save new customers
// exports.SavenewCustomers = async (req, res, next)=>{
//     const {customer_name, customer_email, customer_phone_number} = req.body
    
//      if(customer_email &&customer_phone_number && customer_name ){
                
//                   let date_ob = new Date();
//                 let date = ("0" + date_ob.getDate()).slice(-2);
//                 let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
//                 let year = date_ob.getFullYear();
//                 const date_recorded = year + "-" + month + "-" + date;
                
//                 //check duplicate
//                 const checkDuplicate = await  Customers.findOne({where:{email : customer_email,phone_number : customer_phone_number}})
                
//                 if(checkDuplicate){
//                     return res.status(400).json({message: "Customer info  already exist"})
//                 }
                
//                 await Customers.create({
//                     name: customer_name,
//                     email : customer_email,
//                     phone_number : customer_phone_number,
//                     date : date_recorded
//                 })
                
//                  return res.status(200).json({message: "Customer info  added"})
//             }else{
//                  return res.status(400).json({message: "Customer info  needed"})
//             }
    
// }

// //get all customers for invoice form
// exports.getCustomers = async (req, res, next)=>{
    
//      const search_value = req.query.search_value
     
//      if(search_value){
         
//          const Customerdata = await Customers.findAll({
//       where: {
//         [Op.or]: [
//           { name: { [Op.like]: `%${search_value}%` } },
//           { phone_number : { [Op.like]: `%${search_value}%` } },
//           { email: search_value},
//         ]
//       }
//     })
    
//     return res.status(200).json(Customerdata)
    
//      }
        
    
    
//      const getCustomerdata = await Customers.findAll({attributes:['id','name','phone_number','email']})
     
     
//     return res.status(200).json(getCustomerdata)
// }












