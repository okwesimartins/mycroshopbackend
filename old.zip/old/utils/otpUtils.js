const crypto = require('crypto');

const SECRET = 'thrhhhejjhtbrhjejjjehrhhththrnnjdhurgsbbehhuqxbnzmzzmmm' // Must be the same for encryption/decryption

exports.generateOtp = async (length = 6) => {
  return Math.floor(100000 + Math.random() * 900000).toString().substring(0, length);
}

exports.encryptOtpPayload = async (otp, expiresAt) =>{
  const data = JSON.stringify({ otp, expiresAt });
  const cipher = crypto.createCipher('aes-256-ctr', SECRET);
  const encrypted = Buffer.concat([cipher.update(data), cipher.final()]);
  return encrypted.toString('hex');
}

exports.decryptOtpPayload = async (encryptedToken) => {
  const decipher = crypto.createDecipher('aes-256-ctr', SECRET);
  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(encryptedToken, 'hex')),
    decipher.final()
  ]);
  return JSON.parse(decrypted.toString());
}

