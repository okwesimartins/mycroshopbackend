
module.exports = (sequelize, Sequelize) => {
  const AgentCompanyMappings = sequelize.define("agent_company_mappings", {
    agent_id: Sequelize.INTEGER,
    company_id: Sequelize.INTEGER,
  }, {
    tableName: "agent_company_mappings"
  });
  return AgentCompanyMappings;
};