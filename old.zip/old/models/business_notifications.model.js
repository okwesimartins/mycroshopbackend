module.exports = (sequelize, Sequelize)=>{
    
      const Business_notifications = sequelize.define("business_notifications",{
       message: {
            type: Sequelize.STRING
          },
       business_id: {
            type: Sequelize.INTEGER
          },
        business_type: {
            type: Sequelize.STRING
          },
          
        sent_status: {
            type: Sequelize.INTEGER
          },
        
      },{
          tableName: 'business_notifications'
      })

      return  Business_notifications;
}