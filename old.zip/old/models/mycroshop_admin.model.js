module.exports = (sequelize, Sequelize)=>{
    
      const Mycroshop_admin = sequelize.define("mycroshop_admin",{
       name: {
            type: Sequelize.STRING
          },
       	email: {
            type: Sequelize.STRING
          },
        phone_number:{
            type: Sequelize.STRING
          },
        password:{
            type: Sequelize.STRING
          },
        date:{
            type: Sequelize.STRING
          },
          admin_type:{
            type: Sequelize.STRING
          }
      },{
          tableName: 'mycroshop_admin'
      })

      return  Mycroshop_admin;
}