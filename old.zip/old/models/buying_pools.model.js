module.exports = (sequelize, Sequelize)=>{
    
      const Buying_pools = sequelize.define("buying_pools",{
       product_name: {
            type: Sequelize.STRING
          },
       price_per_unit:{
            type: Sequelize.INTEGER
       },
      product_description: {
            type: Sequelize.STRING
          },
      product_image: {
            type: Sequelize.STRING
          },
      pool_title: {
            type: Sequelize.STRING
          },
      minimum_order_quantity: {
            type: Sequelize.STRING
          },
      target_quantity: {
            type: Sequelize.STRING
          },
      min_buyers: {
            type: Sequelize.STRING
          },
      max_buyers: {
            type: Sequelize.STRING
          },
      pool_start_date: {
            type: Sequelize.STRING
          },
      shipping_destination: {
            type: Sequelize.STRING
          },
      terms_and_condition: {
            type: Sequelize.STRING
          },
      pool_status: {
            type: Sequelize.STRING
          },
      mycroshop_supplier_id: {
            type: Sequelize.INTEGER
          },
     created_at_date: {
            type: Sequelize.STRING
          },
    processing_date: {
            type: Sequelize.STRING
          },
    arrived_date: {
            type: Sequelize.STRING
          },
    category_id: {
            type: Sequelize.INTEGER
          } ,
    expected_arrival_date: {
            type: Sequelize.STRING
          },
    variation: {
            type: Sequelize.JSON // [{length:10,color:"blue",size:"",material:"N/A",weight:"",price_per_unit:"1000"}]
          }
          
      },{
          tableName: 'buying_pools'
      })

      return  Buying_pools;
}