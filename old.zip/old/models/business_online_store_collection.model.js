module.exports = (sequelize, Sequelize)=>{
    
      const Business_online_store_collection = sequelize.define("business_online_store_collection",{
       collection_name: {
            type: Sequelize.STRING
          },
       collection_backgroud_color	: {
            type: Sequelize.STRING
          },
       store_id: {
            type: Sequelize.INTEGER
          }
          
      },{
          tableName: 'business_online_store_collection'
      })

      return  Business_online_store_collection;
}