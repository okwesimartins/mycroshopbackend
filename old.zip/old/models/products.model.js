module.exports = (sequelize, Sequelize)=>{
    
      const Product = sequelize.define("products",{
       product_name: {
            type: Sequelize.STRING
          },
      
       product_category: {
            type: Sequelize.INTEGER
          },
       image: {
            type: Sequelize.STRING
          },
      color: {
            type: Sequelize.STRING
          },
       unit: {
            type: Sequelize.STRING
        },
       total_buying_price:{
        	  type: Sequelize.STRING
        	},
       total_selling_price: {
            type: Sequelize.STRING
          },
       inches: {
            type: Sequelize.STRING
          },
       product_description: {
            type: Sequelize.STRING
          },
       total_product_stock: {
            type: Sequelize.INTEGER
        },
       total_stock_value:{
        	  type: Sequelize.STRING
        	},
       	created_by:{
        	  type: Sequelize.STRING
        	},
      date:{
        	  type: Sequelize.STRING
        	},
     shop_id:{
            type: Sequelize.STRING
        },
   supplier_id: {
            type: Sequelize.INTEGER
        },
        
          date_time: {
            type: Sequelize.DATE
          }
        	
      },{
          tableName: 'products'
      })

      return Product;
}