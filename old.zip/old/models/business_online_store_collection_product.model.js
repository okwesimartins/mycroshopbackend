module.exports = (sequelize, Sequelize)=>{
    
      const Business_online_store_collection_product = sequelize.define("business_online_store_collection_product",{
       store_collection_id:{
            type: Sequelize.INTEGER
          },
       	store_product_id:{
            type: Sequelize.INTEGER
          }
          
      },{
          tableName: 'business_online_store_collection_product'
      })

      return  Business_online_store_collection_product;
}