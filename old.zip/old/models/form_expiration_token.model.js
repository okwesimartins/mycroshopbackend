module.exports = (sequelize, Sequelize)=>{
    
      const Form_expiration_token = sequelize.define("form_expiration_token",{
       token: {
            type: Sequelize.STRING
          },
       	expiration_date_and_time: {
            type: Sequelize.STRING
          },
        trials:{
            type: Sequelize.INTEGER
          }
          
      },{
          tableName: 'form_expiration_token'
      })

      return  Form_expiration_token;
}