module.exports = (sequelize, Sequelize)=>{
    
      const Buying_pool_customers = sequelize.define("buying_pool_customers",{
       name: {
            type: Sequelize.STRING
          },
      email: {
            type: Sequelize.STRING
          },
      phone_number: {
            type: Sequelize.STRING
          },
      password: {
            type: Sequelize.STRING
          },
      date: {
            type: Sequelize.STRING
          },
     password_updated:{
            type: Sequelize.INTEGER
          }
          
      },{
          tableName: 'buying_pool_customers'
      })

      return  Buying_pool_customers;
}