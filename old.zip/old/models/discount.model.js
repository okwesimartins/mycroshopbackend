module.exports = (sequelize, Sequelize)=>{
    
      const Discount = sequelize.define("discount",{
       discount_name: {
            type: Sequelize.STRING
          },
       discount_value: {
            type: Sequelize.STRING
          },
       expiration_date: {
            type: Sequelize.STRING
          },
       status: {
            type: Sequelize.STRING
          },
      business_id: {
            type: Sequelize.INTEGER
          }
      },{
          tableName: 'discount'
      })

      return  Discount;
}