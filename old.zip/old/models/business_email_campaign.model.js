module.exports = (sequelize, Sequelize)=>{
    
      const Business_email_campaign = sequelize.define("business_email_campaign",{
       campaign_name: {
            type: Sequelize.STRING
          },
       email_template: {
            type: Sequelize.STRING
          },
       status: {
            type: Sequelize.STRING
          },
       date: {
            type: Sequelize.STRING
          },
       business_id: {
            type: Sequelize.STRING
          }
          
      },{
          tableName: 'business_email_campaign'
      })

      return  Business_email_campaign;
}