
module.exports = (sequelize, Sequelize)=>{
      const Business_suppliers = sequelize.define("business_suppliers",{
       supplier_name: {
            type: Sequelize.STRING
          },
       supplier_email: {
            type: Sequelize.STRING
          },
        supplier_phonenumber: {
            type: Sequelize.STRING
          },
           country: {
            type: Sequelize.STRING
          },
           state: {
            type: Sequelize.STRING
          },
        date: {
            type: Sequelize.STRING
          },
       status: {
            type: Sequelize.INTEGER
          },
        created_by: {
            type: Sequelize.STRING
          },
        business_id:{
            type: Sequelize.INTEGER
        }
      },{
          tableName: 'business_suppliers'
      })

      return Business_suppliers;
}