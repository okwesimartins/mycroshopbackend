module.exports = (sequelize, Sequelize)=>{
    
      const Business_sms_whatsapp_campaign = sequelize.define("business_sms_whatsapp_campaign",{
       campaign_name:{
            type: Sequelize.STRING
          },
      image:{
            type: Sequelize.STRING
          },
      
      text:{
            type: Sequelize.STRING
          },
      campaign_type:{
            type: Sequelize.STRING
          },
     status:{
            type: Sequelize.STRING
          },
     
     business_id:{
            type: Sequelize.STRING
          },
    date:{
            type: Sequelize.STRING
          }
      },{
          tableName: 'business_sms_whatsapp_campaign'
      })

      return  Business_sms_whatsapp_campaign;
}