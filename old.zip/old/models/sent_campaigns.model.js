module.exports = (sequelize, Sequelize)=>{
    
      const Sent_campaigns = sequelize.define("sent_campaigns",{
       	campaign_info: {
            type: Sequelize.INTEGER
          },
       	sent_status: {
            type: Sequelize.INTEGER
          },
        business_id:{
            type: Sequelize.INTEGER
          },
        date:{
            type: Sequelize.STRING
          }
      },{
          tableName: 'sent_campaigns'
      })

      return  Sent_campaigns;
}