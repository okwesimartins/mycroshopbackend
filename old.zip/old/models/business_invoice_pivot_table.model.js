module.exports = (sequelize, Sequelize)=>{
    
      const Business_invoice_pivot_table = sequelize.define("business_invoice_pivot_table",{
       business_id: {
            type: Sequelize.INTEGER
          },
       invoice_id: {
            type: Sequelize.INTEGER
          }
          
      },{
          tableName: 'business_invoice_pivot_table'
      })

      return  Business_invoice_pivot_table;
}