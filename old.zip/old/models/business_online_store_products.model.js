module.exports = (sequelize, Sequelize)=>{
    
      const Business_online_store_products = sequelize.define("business_online_store_products",{
       business_id: {
            type: Sequelize.INTEGER
          },
       product_id: {
            type: Sequelize.INTEGER
          },
        store_id: {
            type: Sequelize.INTEGER
          }
          
      },{
          tableName: 'business_online_store_products'
      })

      return  Business_online_store_products;
}