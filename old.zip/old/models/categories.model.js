module.exports = (sequelize, Sequelize)=>{
    
      const Categories = sequelize.define("categories",{
       category_name: {
            type: Sequelize.STRING
          },
       date: {
            type: Sequelize.STRING
          }
      },{
          tableName: 'categories'
      })

      return  Categories;
}