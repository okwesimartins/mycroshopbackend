module.exports = (sequelize, Sequelize)=>{
    
      const Business_purchases_pivot_table = sequelize.define("business_purchases_pivot_table",{
       business_id: {
            type: Sequelize.INTEGER
          },
      purchase_id: {
            type: Sequelize.INTEGER
          }
          
      },{
          tableName: 'business_purchases_pivot_table'
      })

      return  Business_purchases_pivot_table;
}