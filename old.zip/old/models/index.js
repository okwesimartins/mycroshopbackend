const Sequelize= require("sequelize");


const sequelize = new Sequelize("legithairng_mycroshop","legithairng_mycroshopuser", "Saintseverus911@", {
    host: "legithairng.com",
    port:3306,
    dialect: "mysql",
    dialectOptions:{
        connectTimeout: 100000
    },
    define:{
       timestamps: false
    },
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000
    }
  });
  
  const db = {};
  
  db.Sequelize = Sequelize;
  db.sequelize = sequelize;
  
  db.shop = require("./shop.model.js")(sequelize, Sequelize);
  db.stock_movement = require("./stock_movement.model.js")(sequelize, Sequelize);
  db.stock_summary = require("./stock_summary.model.js")(sequelize, Sequelize);
  db.purchase = require("./purchase.model.js")(sequelize, Sequelize);
  db.notifications = require("./notifications.model.js")(sequelize, Sequelize);
  db.child_menu = require("./child_menu.model.js")(sequelize, Sequelize);
  db.customers = require("./business_customers.model.js")(sequelize, Sequelize);
  db.categories = require("./categories.model.js")(sequelize, Sequelize);
  db.menus = require("./menus.model.js")(sequelize, Sequelize);
  db.payment_list = require("./payment_list.model.js")(sequelize, Sequelize);
  db.products = require("./products.model.js")(sequelize, Sequelize);
  db.privileges = require("./privileges.model.js")(sequelize, Sequelize);

  
  db.invoice =  require("./invoice.model.js")(sequelize, Sequelize);
  
  db.discount =  require("./discount.model.js")(sequelize, Sequelize);
  
  db.business = require("./business.model.js")(sequelize, Sequelize);
  
  db.business_email_campaign = require("./business_email_campaign.model.js")(sequelize, Sequelize);
  
  db.business_employees = require("./business_employees.model.js")(sequelize, Sequelize)

  db.business_invoice_pivot_table = require("./business_invoice_pivot_table.model.js")(sequelize, Sequelize)
  
  db.business_notifications = require("./business_notifications.model.js")(sequelize, Sequelize)
  
  db.business_online_store_collection = require("./business_online_store_collection.model.js")(sequelize, Sequelize)
  
  db.business_online_store_collection_product = require("./business_online_store_collection_product.model.js")(sequelize, Sequelize)
  
  db.business_online_store_front = require("./business_online_store_front.model.js")(sequelize, Sequelize)
  
  db.business_online_store_products = require("./business_online_store_products.model.js")(sequelize, Sequelize)
  
  db.business_online_store_services = require("./business_online_store_services.model.js")(sequelize, Sequelize)
  
  db.business_product_category_pivot_table = require("./business_product_category_pivot_table.model.js")(sequelize, Sequelize)
  
  db.business_product_pivot_table = require("./business_product_pivot_table.model.js")(sequelize, Sequelize)
  
  db.business_purchases_pivot_table = require("./business_purchases_pivot_table.model.js")(sequelize, Sequelize)
  
  db.buying_pools = require("./buying_pools.model.js")(sequelize, Sequelize)
  
  db.buying_pool_customers = require("./buying_pool_customers.model.js")(sequelize, Sequelize)
  
  db.buying_pool_joined_by_customers = require("./buying_pool_joined_by_customers.model.js")(sequelize, Sequelize)
  
  db.logistics_agents = require("./logistics_agents.model.js")(sequelize, Sequelize)
  
  db.logistic_agent_listings = require("./logistic_agent_listings.model.js")(sequelize, Sequelize)
  
  db.logistic_bookings = require("./logistic_bookings.model.js")(sequelize, Sequelize)
  
  db.mycroshop_admin = require("./mycroshop_admin.model.js")(sequelize, Sequelize)
  
  db.mycroshop_suppliers = require("./mycroshop_suppliers.model.js")(sequelize, Sequelize)
  
  db.sent_campaigns = require("./sent_campaigns.model.js")(sequelize, Sequelize)
  
  db.subscription_payments = require("./subscription_payments.model.js")(sequelize, Sequelize)
  
  db.subscription_plans = require("./subscription_plans.model.js")(sequelize, Sequelize)
  
  db.form_expiration_token = require("./form_expiration_token.model.js")(sequelize, Sequelize)
  
  db.buying_pool_subscription_payment = require("./buying_pool_subscription_payment.model.js")(sequelize, Sequelize)
  
  db.buying_pool_suppliers_sub_plan = require("./buying_pool_suppliers_sub_plan.model.js")(sequelize, Sequelize)
  
  db.mycroshop_logistics_customers = require("./mycroshop_logistics_customers.model.js")(sequelize, Sequelize)
  
  db.logistics_token_payments = require("./logistics_token_payments.model.js")(sequelize, Sequelize)
  
  db.logisticsCompanies = require("./logisticscompanies.model.js")(sequelize, Sequelize)
  
  db.agent_company_mappings = require("./agent_company_mappings.model.js")(sequelize, Sequelize)
  
  db.freelance_agents = require("./freelance_agents.model.js")(sequelize, Sequelize)
  
  db.pickup_request = require("./pickup_request.model.js")(sequelize, Sequelize)
  
  db.manual_terminal_bookings = require("./manual_terminal_bookings.model.js")(sequelize, Sequelize)
  
  db.buying_pool_extra_purchases = require("./buying_pool_extra_purchases.model.js")(sequelize, Sequelize)
  
  module.exports = db;
  
  