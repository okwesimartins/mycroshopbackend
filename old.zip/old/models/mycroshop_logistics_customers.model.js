module.exports = (sequelize, Sequelize)=>{
    
      const Mycroshop_logistics_customers = sequelize.define("mycroshop_logistics_customers",{
       name: {
            type: Sequelize.STRING
          },
       email: {
            type: Sequelize.STRING
          },
       phone_number: {
            type: Sequelize.INTEGER
          },
       	password: {
            type: Sequelize.STRING
          },
        date_created:{
            type: Sequelize.STRING
          },
        logistic_token:{
            type: Sequelize.INTEGER
          }
      },{
          tableName: 'mycroshop_logistics_customers'
      })

      return  Mycroshop_logistics_customers;
}