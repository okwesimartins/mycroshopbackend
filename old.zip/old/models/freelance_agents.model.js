module.exports = (sequelize, Sequelize) => {
  const FreelanceAgents = sequelize.define("freelance_agents", {
    name: { type: Sequelize.STRING },
    email: { type: Sequelize.STRING },
    phone_number: { type: Sequelize.STRING },
    password: { type: Sequelize.STRING },
    vehicle_type: { type: Sequelize.STRING },
    nin: { type: Sequelize.STRING },
    status: { type: Sequelize.STRING, defaultValue: 'pending' }, // pending, active, blocked
    location_lat: { type: Sequelize.FLOAT },
    location_lng: { type: Sequelize.FLOAT },
    country : { type: Sequelize.STRING },
    state :  { type: Sequelize.STRING },
    lga: { type: Sequelize.STRING },
    date_registered: { type: Sequelize.STRING }
  }, {
    tableName: 'freelance_agents'
  });
  return FreelanceAgents;
};