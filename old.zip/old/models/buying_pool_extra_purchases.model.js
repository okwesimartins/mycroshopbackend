module.exports = (sequelize, Sequelize)=>{
      const Buying_pool_extra_purchases = sequelize.define("buying_pool_extra_purchases",{
       pool_join_id: {
            type: Sequelize.INTEGER
          },
       varaition: {
            type: Sequelize.JSON // [{length:10,color:"blue",size:"",material:"N/A",weight:"",price_per_unit:"1000"}]
          },
        payment_reference: {
            type: Sequelize.STRING
          },
        quantity_purchased: {
            type: Sequelize.STRING
          }
        
      },{
          tableName: 'buying_pool_extra_purchases'
      })

      return Buying_pool_extra_purchases;
}