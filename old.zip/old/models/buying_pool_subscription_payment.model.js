module.exports = (sequelize, Sequelize)=>{
    
      const Buying_pool_subscription_payment = sequelize.define("buying_pool_subscription_payment",{
       buying_pool_customer_id: {
            type: Sequelize.INTEGER
          },
       payment_reference: {
            type: Sequelize.STRING
          },
       plan_id: {
            type: Sequelize.STRING
          },
       sub_type: {
            type: Sequelize.STRING
          },
       date: {
            type: Sequelize.STRING
          },
       mycroshop_admin_payment_status: {
            type: Sequelize.INTEGER
          },
       supplier_id: {
            type: Sequelize.INTEGER
          },
      expiration_date: {
            type: Sequelize.STRING
          }
          
      },{
          tableName: 'buying_pool_subscription_payment'
      })

      return  Buying_pool_subscription_payment;
}