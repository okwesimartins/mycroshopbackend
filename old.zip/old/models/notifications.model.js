module.exports = (sequelize, Sequelize)=>{
    
      const Notifications = sequelize.define("notifications",{
       actioned_performed: {
            type: Sequelize.STRING
          },
        type: {
            type: Sequelize.STRING
          },
       shop_id: {
            type: Sequelize.INTEGER
          }
          
      },{
          tableName: 'notifications'
      })

      return  Notifications;
}