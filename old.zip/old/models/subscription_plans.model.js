module.exports = (sequelize, Sequelize)=>{
    
      const Subscription_plans = sequelize.define("subscription_plans",{
          
       		plan_name: {
       		    type: Sequelize.STRING 
          },
       	yearly_fee: {
            type: Sequelize.STRING
          },
        details: {
           type: Sequelize.STRING
        }
      },{
          tableName: 'subscription_plans'
      })

      return  Subscription_plans;
}