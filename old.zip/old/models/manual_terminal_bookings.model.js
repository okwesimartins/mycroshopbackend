module.exports = (sequelize, Sequelize) => {

    const Manual_terminal_bookings = sequelize.define("manual_terminal_bookings", {
        listing_id: {
            type: Sequelize.INTEGER
        },
        company_id: {
            type: Sequelize.INTEGER
        },
        booking_agent_id: { // The agent who created the booking at the terminal
            type: Sequelize.INTEGER
        },
        booking_id: { // Unique identifier for this booking
            type: Sequelize.STRING
        },
        logistic_type: { // 'delivery' or 'travel'
            type: Sequelize.STRING
        },
        // --- Payment Details ---
        amount_paid: {
            type: Sequelize.FLOAT
        },
        payment_method: { // e.g., 'cash', 'pos', 'transfer'
            type: Sequelize.STRING
        },
        // --- Parcel Details ---
        parcel_kg: { type: Sequelize.FLOAT },
        sender_name: { type: Sequelize.STRING },
        sender_phone: { type: Sequelize.STRING },
        recipient_name: { type: Sequelize.STRING },
        recipient_phone: { type: Sequelize.STRING },
        recipient_address: { type: Sequelize.STRING },
        // --- Travel Details ---
        seat_numbers: { type: Sequelize.JSON }, // Stored as ["A1", "B2"]
        passenger_name: { type: Sequelize.STRING },
        passenger_phone: { type: Sequelize.STRING },
        emergency_contact_name: { type: Sequelize.STRING },
        emergency_contact_phone: { type: Sequelize.STRING },
        // --- Status Tracking ---
        status: {
            type: Sequelize.STRING // Other statuses: 'checked_in', 'in_transit', 'arrived', 'delivered', 'cancelled'
        },
        date: {
            type: Sequelize.DATE
        }
    }, {
        tableName: 'manual_terminal_bookings'
    });

    return Manual_terminal_bookings;
}