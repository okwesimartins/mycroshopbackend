module.exports = (sequelize, Sequelize)=>{
    
      const shops = sequelize.define("shops",{
       shop_name: {
            type: Sequelize.STRING
          },
       business_id: {
            type: Sequelize.STRING
          }
      },{
          tableName: 'shops'
      })

      return  shops;
}