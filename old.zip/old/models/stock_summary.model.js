module.exports = (sequelize, Sequelize)=>{
    
      const monthly_stock_summary = sequelize.define("monthly_stock_summary",{
       product_id: {
            type: Sequelize.INTEGER
          },
       inch: {
            type: Sequelize.STRING
          },
     opening_stock: {
            type: Sequelize.STRING
          },
      month:{
            type: Sequelize.STRING
        },
     year: {
            type: Sequelize.STRING
          },
     shop_id: {
            type: Sequelize.STRING
          },
      date_time: {
            type: Sequelize.DATE
          }
      },{
          tableName: 'monthly_stock_summary'
      })

      return  monthly_stock_summary;
}