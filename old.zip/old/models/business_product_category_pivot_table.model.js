module.exports = (sequelize, Sequelize)=>{
    
      const Business_product_category_pivot_table = sequelize.define("business_product_category_pivot_table",{
       business_id: {
            type: Sequelize.INTEGER
          },
       category_id: {
            type: Sequelize.INTEGER
          }
          
      },{
          tableName: 'business_product_category_pivot_table'
      })

      return  Business_product_category_pivot_table;
}