module.exports = (sequelize, Sequelize)=>{
    
      const Logistic_bookings = sequelize.define("logistic_bookings",{
    user_id: Sequelize.INTEGER,
    user_type: Sequelize.STRING,
    listing_id: Sequelize.STRING,
    company_id: Sequelize.INTEGER,
    logistic_agent_id: Sequelize.INTEGER,
    seat_number: Sequelize.JSON,
    parcel_kg: Sequelize.INTEGER,
    amount_paid: Sequelize.STRING,
    payment_reference: Sequelize.STRING,
    date: Sequelize.STRING,
    booking_id: Sequelize.STRING,
    status: Sequelize.INTEGER,
    pickup_fee:Sequelize.STRING
      },{
          tableName: 'logistic_bookings'
      })

      return  Logistic_bookings;
}