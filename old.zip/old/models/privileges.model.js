
module.exports = (sequelize, Sequelize)=>{
      const privileges = sequelize.define("privileges",{
       role_type_id: {
            type: Sequelize.INTEGER
          },
       privileges: {
            type: Sequelize.STRING
          }
      },{
          tableName: 'privileges'
      })

      return privileges;
}