module.exports = (sequelize, Sequelize)=>{
    
      const stock_movement = sequelize.define("stock_movement",{
       product_id: {
            type: Sequelize.INTEGER
          },
         inch: {
            type: Sequelize.STRING
          },
       movement_type: {
            type: Sequelize.STRING
          },
      movement_reason: {
            type: Sequelize.STRING
          },
      quantity:{
            type: Sequelize.STRING
        },
     balance: {
            type: Sequelize.STRING
          },
     movement_date: {
            type: Sequelize.STRING
          },
     shop_id: {
            type: Sequelize.STRING
          },
      date_time: {
            type: Sequelize.DATE
          }
      },{
          tableName: 'stock_movement'
      })

      return  stock_movement;
}