module.exports = (sequelize, Sequelize)=>{
    
      const customers = sequelize.define("business_customers",{
       name: {
            type: Sequelize.STRING
          },
       email: {
            type: Sequelize.STRING
          },
       phone_number: {
            type: Sequelize.STRING
          },
       date: {
            type: Sequelize.STRING
          },
        business_id: {
            type: Sequelize.INTEGER
          }
      },{
          tableName: 'business_customers'
      })

      return  customers;
}