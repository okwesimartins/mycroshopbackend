module.exports = (sequelize, Sequelize)=>{
    
      const Logistic_agent_listings = sequelize.define("logistic_agent_listings",{
        logistics_agent_id: Sequelize.INTEGER,
    logistics_company_id:Sequelize.INTEGER,
    country: Sequelize.STRING,
    state_created_in: Sequelize.STRING,
    destination_state: Sequelize.STRING,
    destination_address: Sequelize.STRING,
    package_category: Sequelize.STRING,
    price: Sequelize.STRING,
    price_per_kg: Sequelize.FLOAT,
    total_kg_limit: Sequelize.INTEGER,
    available_kg: Sequelize.INTEGER,
    available_seats: Sequelize.INTEGER,
    seat_map: Sequelize.JSON, // Example: [{"seat":"A1","booked":false}]
    logistic_type: Sequelize.STRING, // 'delivery' or 'travel'
    departure_date: Sequelize.STRING,
    departure_time: Sequelize.STRING,
    driver_name: Sequelize.STRING,
    driver_number: Sequelize.STRING,
    driver_second_number: Sequelize.STRING,
    status: Sequelize.STRING, //'open' or 'closed'
    date_created: Sequelize.STRING
      },{
          tableName: 'logistic_agent_listings'
      })

      return  Logistic_agent_listings;
}