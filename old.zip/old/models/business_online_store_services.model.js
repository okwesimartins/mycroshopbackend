module.exports = (sequelize, Sequelize)=>{
    
      const Business_online_store_services = sequelize.define("business_online_store_services",{
       	store_id:{
            type: Sequelize.INTEGER
          },
       service_title:{
            type: Sequelize.STRING
          },
       service_description:{
            type: Sequelize.STRING
          },
       service_price: {
            type: Sequelize.STRING
          },
       service_image: {
            type: Sequelize.STRING
          },
       service_duration:{
            type: Sequelize.STRING
          },
       availability: {
            type: Sequelize.INTEGER
          },
       location: {
            type: Sequelize.STRING
          },
       call_to_action: {
            type: Sequelize.STRING
          }
          
      },{
          tableName: 'business_online_store_services'
      })

      return  Business_online_store_services;
}