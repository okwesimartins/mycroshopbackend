
module.exports = (sequelize, Sequelize)=>{
      const payment_list = sequelize.define("payments",{
       payment_type: {
            type: Sequelize.STRING
          },
       amount: {
            type: Sequelize.STRING
          },
       	date: {
            type: Sequelize.STRING
          },
         business_id:{
            type: Sequelize.INTEGER
        },
        customer_id: {
            type: Sequelize.INTEGER
          }
      },{
          tableName: 'payments'
      })

      return payment_list;
}