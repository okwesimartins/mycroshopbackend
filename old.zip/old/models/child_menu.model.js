module.exports = (sequelize, Sequelize)=>{
    
      const child_menu = sequelize.define("child_menu",{
       child_menu_name: {
            type: Sequelize.STRING
          },
       parent_id:{
            type: Sequelize.INTEGER
        }
      },{
          tableName: 'child_menu'
      })

      return  child_menu;
}