module.exports = (sequelize, Sequelize)=>{
    
      const Buying_pool_joined_by_customers = sequelize.define("buying_pool_joined_by_customers",{
       pool_id: {
            type: Sequelize.INTEGER
          },
       	customer_id: {
            type: Sequelize.INTEGER
          },
        quantity_purchased:{
            type: Sequelize.STRING
          },
        date:{
            type: Sequelize.STRING
          },
        transaction_reference:{
            type: Sequelize.STRING
          },
        mycroshop_admin_payment_status:{
           type: Sequelize.STRING 
        },
        status:{
           type: Sequelize.STRING 
        },
       
        variation: {
            type: Sequelize.JSON // [{length:10,color:"blue",size:"",material:"N/A",weight:"",price_per_unit:"1000"}]
          }
      },{
          tableName: 'buying_pool_joined_by_customers'
      })

      return  Buying_pool_joined_by_customers;
}