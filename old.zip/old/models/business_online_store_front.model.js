module.exports = (sequelize, Sequelize)=>{
    
      const Business_online_store_front = sequelize.define("business_online_store_front",{
       	business_id: {
            type: Sequelize.INTEGER
          },
       	store_username: {
            type: Sequelize.STRING
          },
        store_description: {
            type: Sequelize.STRING
          },
       social_media_links: {
            type: Sequelize.STRING
          },
       restrict_store_to_a_location: {
            type: Sequelize.STRING
          },
       allow_delivery_date_and_time_incheckout:{
            type: Sequelize.INTEGER
          },
       store_profile_image: {
            type: Sequelize.STRING
          },
       	banner_image: {
            type: Sequelize.STRING
          },
           	background_image: {
            type: Sequelize.STRING
          },
       background_color:{
            type: Sequelize.INTEGER
          },
       button_color: {
            type: Sequelize.STRING
          },
       	button_font: {
            type: Sequelize.STRING
          },
          
      },{
          tableName: 'business_online_store_front'
      })

      return  Business_online_store_front;
}