module.exports = (sequelize, Sequelize)=>{
    
      const Business_employees = sequelize.define("business_employees",{
       name: {
            type: Sequelize.STRING
          },
       phone_number: {
            type: Sequelize.STRING
          },
       password: {
            type: Sequelize.STRING
          },
       date_created: {
            type: Sequelize.STRING
          },
       business_id: {
            type: Sequelize.INTEGER
          },
       menus_assigned: {
            type: Sequelize.STRING
          },
      status: {
            type: Sequelize.INTEGER
          },
          
      },{
          tableName: 'business_employees'
      })

      return  Business_employees;
}