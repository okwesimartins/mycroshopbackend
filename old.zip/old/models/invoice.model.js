module.exports = (sequelize, Sequelize)=>{
    
      const Invoice = sequelize.define("invoices",{
       invoice_number: {
            type: Sequelize.STRING
          },
       payment_method: {
            type: Sequelize.STRING
          },
       customer_id: {
            type: Sequelize.INTEGER
          },
       	products_ordered_array: {
            type: Sequelize.STRING
          },
        total_amount:{
            type: Sequelize.STRING
          },
        discounted:{
            type: Sequelize.INTEGER
          },
        created_by:{
            type: Sequelize.STRING
          },
        status:{
            type: Sequelize.INTEGER
          },
        date:{
            type: Sequelize.STRING
          },
         shop_id:{
            type: Sequelize.INTEGER
        },
        validated: {
            type: Sequelize.INTEGER
          },
        discount_name: {
            type: Sequelize.STRING
          },
          date_time: {
            type: Sequelize.DATE
          }
      },{
          tableName: 'invoices'
      })

      return  Invoice;
}