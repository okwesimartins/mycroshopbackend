module.exports = (sequelize, Sequelize)=>{
    
      const Buying_pool_suppliers_sub_plan = sequelize.define("buying_pool_suppliers_sub_plan",{
       mycroshop_supplier_id: {
            type: Sequelize.INTEGER
          },
       	plan_description: {
            type: Sequelize.STRING
          },
       monthly_duration: {
            type: Sequelize.INTEGER
          },
       	yearly_sub_amount: {
            type: Sequelize.INTEGER
          }
          
      },{
          tableName: 'buying_pool_suppliers_sub_plan'
      })

      return  Buying_pool_suppliers_sub_plan;
}