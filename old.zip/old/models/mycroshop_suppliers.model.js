module.exports = (sequelize, Sequelize)=>{
    
      const Mycroshop_suppliers = sequelize.define("mycroshop_suppliers",{
       	supplier_name: {
            type: Sequelize.STRING
          },
       	email: {
            type: Sequelize.STRING
          },
        phone_number:{
            type: Sequelize.STRING
          },
        password:{
            type: Sequelize.STRING
          },
        date:{
            type: Sequelize.STRING
          },
          status:{
            type: Sequelize.INTEGER
          },
         mycroshop_sub_commission:{
            type: Sequelize.STRING
          },
        paystack_public_key:{
            type: Sequelize.STRING
          },
        paystack_secrete_key:{
            type: Sequelize.STRING
          }
      },{
          tableName: 'mycroshop_suppliers'
      })

      return  Mycroshop_suppliers;
}