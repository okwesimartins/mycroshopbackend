module.exports = (sequelize, Sequelize)=>{
    
      const Business = sequelize.define("business",{
       name: {
            type: Sequelize.STRING
          },
       email: {
            type: Sequelize.STRING
          },
       phone_number: {
            type: Sequelize.STRING
          },
       password: {
            type: Sequelize.STRING
          },
       status: {
            type: Sequelize.STRING
          },
       date: {
            type: Sequelize.STRING
          },
       business_user_name: {
            type: Sequelize.STRING
          },
       business_category: {
            type: Sequelize.STRING
          },
      logistic_token: {
            type: Sequelize.INTEGER
          }
          
      },{
          tableName: 'business'
      })

      return  Business;
}