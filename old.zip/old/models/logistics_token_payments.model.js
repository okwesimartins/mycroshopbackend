module.exports = (sequelize, Sequelize)=>{
    
      const Logistics_token_payments = sequelize.define("logistics_token_payments",{
       user_id: {
            type: Sequelize.INTEGER
          },
       user_type: {
            type: Sequelize.STRING
          },
       payment_reference: {
            type: Sequelize.INTEGER
          },
       token_purchased: {
            type: Sequelize.STRING
          },
       amount_paid:{
            type: Sequelize.STRING
       },
        date:{
            type: Sequelize.STRING
          }
      },{
          tableName: 'logistics_token_payments'
      })

      return  Logistics_token_payments;
}