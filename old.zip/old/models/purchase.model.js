module.exports = (sequelize, Sequelize)=>{
    
      const purchase = sequelize.define("purchase",{
       product_id: {
            type: Sequelize.INTEGER
          },
       created_by: {
            type: Sequelize.STRING
          },
       date: {
            type: Sequelize.STRING
          },
       shop_id:{
            type: Sequelize.INTEGER
        },
     supplier: {
            type: Sequelize.STRING
          },
     product_quantity: {
            type: Sequelize.STRING
          },
     inches: {
            type: Sequelize.STRING
          },
      },{
          tableName: 'purchase'
      })

      return  purchase;
}