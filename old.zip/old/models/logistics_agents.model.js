module.exports = (sequelize, Sequelize)=>{
    
      const Logistics_agents = sequelize.define("logistics_agents",{
       name: {
            type: Sequelize.STRING
          },
       	email: {
            type: Sequelize.STRING
          },
          
        company_id: {
            type: Sequelize.INTEGER
          },
        phone_number:{
            type: Sequelize.STRING
          },
        password:{
            type: Sequelize.STRING
          },
        country:{
            type: Sequelize.STRING
          },
        location:{
            type: Sequelize.JSON
          },
        date:{
            type: Sequelize.STRING
          },
        mycroshop_commission:{
            type: Sequelize.STRING
        }
      },{
          tableName: 'logistics_agents'
      })

      return  Logistics_agents;
}