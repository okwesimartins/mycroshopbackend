
module.exports = (sequelize, Sequelize)=>{
    const Logistics_companies = sequelize.define("logistics_companies",{
    name: Sequelize.STRING,
    email: Sequelize.STRING,
    phone_number: Sequelize.STRING,
    password:Sequelize.STRING,
    country: Sequelize.STRING,
    location: Sequelize.JSON,//[{state:"Lagos", address:"4b toyin street"}]
    paystack_public_key: Sequelize.STRING,
    paystack_secrete_key: Sequelize.STRING,
    created_at: Sequelize.DATE
      },{
          tableName: 'logistics_companies'
      })

      return Logistics_companies;
}