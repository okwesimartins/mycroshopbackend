module.exports = (sequelize, Sequelize)=>{
    
      const Subscription_payments = sequelize.define("subscription_payments",{
          
       		subscription_plan_id: {
       		    type: Sequelize.INTEGER 
          },
       	payment_reference: {
            type: Sequelize.STRING
          },
        business_id: {
           type: Sequelize.INTEGER
        },
        status:{
            type: Sequelize.STRING
          },
        date:{
            type: Sequelize.STRING
          },
       expiration_date:{
           type: Sequelize.STRING 
       }
      },{
          tableName: 'subscription_payments'
      })

      return  Subscription_payments;
}