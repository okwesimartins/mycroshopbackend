module.exports = (sequelize, Sequelize) => {
  const PickupRequests = sequelize.define("pickup_requests", {
    customer_id: { type: Sequelize.INTEGER },
    booking_id: { type: Sequelize.STRING },
    agent_id: { type: Sequelize.INTEGER },
    status: { type: Sequelize.STRING }, // pending, assigned, picked, delivered
    pickup_address: { type: Sequelize.STRING },
    pickup_lat: { type: Sequelize.FLOAT },
    pickup_lng: { type: Sequelize.FLOAT },
    lga: { type: Sequelize.STRING },
    responded: { type: Sequelize.BOOLEAN},
    accepted_at: { type: Sequelize.DATE },
    rejected_at: { type: Sequelize.DATE },
    created_at: { type: Sequelize.STRING }
  }, {
    tableName: 'pickup_requests'
  });
  return PickupRequests;
}