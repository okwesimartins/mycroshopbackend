module.exports = (sequelize, Sequelize)=>{
    
      const Menus = sequelize.define("menus",{
       menu_name: {
            type: Sequelize.STRING
          }
      },{
          tableName: 'menus'
      })

      return  Menus;
}