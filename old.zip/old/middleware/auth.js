const Jwt = require("jsonwebtoken");
const key = 'tywuwiiiwoohhwbbbhhwhhbbnn';
const db = require("../models")
const Privilege = db.privileges

exports.verifyToken = (req, res, next)=>{
    let token = req.headers['authorization'];
   
   
      if(!token){
        return res.status(401).json({message: "Unauthorized request"});
      }
       
    

    try{

        token = token.split(' ')[1];
      
        if(token === 'null' || !token){
            return res.status(401).json({message: "Unauthorized request"});
        }
const verifieduser = Jwt.verify(token, key);

if(!verifieduser){
return res.status(401).json({message: "Unauthorized request"});
}
req.user = verifieduser;
next();
    } catch(error){
     res.status(400).send(error);
    }
}

exports.authorization =  (requiredAction) => {
  return (req, res, next) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');

    const { id, privileges = [] } = req.user;


    const hasPermission = privileges.includes(requiredAction);

    if (!hasPermission) {
      return res.status(403).json({ message: "You don't have permission to perform this action" });
    }

    next();
  };
}
















