const db = require("../models");
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const maxSize = 5 * 1024 * 1024; // 5MB limit per file

const fileFilter = (req, file, cb) => {
  const fileTypes = ["image/jpeg","video/mp4", "video/mp3","image/jpg", "image/png", "image/gif"];

  if (fileTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Invalid file format uploaded'), false);
  }
};

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadPath = './public/image';
    fs.mkdirSync(uploadPath, { recursive: true }); // Create directory if it doesn't exist
    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const filename = `${file.fieldname}-${uniqueSuffix}${path.extname(file.originalname)}`;
 
    cb(null, filename);
  }
});

const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: maxSize
  }
}).fields([{ name: 'images', maxCount: 10 }]); // Allow up to 10 images in the 'legithair' field


exports.imageValidator = (req, res, next) => {
    
        upload(req, res, (err) => {
            if(req.files && req.files['images']){
                
                 if (err) {
     
      if (err instanceof multer.MulterError) {
        switch (err.code) {
          case 'LIMIT_FILE_SIZE':
            return res.status(400).json({ error: 'File is too large. Please upload files under 5MB each.' });
          case 'LIMIT_FILE_COUNT':
            return res.status(400).json({ error: 'Maximum of 10 images allowed.' });
          default:
            return res.status(400).json(err);
        }
      } else {
        return res.status(400).json(err);
      }
    } else {
    // Log all uploaded files for debugging

      const files = req.files?.['images[]'] || [];
      const fileRecords = files.map(file => ({
        filename: file.filename
      }));

      try {
        fileRecords.forEach(async (fileRecord) => {
          const filePath = path.join('./public/image', fileRecord.filename);
          try {
            const buffer = Buffer.from(fileRecord.buffer);
            await fs.promises.writeFile(filePath, buffer);
           
          } catch (error) {
            
            // Handle error, e.g., remove partially saved file
            fs.unlinkSync(filePath);
          }
        });

         next()  // Proceed if all files are saved successfully
      } catch (error) {
      
        res.status(500).json({ error: 'Failed to save images' });
      }
    }
            }else{
              next()
            }
          
   
  });
  

};



