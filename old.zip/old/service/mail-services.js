
const nodemailer = require("nodemailer");
const ejs = require("ejs");
const path = require("path");
const url = require("url");
const fs = require('fs')

// const filepath = fs.readFileSync(path.join(__dirname, '/template/operation-flush.ejs'));

const filepath =  path.join(__dirname, '/templates/enrollmentcompleted.ejs');

const otppath = path.join(__dirname, '/templates/otp.ejs');

const ordertemplate = path.join(__dirname, '/templates/order.ejs');



exports.sendOtpemail = async (receiver, otp) =>{
//
    let message = "email sent";
     
  const transporter = nodemailer.createTransport({
      host: 'legithairng.com',
      port: 465,
      auth: {
        user: 'admin@legithairng.com',
        pass: 'Saintseverus911@'
      },
      tls: {
          rejectUnauthorized: true
      }
    });
    ejs.renderFile(otppath, {receiver, otp}, (err, data) => {
          if(err){
            message=err;
            
            return message;
          }else{
            const mailOptions = {
              from: 'testproject@pluralcode.academy',
              to: receiver,
              subject: 'Legithair.NG Otp',
              html: data
            };
            
            transporter.sendMail(mailOptions, function(error, info){
              if (error) {
                message =error;
              }
              
              return message;
              
            }); 
          }
    });
   


}



exports.sendEmailWithTemplate = async(to, subject, html)=>{
    
      const transporter = nodemailer.createTransport({
      host: 'mail.mycroshop.com',
      port: 465,
      auth: {
        user: 'no-reply@mycroshop.com',
        pass: 'Saintseverus911@'
      },
      tls: {
          rejectUnauthorized: true
      }
    })
    
     try {
    await transporter.sendMail({
      from: '"Mycroshop" <no-reply@mycroshop.com>',
      to,
      subject,
      html
    });
    return true;
  } catch (err) {
    
    return err;
  }
}


        
exports.sendOrderemail = async (name, email, products,delivery_address,delivery_landmark,amount_paid,payment_method,order_id) =>{
//
    let message = "email sent";
     
  const transporter = nodemailer.createTransport({
      host: 'legithairng.com',
      port: 465,
      auth: {
        user: 'sales@legithairng.com',
        pass: 'Saintseverus911@'
      },
      tls: {
          rejectUnauthorized: false
      }
    });
    ejs.renderFile(ordertemplate, {name, email, products,delivery_address,delivery_landmark,amount_paid,payment_method,order_id}, (err, data) => {
          if(err){
            message=err;
            
            return message;
          }else{
            const mailOptions = {
              from: 'sales@legithairng.com',
              to: email,
              subject: 'LEGITHAIR ORDER',
              html: data
            };
            
            transporter.sendMail(mailOptions, function(error, info){
              if (error) {
                message =error;
              }
              
              return message;
              
            }); 
          }
    });
   


}